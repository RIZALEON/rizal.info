/* BATIBABOX 2.1.7 · bbx-rvm.js · conversation + operational-action skills ported onto the ЯVM (egg id=rvm, rvm.v1).
 * Logic split (honest): the ЯVM bytecode (rasm, jobs in bbx-rvm-jobs.json) does every effect: reads of mirrored host files,
 * chat-turn persistence, Decider proposals + chain records. rvm.v1 has no string-search/split/regex opcode, so intent
 * matching, clarify, ЯID hiding and recall scoring run here in egg JS inside the same ENJIN page (no eval, no network,
 * no host APIs). Gated intents can ONLY reach the bbx-propose job (fs.write into the VM fs + chain.append) — never sign/seat/
 * install/publish/delete/toggle. Spec: BATIBABOX-SKILLS.rzl (rzl.batibabox.skills.v1). Decider ЯID-0001-3QQS. */
(function (root, factory) { var m = factory(); if (typeof module === 'object' && module.exports) module.exports = m; else root.YaSeedBbx = m; })(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';
  var VERSION = 'batibabox-rvm 2.1.7';
  var STOP = {}; 'a an the what which who is are was were be to of in on for and or how why it its this that with by from as at do does did me my you your i we our can please now'.split(' ').forEach(function (w) { STOP[w] = 1; });
  function words(s) { return String(s || '').toLowerCase().split(/[^\p{L}\p{N}-]+/u).filter(function (w) { return w.length > 2 && !STOP[w]; }); }
  function Bbx(rvm, spec, opts) {
    opts = opts || {}; this.vm = rvm; this.spec = spec; this.host = opts.host || 'ybot'; this.chat = opts.chat || 'default';
    this.conv = spec.conversation || {}; this.turnsMem = [];
  }
  Bbx.VERSION = VERSION;
  // install jobs through the RVM's own validator (assembles every job, refuses forbidden/unknown caps)
  Bbx.prototype.installJobs = function (lib) { var ok = this.vm.validateJobs(lib); for (var k in ok) this.vm.jobsLib[k] = ok[k]; return Object.keys(ok); };
  Bbx.prototype.job = async function (name, args) { var j = await this.vm.run(name, args); if (j.status !== 'done') throw new Error(name + ': ' + j.error); return j; };
  Bbx.prototype.read = async function (p) { try { return (await this.job('bbx-read', [p])).result || ''; } catch (e) { return ''; } };
  Bbx.prototype.ls = async function (p) { try { return (await this.job('bbx-ls', [p])).result || []; } catch (e) { return []; } };
  Bbx.prototype.intent = function (text) {
    var l = text.toLowerCase(), best = null, bl = 0;
    if (/^\/?(recall|remember)\b/.test(l)) return 'recall';   // explicit recall verb wins over topic keywords
    (this.spec.intents || []).forEach(function (it) { (it.kw || []).forEach(function (k) { if (l.indexOf(k) >= 0 && k.length > bl) { best = it.id; bl = k.length; } }); });
    return best || 'chat';
  };
  Bbx.prototype.topic = function () { var tf = {}; this.turnsMem.slice(-(this.conv.contextTurns || 6)).forEach(function (t) { if (t.role === 'user') words(t.text).forEach(function (w) { tf[w] = (tf[w] || 0) + 1; }); }); return Object.keys(tf).sort(function (a, b) { return tf[b] - tf[a]; }).slice(0, 5); };
  Bbx.prototype.clarify = function (text) {
    var c = this.conv.clarify || {}, ws = text.toLowerCase().split(/[^\p{L}]+/u).filter(Boolean), l = text.toLowerCase();
    var vague = (c.vague || []).some(function (v) { return v.indexOf(' ') >= 0 ? l.indexOf(v) >= 0 : ws.indexOf(v) >= 0; });
    return (ws.length < (c.minWords || 3) && vague && !this.topic().length) ? "Which thing do you mean? Tell me the app, egg or device and I'll take it from there." : null;
  };
  Bbx.prototype.ridFilter = function (reply, user) {
    var asked = (this.conv.ridAsk || []).some(function (k) { return user.toLowerCase().indexOf(k.toLowerCase()) >= 0; });
    return asked ? reply : String(reply).replace(/ЯID-[0-9]{4}-[0-9A-Z]{4}/g, '[ЯID hidden]');
  };
  Bbx.prototype.saveTurn = async function (role, text, intent) {
    this.turnsMem.push({ ts: new Date().toISOString(), role: role, text: String(text).slice(0, 800), intent: intent });
    await this.job('bbx-turn', ['/bbx/chat/' + this.host + '-' + this.chat + '.json', JSON.stringify(this.turnsMem)]);
  };
  Bbx.prototype.recall = async function (q) {
    var idx = []; try { idx = JSON.parse(await this.read('/host/mind/index.json')); } catch (e) {}
    var doc = await this.read('/host/mind/MACHINE-MIND-UNIFIED.md');   // 19 MB on the Neo: larger than the ЯVM fs caps (2 MiB/file, 16 MiB total) → usually absent
    var m = /ЯID-[0-9]{4}-[0-9A-Z]{4}/.exec(q);
    if (m) { var hay = doc || idx.map(function (e) { return e.h; }).join('\n'); return hay.split('\n').filter(function (l) { return l.indexOf(m[0]) >= 0; }).slice(0, 3).join('\n'); }
    var qw = words(q); if (!qw.length) return '';
    var sc = idx.map(function (e, i) { var hw = words(e.h); return [qw.filter(function (w) { return hw.indexOf(w) >= 0; }).length, i]; }).filter(function (x) { return x[0] > 0; }).sort(function (a, b) { return b[0] - a[0]; });
    if (!doc) return sc.slice(0, 3).map(function (x) { return 'heading: ' + idx[x[1]].h + ' (offset ' + idx[x[1]].o + ')'; }).join('\n');   // headings only until a host mind.read(offset,len) cap exists
    var bytes = new TextEncoder().encode(doc), dec = new TextDecoder();
    return sc.slice(0, 2).map(function (x) { var o = idx[x[1]].o || 0; return dec.decode(bytes.slice(o, o + 600)); }).join('\n…\n');
  };
  Bbx.prototype.runRead = async function (id, text) {
    var self = this;
    if (id === 'recall') { var r = await this.recall(text.replace(/recall/ig, '')); return r || "I don't know: recall found nothing."; }
    if (id === 'egg.list' || id === 'egg.status') {
      var fs = (await this.ls('/host/eggs-active/')).map(function (f) { return f.path; }).filter(function (p) { return /\.json$/.test(p); }).sort(), out = [];
      for (var i = 0; i < fs.length; i++) { var name = fs[i].split('/').pop().replace(/\.json$/, ''); if (id === 'egg.status' && text.toLowerCase().indexOf(name) < 0) continue; var o = {}; try { o = JSON.parse(await this.read(fs[i])); } catch (e) {} out.push(name + ' ' + (o.active || o.version || '?')); }
      return out.length ? out.join(' · ') : 'No matching ACTIVE egg.';
    }
    if (id === 'ghostchain.read') return (await this.read('/host/ghostchain-tail.jsonl')).split('\n').filter(Boolean).slice(-5).map(function (l) { try { var o = JSON.parse(l); return '#' + o.seq + ' ' + o.event + ' ' + o.id + ' ' + (o.ts || ''); } catch (e) { return null; } }).filter(Boolean).join('\n');
    if (id === 'spong.report') { var s = await this.read('/host/spong-latest.md'); return s ? s.slice(0, 900) : 'No SPONG report on this device.'; }
    if (id === 'lesson.read') {
      var ls = (await this.ls('/host/lessons/')).map(function (f) { return f.path.split('/').pop(); }).sort(), m = /L[0-9]{3}/.exec(text);
      if (m) { var f = ls.filter(function (x) { return x.indexOf(m[0]) === 0; })[0]; if (f) return f + '\n' + (await this.read('/host/lessons/' + f)).slice(0, 900); }
      return ls.length + ' lessons; newest: ' + ls.slice(-3).join(', ');
    }
    if (id === 'rweb.read' || id === 'xfiles.read' || id === 'mind.status') { var t = await this.read('/host/' + id + '.txt'); return t ? t.slice(0, 900) : 'Not mirrored on this device.'; }
    return 'Unknown read action.';
  };
  Bbx.prototype.propose = async function (id, text) {
    var a = (this.spec.actions || {})[id] || {}, now = new Date(), st = now.toISOString().replace(/[-:]/g, '').slice(0, 13).replace('T', '-');
    var body = { schema: 'rzl.batibabox.proposal.v1', decider: this.spec.decider, host: this.host, action: id, why: a.why || 'gated', request: text.slice(0, 400), ts: now.toISOString(), state: 'PROPOSED · waiting for Decider · not executed', via: 'ЯVM rvm.v1 job bbx-propose' };
    var sha = (await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(body))));
    var h = Array.from(new Uint8Array(sha)).map(function (b) { return (b < 16 ? '0' : '') + b.toString(16); }).join('').slice(0, 8);
    var name = st + '-' + this.host + '-bbx-' + h;
    var j = await this.job('bbx-propose', ['/bbx/proposals/' + name + '.json', JSON.stringify(body), name, { action: id, proposal: name, decider: this.spec.decider }]);
    return { name: name, job: j, text: 'That needs the Decider. I wrote proposal ' + name + ' (' + (a.why || 'gated') + '). Nothing ran.' };
  };
  Bbx.prototype.turn = async function (text) {
    text = String(text || '').trim(); var id = this.intent(text), reply, extra = {};
    var cq = this.clarify(text);
    if (cq) { id = 'clarify'; reply = cq; }
    else if (id === 'chat') reply = null;   // free chat → host Heart (rosHeart) with persona + context(); not a VM effect
    else if (((this.spec.actions || {})[id] || {}).gate === 'decider') { var p = await this.propose(id, text); reply = p.text; extra.proposal = p.name; extra.job = p.job; }
    else reply = await this.runRead(id, text);
    await this.saveTurn('user', text, id);
    if (reply != null) { reply = this.ridFilter(reply, text); await this.saveTurn('assistant', reply, id); }
    return Object.assign({ intent: id, reply: reply, heart: reply == null, persona: this.persona(), context: this.context() }, extra);
  };
  Bbx.prototype.persona = function () { var p = (this.spec.personas || {})[this.host] || {}; return 'You are ' + (p.name || this.host) + ': ' + (p.voice || 'helpful lab bot') + '.\nRULES:\n' + (this.conv.rules || []).map(function (r) { return '- ' + r; }).join('\n'); };
  Bbx.prototype.context = function () { var n = this.conv.contextTurns || 6, all = this.turnsMem; return 'CHAT MEMORY (' + all.length + ' turns)\nTOPIC: ' + this.topic().join(', ') + '\n' + all.slice(-n).map(function (t) { return t.role + ': ' + t.text.slice(0, 240); }).join('\n'); };
  return { VERSION: VERSION, Bbx: Bbx, words: words };
});
