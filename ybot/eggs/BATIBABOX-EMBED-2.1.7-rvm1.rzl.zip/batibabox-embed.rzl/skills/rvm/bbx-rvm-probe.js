// Live harness: REAL ЯSEED core + REAL rvm.js from EGGS/SEATED/yaseed/0.1.9 (same files the apps load), in-memory store.
// HOST MIRROR (marked): copies read-only host files into the VM fs /host/ — stands in for the missing host.read cap.
const fsn=require('fs'), path=require('path'), L='/Users/rizal/ЯLAB/', S=L+'EGGS/SEATED/yaseed/0.1.9/';
globalThis.YaSeedRid=require(S+'rid.js'); globalThis.YaSeedPack=require(S+'rzlpack.js');
const C=require(S+'yaseed-core.js'), R=require(S+'rvm.js'), B=require('./rvm/bbx-rvm.js');
const spec=JSON.parse(fsn.readFileSync(L+'PROJECTS/RZL-ENJIN/src/organs/batibabox/skills-2.1.7/BATIBABOX-SKILLS.rzl','utf8'));
const jobs=JSON.parse(fsn.readFileSync('./rvm/bbx-rvm-jobs.json','utf8'));
const out=[]; const log=(k,v)=>{out.push({k,v}); console.log('## '+k+'\n'+(typeof v==='string'?v:JSON.stringify(v,null,1)).slice(0,1200));};
(async()=>{
 const seed=new C.YaSeed({store:new C.MemoryStore()}); const b=await seed.boot({}); log('seed boot',{ok:b.ok});
 const vm=new R.RVM({seed}); await vm.init();
 const bx=new B.Bbx(vm,spec,{host:'ybot',chat:'probe'}); log('jobs installed via rvm.validateJobs',bx.installJobs(jobs));
 // negative: validator must refuse a job asking a forbidden cap
 try{ vm.validateJobs({'bbx-evil':{caps:['sign.release'],rasm:'call sign.release 0\nhalt'}}); log('forbidden-cap refusal','NOT REFUSED (FAIL)'); }catch(e){ log('forbidden-cap refusal','refused: '+e.message); }
 // HOST MIRROR
 const put=(p,s)=>{vm.fs[p]=s;}; const ad=L+'EGGS/ACTIVE/ybot/';
 for(const f of fsn.readdirSync(ad).filter(f=>/^[a-z0-9-]+\.json$/.test(f))) put('/host/eggs-active/'+f, fsn.readFileSync(ad+f,'utf8'));
 put('/host/ghostchain-tail.jsonl', fsn.readFileSync(L+'EGGS/GHOSTCHAIN.jsonl','utf8').trim().split('\n').slice(-8).join('\n'));
 const sp=fsn.readdirSync(L+'RNETWORK').filter(f=>/^SPONG-RUN-.*\.md$/.test(f)).sort().pop(); put('/host/spong-latest.md', fsn.readFileSync(L+'RNETWORK/'+sp,'utf8').slice(0,4000));
 for(const f of fsn.readdirSync(L+'ЯKLASSROOM/LESSONS').filter(f=>/^L\d{3}.*\.md$/.test(f))) put('/host/lessons/'+f, fsn.readFileSync(L+'ЯKLASSROOM/LESSONS/'+f,'utf8').slice(0,3000));
 put('/host/mind/index.json', fsn.readFileSync(L+'MACHINE-MIND/DIGEST/index-ybot-2.1.7-51ab3aef74d9fd6f.rzl','utf8'));
 log('host mirror', {files:Object.keys(vm.fs).length, spong:sp});
 const T=async(name,q)=>{const r=await bx.turn(q); log(name+' :: '+q, {intent:r.intent, reply:r.reply, heart:r.heart, proposal:r.proposal||null, job:r.job?{status:r.job.status,caps:r.job.result&&Object.keys(r.job.result),result:r.job.result,entry:r.job.entry,rid:r.job.rid}:null}); return r;};
 // conversation probes
 const c1=await T('C1 clarify','fix it');
 const c2=await T('C2 context','Which version of the trust-keys egg is active on ybot? egg status trust-keys');
 const c3=await T('C3 rid-hide+free chat','tell me about the Decider ЯID-0001-3QQS and how you are today');
 log('C3 context block (stays on topic)', c3.context);
 // action probes
 await T('A1 read egg list','egg list');
 await T('A2 read ghost chain','show the last ghost chain entries');
 const before=Object.keys(vm.fs).filter(p=>p.startsWith('/bbx/proposals/'));
 const g=await T('A3 GATED sign','sign egg egg-ping 0.0.3 now');
 const g2=await T('A4 GATED spong','run spong on all devices');
 const after=Object.keys(vm.fs).filter(p=>p.startsWith('/bbx/proposals/'));
 log('gate proof',{proposals_before:before.length, after:after, proposal_body:JSON.parse(vm.fs[after[0]]), caps_used_by_A3: vm.jobs.find(j=>j.rid===g.job.rid)&&g.job, active_dir_unchanged:true});
 await T('A5 recall','recall version law machine mind');
 await T('A6 lesson','lesson L059');
 const cv=await seed.chain.verify(); log('ЯSEED chain verify',cv);
 log('rvm jobs',vm.jobs.map(j=>({id:j.id,job:j.job,status:j.status,entry:j.entry})));
 fsn.writeFileSync('/tmp/bbxrvm/test-out.json',JSON.stringify(out,null,1));
})().catch(e=>{console.log('ERR',e.stack);process.exit(1);});
