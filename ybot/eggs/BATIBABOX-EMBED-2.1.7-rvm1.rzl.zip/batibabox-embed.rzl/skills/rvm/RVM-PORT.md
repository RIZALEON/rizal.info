# BATIBABOX 2.1.7 · ЯVM port (revision rvm1 · 2026-10-15 MT · STAGED only)
ЯVM = egg `rvm` 0.1.3 (rvm.js, `rvm.v1`), also fused inside egg `yaseed` 0.1.9 (byte-identical rvm.js). A deterministic stack-bytecode VM
in pure JS (no eval). Source language: rasm (29 ops: push pop dup swap load store add sub mul div mod eq ne lt gt not and or get set mkarr
mkobj len jmp jz jnz call assert halt). Effects only via `call <cap> <n>` against a per-job capability grant; fuel-limited; pre-job
snapshot + rollback on failure; every job minted an ЯID and chained in the ЯSEED Ghost Chain (P-256 device chain).
Caps: fs.read fs.write fs.ls fs.rm log chain.append rid.mint index.file net.fetch(off unless host allows) pack.build pack.verify
seed.grow/train/evolve module.modify module.update sign.device. Forbidden: sign.release sign.app sign.appcast keys.add trusted-signers.add
host.exec xcode.build. Jobs are data: rvm.init loads `rvm/jobs.json` from the yaseed pack and `/etc/rvm-jobs.json` from the VM fs, each
through validateJobs (must assemble, only known non-forbidden caps).

## What this revision adds
- `bbx-rvm-jobs.json`: rasm jobs bbx-read, bbx-ls (gate read), bbx-turn (chat memory), bbx-propose (Decider proposal: fs.write into
  /bbx/proposals + chain.append; returns executed:false). No job holds any sign/seat/install/publish/delete/toggle/network cap.
- `bbx-rvm.js`: router (intents, one clarifying question, topic/context, persona, ЯID hiding, recall scoring) from BATIBABOX-SKILLS.rzl.
  Runs as egg JS in the same ENJIN page as rvm.js because rvm.v1 has no string search/split/regex opcode.

## Gaps (host functions needed — not faked)
1. `host.read(path)` read-only allowlisted cap (EGGS/ACTIVE/<host>, GHOSTCHAIN tail, RNETWORK, ЯKLASSROOM/LESSONS, MACHINE-MIND index)
   — today the VM fs only sees its own files and the yaseed pack; the probe harness mirrors these files into /host/.
2. `mind.read(offset,len)` — MACHINE-MIND-UNIFIED.md is 19 MB > ЯVM caps (2 MiB/file, 16 MiB total); recall returns headings only.
3. A string `has`/`split` opcode (or cap) to move intent matching into bytecode.
4. A page that loads bbx-rvm.js: batibabox-embed is a dataOnly egg, so its JS is not executed by the host; the loader line has to come
   in a yaseed (page egg) revision. The rasm jobs alone can be delivered today via `/rvm fs put /etc/rvm-jobs.json …`.
5. Proposals land in the VM fs (/bbx/proposals); a host relay to PLUGINS/SUPERGROK-BRIDGE/PROPOSALS is needed for the Decider inbox.
