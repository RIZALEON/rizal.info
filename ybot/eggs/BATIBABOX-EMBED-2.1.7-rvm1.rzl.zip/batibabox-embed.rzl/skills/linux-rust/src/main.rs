//! batibabox-ut 2.1.7 · native BATIBABOX conversation + operational-action adapter for Ubuntu Touch / Linux (Pixel 3a).
//! Offline: keyword + exact-ЯID recall over the seated MACHINE-MIND, per-chat memory, local action registry, Decider proposals,
//! chained action log. Online: `sync` fetches the host feed via the system curl, verifies each egg's ed25519 signature
//! (Neo egg key e5833fdfbbfe, public key only) and caches the verified listing. Never downloads payloads, never installs.
//! Same spec (BATIBABOX-SKILLS.rzl), gates and logs as the Swift (macOS/iOS) and Kotlin (Android) paths.
use regex::Regex;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::HashMap, fs, io::Write, path::PathBuf, process::Command, time::SystemTime};

const EGG_KEY: &str = "zs7M4OOB0zQhWOQw3SHpAY+XYxbZJvcPESy1y400Ti0=";
const STOP: &str = "a an the what which who is are was were be to of in on for and or how why it its this that with by from as at do does did me my you your i we our can please now";

fn sha_hex(b: &[u8]) -> String { Sha256::digest(b).iter().map(|x| format!("{:02x}", x)).collect() }
fn now() -> (String, String) {
    let o = Command::new("date").args(["-u", "+%Y-%m-%dT%H:%M:%SZ"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).unwrap_or_default();
    let l = Command::new("date").arg("+%Y%m%d-%H%M").output().ok().map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).unwrap_or_default();
    if o.is_empty() { let s = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap().as_secs(); (s.to_string(), s.to_string()) } else { (o, l) }
}
fn b64(s: &str) -> Option<Vec<u8>> {
    let t = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let (mut out, mut buf, mut n) = (vec![], 0u32, 0);
    for c in s.bytes().filter(|c| *c != b'=') { let v = t.iter().position(|x| *x == c)? as u32; buf = buf << 6 | v; n += 6; if n >= 8 { n -= 8; out.push((buf >> n) as u8); buf &= (1 << n) - 1; } }
    Some(out)
}
fn cut(s: &str, n: usize) -> String { s.chars().take(n).collect() }
fn words(s: &str) -> Vec<String> {
    let stop: Vec<&str> = STOP.split(' ').collect();
    s.to_lowercase().split(|c: char| !(c.is_alphanumeric() || c == '-')).filter(|w| w.chars().count() > 2 && !stop.contains(w)).map(String::from).collect()
}
fn top(m: &HashMap<String, usize>, n: usize) -> Vec<String> {
    let mut v: Vec<_> = m.iter().collect(); v.sort_by(|a, b| b.1.cmp(a.1).then(a.0.cmp(b.0))); v.into_iter().take(n).map(|x| x.0.clone()).collect()
}
fn append(p: &PathBuf, v: &Value) { if let Ok(mut f) = fs::OpenOptions::new().create(true).append(true).open(p) { let _ = writeln!(f, "{}", v); } }

struct B { lab: PathBuf, host: String, s: Value, rid: Regex }
struct R { intent: String, gate: String, out: String, proposal: String }

impl B {
    fn p(&self, rel: &str) -> PathBuf { self.lab.join(rel) }
    fn read(&self, rel: &str) -> String { fs::read_to_string(self.p(rel)).unwrap_or_default() }
    fn ls(&self, rel: &str) -> Vec<String> { let mut v: Vec<String> = fs::read_dir(self.p(rel)).map(|d| d.filter_map(|e| e.ok()).map(|e| e.file_name().to_string_lossy().into_owned()).collect()).unwrap_or_default(); v.sort(); v }
    fn conv(&self) -> &Value { &self.s["conversation"] }

    fn intent(&self, text: &str) -> String {
        let t = text.to_lowercase();
        if t.starts_with("recall ") || t.starts_with("/recall ") { return "recall".into(); }
        let (mut best, mut bl) = ("chat".to_string(), 0);
        for i in self.s["intents"].as_array().into_iter().flatten() {
            for k in i["kw"].as_array().into_iter().flatten().filter_map(|k| k.as_str()) {
                if t.contains(k) && k.chars().count() > bl { best = i["id"].as_str().unwrap_or("chat").into(); bl = k.chars().count(); }
            }
        }
        best
    }
    fn chat_file(&self, chat: &str) -> PathBuf {
        let d = self.p(&format!("MACHINE-MIND/DIGEST/CHAT/{}", self.host)); let _ = fs::create_dir_all(&d);
        d.join(format!("{}.jsonl", chat.chars().filter(|c| c.is_ascii_alphanumeric() || *c == '-').collect::<String>()))
    }
    fn turns(&self, chat: &str) -> Vec<Value> { fs::read_to_string(self.chat_file(chat)).unwrap_or_default().lines().filter_map(|l| serde_json::from_str(l).ok()).collect() }
    fn remember(&self, chat: &str, role: &str, text: &str, intent: &str) { append(&self.chat_file(chat), &json!({"ts": now().0, "role": role, "text": cut(text, 800), "intent": intent})); }
    fn context(&self, chat: &str) -> (String, Vec<String>) {
        let all = self.turns(chat); let n = self.conv()["contextTurns"].as_u64().unwrap_or(6) as usize;
        let c = all.len().saturating_sub(n); let (older, recent) = all.split_at(c);
        let (mut f, mut tf) = (HashMap::new(), HashMap::new());
        for t in older { for w in words(t["text"].as_str().unwrap_or("")) { *f.entry(w).or_insert(0) += 1; } }
        for t in recent.iter().filter(|t| t["role"] == "user") { for w in words(t["text"].as_str().unwrap_or("")) { *tf.entry(w).or_insert(0) += 1; } }
        let mut b = format!("CHAT MEMORY ({} turns)", all.len());
        let d = top(&f, 10); if !d.is_empty() { b += &format!("\nearlier topics: {}", d.join(", ")); }
        for t in recent { b += &format!("\n{}: {}", t["role"].as_str().unwrap_or("?"), cut(t["text"].as_str().unwrap_or(""), 240)); }
        (b, top(&tf, 5))
    }
    fn clarify(&self, text: &str, topic: &[String]) -> Option<String> {
        let c = &self.conv()["clarify"]; let t = text.to_lowercase();
        let ws: Vec<&str> = t.split(|ch: char| !ch.is_alphabetic()).filter(|w| !w.is_empty()).collect();
        let vague = c["vague"].as_array().into_iter().flatten().filter_map(|v| v.as_str()).any(|v| if v.contains(' ') { t.contains(v) } else { ws.contains(&v) });
        if (ws.len() as u64) < c["minWords"].as_u64().unwrap_or(3) && vague && topic.is_empty() { Some("Which thing do you mean? Tell me the app, egg or device and I'll take it from there.".into()) } else { None }
    }
    fn rid_filter(&self, reply: &str, user: &str) -> String {
        let u = user.to_lowercase();
        if self.conv()["ridAsk"].as_array().into_iter().flatten().filter_map(|a| a.as_str()).any(|a| u.contains(&a.to_lowercase())) { return reply.into(); }
        self.rid.replace_all(reply, "[ЯID hidden]").into_owned()
    }
    fn persona(&self) -> String {
        let p = &self.s["personas"][&self.host];
        let rules: String = self.conv()["rules"].as_array().into_iter().flatten().filter_map(|r| r.as_str()).map(|r| format!("\n- {}", r)).collect();
        format!("You are {}: {}.\nRULES:{}", p["name"].as_str().unwrap_or(&self.host), p["voice"].as_str().unwrap_or("helpful lab bot"), rules)
    }
    fn active(&self) -> Value { serde_json::from_str(&self.read(&format!("EGGS/ACTIVE/{}/machine-mind.json", self.host))).unwrap_or(Value::Null) }
    fn mind_status(&self) -> String {
        let a = self.active();
        format!("machine-mind ACTIVE {} ({}, sha {}) · SEATED: {} · history: {}", a["active"].as_str().unwrap_or("?"), a["flavor"].as_str().unwrap_or("?"),
            cut(a["sha256"].as_str().unwrap_or(""), 12), self.ls("EGGS/SEATED/machine-mind").join(","), a["history"])
    }
    fn recall(&self, q: &str) -> String {
        let a = self.active(); let v = a["active"].as_str().unwrap_or(""); let sha = cut(a["sha256"].as_str().unwrap_or(""), 16);
        let doc = self.p(&format!("EGGS/SEATED/machine-mind/{}/MACHINE-MIND-UNIFIED.md", v));
        let Ok(bytes) = fs::read(&doc) else { return String::new() };
        if let Some(m) = self.rid.find(q) {
            let s = String::from_utf8_lossy(&bytes);
            return s.lines().filter(|l| l.contains(m.as_str())).take(3).collect::<Vec<_>>().join("\n");
        }
        let idx: Value = serde_json::from_str(&self.read(&format!("MACHINE-MIND/DIGEST/index-{}-{}-{}.rzl", self.host, v, sha))).unwrap_or(Value::Null);
        let qw: Vec<String> = words(q); if qw.is_empty() { return String::new(); }
        let mut sc: Vec<(usize, u64)> = vec![];
        for e in idx.as_array().into_iter().flatten() {
            let mut hw = words(e["h"].as_str().unwrap_or("")); hw.sort(); hw.dedup();
            let s = hw.iter().filter(|w| qw.contains(w)).count();
            if s > 0 { sc.push((s, e["o"].as_u64().unwrap_or(0))); }
        }
        sc.sort_by(|a, b| b.0.cmp(&a.0));
        sc.iter().take(2).map(|(_, o)| { let o = *o as usize; String::from_utf8_lossy(&bytes[o.min(bytes.len())..(o + 600).min(bytes.len())]).into_owned() }).collect::<Vec<_>>().join("\n…\n")
    }
    fn newest(&self, dir: &str, pre: &str) -> Option<String> { self.ls(dir).into_iter().filter(|f| f.starts_with(pre) && f.ends_with(".md")).last() }
    fn run_read(&self, id: &str, text: &str) -> String {
        match id {
            "recall" => { let r = self.recall(&text.replacen("recall", "", 1)); if r.is_empty() { "I don't know: recall found nothing.".into() } else { r } }
            "mind.status" => self.mind_status(),
            "spong.report" => self.newest("RNETWORK", "SPONG-RUN-").map(|f| format!("{}\n{}", f, cut(&self.read(&format!("RNETWORK/{}", f)), 900))).unwrap_or("No SPONG report on this device.".into()),
            "egg.list" | "egg.status" => {
                let d = format!("EGGS/ACTIVE/{}", self.host); let tl = text.to_lowercase();
                let out: Vec<String> = self.ls(&d).into_iter().filter(|f| f.ends_with(".json")).filter_map(|f| {
                    let name = f.trim_end_matches(".json").to_string();
                    if id == "egg.status" && !tl.contains(&name) { return None; }
                    let o: Value = serde_json::from_str(&self.read(&format!("{}/{}", d, f))).unwrap_or(Value::Null);
                    Some(format!("{} {}", name, o["active"].as_str().or(o["version"].as_str()).unwrap_or("?")))
                }).collect();
                if out.is_empty() { "No matching ACTIVE egg.".into() } else { out.join(" · ") }
            }
            "ghostchain.read" => {
                let s = self.read("EGGS/GHOSTCHAIN.jsonl"); let ls: Vec<&str> = s.lines().collect();
                ls[ls.len().saturating_sub(5)..].iter().filter_map(|l| serde_json::from_str::<Value>(l).ok()).map(|o| format!("#{} {} {} {}", o["seq"], o["event"].as_str().unwrap_or(""), o["id"].as_str().unwrap_or(""), o["ts"].as_str().unwrap_or(""))).collect::<Vec<_>>().join("\n")
            }
            "lesson.read" => {
                let ls = self.ls("ЯKLASSROOM/LESSONS");
                if let Some(m) = Regex::new(r"L[0-9]{3}").unwrap().find(text) { if let Some(f) = ls.iter().find(|f| f.starts_with(m.as_str())) { return format!("{}\n{}", f, cut(&self.read(&format!("ЯKLASSROOM/LESSONS/{}", f)), 900)); } }
                format!("{} lessons; newest: {}", ls.len(), ls[ls.len().saturating_sub(3)..].join(", "))
            }
            "rweb.read" => self.newest("RNETWORK", "RNETWORK-MAP-").map(|f| format!("{}: {}", f, self.read(&format!("RNETWORK/{}", f)).lines().filter(|l| l.starts_with('#')).take(12).collect::<Vec<_>>().join(" | "))).unwrap_or("No RWEB map here.".into()),
            "xfiles.read" => { let x = self.read("RNETWORK/XFILES.md"); if x.is_empty() { "No XFILE list here.".into() } else { cut(&x, 900) } }
            _ => String::new(),
        }
    }
    fn propose(&self, id: &str, text: &str, why: &str) -> String {
        let dir = self.p("PLUGINS/SUPERGROK-BRIDGE/PROPOSALS"); let _ = fs::create_dir_all(&dir); let (ts, loc) = now();
        let body = json!({"schema": "rzl.batibabox.proposal.v1", "organ": "rzl.organ.batibabox.v1", "version": "2.1.7", "host": self.host, "adapter": "linux-rust",
            "action": id, "why": why, "request": cut(text, 400), "decider": self.s["decider"], "state": "awaiting-decider", "executed": false, "ts": ts});
        let d = serde_json::to_string_pretty(&body).unwrap();
        let pid = format!("{}-{}-bbx-{}", loc, self.host, &sha_hex(d.as_bytes())[..8]);
        let _ = fs::write(dir.join(format!("{}.json", pid)), d); pid
    }
    fn log_action(&self, mut r: Value) {
        let p = self.p("MACHINE-MIND/DIGEST/BATIBABOX-ACTIONS.jsonl"); let s = fs::read_to_string(&p).unwrap_or_default();
        let prev = s.lines().last().map(|l| sha_hex(l.as_bytes())).unwrap_or_default();
        r["prev"] = json!(prev); r["ts"] = json!(now().0); r["host"] = json!(self.host); r["adapter"] = json!("linux-rust"); append(&p, &r);
    }
    fn turn(&self, chat: &str, text: &str) -> R {
        let (_ctx, topic) = self.context(chat); let i = self.intent(text); self.remember(chat, "user", text, &i);
        if i == "chat" { if let Some(q) = self.clarify(text, &topic) { self.remember(chat, "bot", &q, "clarify"); return R { intent: "clarify".into(), gate: "none".into(), out: q, proposal: String::new() }; } }
        let a = &self.s["actions"][&i]; let gate = a["gate"].as_str().unwrap_or("none").to_string();
        let (mut out, mut pid) = (String::new(), String::new());
        match gate.as_str() {
            "read" => out = self.run_read(&i, text),
            "decider" => { pid = self.propose(&i, text, a["why"].as_str().unwrap_or("")); out = format!("That needs Rizal's approval. I made Decider proposal {}; nothing ran.", pid); }
            _ => { let m = self.recall(&format!("{} {}", text, topic.join(" "))); if !m.is_empty() { out = format!("memory: {}", m); } }
        }
        if gate != "none" { self.log_action(json!({"action": i, "gate": gate, "proposal": pid, "executed": gate == "read", "chat": chat, "out_sha256": sha_hex(out.as_bytes())})); }
        let shown = self.rid_filter(&out, text); if !shown.is_empty() { self.remember(chat, "bot", &shown, &i); }
        R { intent: i, gate, out: shown, proposal: pid }
    }
    fn sync(&self, feed: &str) -> String {
        use ed25519_dalek::{PublicKey, Signature, Verifier};
        let o = Command::new("curl").args(["-fsSL", "--max-time", "12", feed]).output();
        let Ok(o) = o else { return "offline: curl unavailable".into() };
        if !o.status.success() { return format!("offline: curl exit {:?}", o.status.code()); }
        let Ok(doc) = serde_json::from_slice::<Value>(&o.stdout) else { return "feed not JSON".into() };
        let pk = PublicKey::from_bytes(&b64(EGG_KEY).unwrap()).unwrap();
        let items: Vec<&Value> = ["eggs", "items"].iter().flat_map(|k| doc[*k].as_array().into_iter().flatten()).collect();
        let (mut ok, mut bad, mut keep, mut note) = (0, 0, vec![], String::new());
        for e in &items {
            let kind = e["kind"].as_str().unwrap_or("egg");
            let msg = format!("rlab-update-v1\n{}\n{}\n{}\n{}\n{}\n{}", kind, e["id"].as_str().unwrap_or(""), e["version"].as_str().unwrap_or(""), e["name"].as_str().unwrap_or(""), e["size"].as_u64().unwrap_or(0), e["sha256"].as_str().unwrap_or("").to_lowercase());
            let sig = b64(e["ed25519"].as_str().unwrap_or("")).and_then(|b| Signature::from_bytes(&b).ok());
            if sig.map(|s| pk.verify(msg.as_bytes(), &s).is_ok()).unwrap_or(false) {
                ok += 1; keep.push(json!({"id": e["id"], "version": e["version"], "sha256": e["sha256"]}));
                if e["id"] == "batibabox-embed" || e["id"] == "machine-mind" { note += &format!(" {}={}", e["id"].as_str().unwrap(), e["version"].as_str().unwrap_or("?")); }
            } else { bad += 1; }
        }
        let _ = fs::create_dir_all(self.p("MACHINE-MIND/DIGEST/FEED-CACHE"));
        let _ = fs::write(self.p(&format!("MACHINE-MIND/DIGEST/FEED-CACHE/{}.json", self.host)), serde_json::to_string_pretty(&json!({"feed": feed, "at": now().0, "verified": keep, "unverified": bad})).unwrap());
        format!("{} items · {} signature-verified · {} unverified · cached ·{}", items.len(), ok, bad, note)
    }
}

fn main() {
    let a: Vec<String> = std::env::args().collect();
    if a.len() < 5 { eprintln!("usage: batibabox-ut <lab> <host> <spec> turn <chat> <text..> | sync <feed> | mind | ridtest <reply> <user>"); std::process::exit(64); }
    let s: Value = serde_json::from_str(&fs::read_to_string(&a[3]).expect("spec")).expect("spec json");
    let b = B { lab: PathBuf::from(&a[1]), host: a[2].clone(), s, rid: Regex::new(r"ЯID-[0-9]{4}-[0-9A-Z]{4}").unwrap() };
    match a[4].as_str() {
        "mind" => println!("{}", b.mind_status()),
        "persona" => println!("{}", b.persona()),
        "context" => println!("{}", b.context(&a[5]).0),
        "sync" => println!("{}", b.sync(&a[5])),
        "ridtest" => println!("{}", b.rid_filter(&a[5], &a[6])),
        "turn" => for q in &a[6..] { let r = b.turn(&a[5], q); println!("Q: {}\n intent={} gate={} proposal={}\n out: {}\n", q, r.intent, r.gate, if r.proposal.is_empty() { "-" } else { &r.proposal }, cut(&r.out, 400)); },
        _ => std::process::exit(64),
    }
}
