package local.rizal.yabowzr.batibabox

// BATIBABOX-SKILLS 2.1.7 · Android (ЯBOWZR / ЯBOT 2.1.9 native) adapter for rzl.organ.batibabox.v1.
// Same spec (BATIBABOX-SKILLS.rzl, seated as an egg), same gates and logs as the Swift (macOS/iOS) and Rust (Ubuntu Touch) paths.
// OFFLINE: per-chat memory, keyword + exact-ЯID recall over the seated MACHINE-MIND, local action registry, Decider proposals,
//          chained action log. (On-device embeddings: next step, reading BATIBABOX-EMBED.rzl like RZLEmbed; not in 2.1.7.)
// ONLINE : sync() fetches the host feed, verifies each item's ed25519 (EggIntake.PUBLIC_KEY_B64, keyId e5833fdfbbfe) with the
//          app's Ed25519Verify, and caches the verified listing. It never downloads payloads and never installs or seats.
// Layout (EggIntake): filesDir/eggs/ACTIVE.json {id:{version,sha256}}, filesDir/eggs/SEATED/<id>/<ver>/ ; memory in filesDir/batibabox/.

import android.util.Base64
import local.rizal.yabowzr.Ed25519Verify
import local.rizal.yabowzr.EggIntake
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class BatibaboxSkills(private val filesDir: File, private val host: String, specJson: String) {
    data class Result(val intent: String, val gate: String, val output: String, val proposal: String?, val context: String)

    private val spec = JSONObject(specJson)
    private val conv = spec.optJSONObject("conversation") ?: JSONObject()
    private val actions = spec.optJSONObject("actions") ?: JSONObject()
    private val mem = File(filesDir, "batibabox").apply { mkdirs() }
    private val rid = Regex("ЯID-[0-9]{4}-[0-9A-Z]{4}")
    private val stop = ("a an the what which who is are was were be to of in on for and or how why it its this that with by from as at " +
        "do does did me my you your i we our can please now").split(" ").toSet()

    companion object {
        fun sha(b: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
        fun iso(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        fun stamp(): String = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
    }
    private fun words(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{N}-]+")).filter { it.length > 2 && it !in stop }
    private fun arr(o: JSONObject?, k: String): List<String> = o?.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()

    fun intent(text: String): String {
        val t = text.lowercase()
        if (t.startsWith("recall ") || t.startsWith("/recall ")) return "recall"
        var best = "chat"; var bl = 0
        val ins = spec.optJSONArray("intents") ?: JSONArray()
        for (i in 0 until ins.length()) { val o = ins.getJSONObject(i)
            for (k in arr(o, "kw")) if (t.contains(k) && k.length > bl) { best = o.getString("id"); bl = k.length } }
        return best
    }
    private fun chatFile(chat: String) = File(mem, "CHAT/$host").apply { mkdirs() }.let { File(it, chat.filter { c -> c.isLetterOrDigit() || c == '-' } + ".jsonl") }
    private fun turns(chat: String): List<JSONObject> = chatFile(chat).takeIf { it.isFile }?.readLines()?.mapNotNull { runCatching { JSONObject(it) }.getOrNull() } ?: emptyList()
    private fun remember(chat: String, role: String, text: String, intent: String) =
        chatFile(chat).appendText(JSONObject().put("ts", iso()).put("role", role).put("text", text.take(800)).put("intent", intent).toString() + "\n")

    fun context(chat: String): Pair<String, List<String>> {
        val all = turns(chat); val n = conv.optInt("contextTurns", 6)
        val recent = all.takeLast(n); val older = all.dropLast(minOf(n, all.size))
        val digest = older.flatMap { words(it.optString("text")) }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(10).map { it.key }
        val topic = recent.filter { it.optString("role") == "user" }.flatMap { words(it.optString("text")) }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5).map { it.key }
        val b = StringBuilder("CHAT MEMORY (${all.size} turns)")
        if (digest.isNotEmpty()) b.append("\nearlier topics: ").append(digest.joinToString(", "))
        recent.forEach { b.append("\n${it.optString("role")}: ${it.optString("text").take(240)}") }
        return b.toString() to topic
    }
    fun clarify(text: String, topic: List<String>): String? {
        val c = conv.optJSONObject("clarify") ?: JSONObject(); val t = text.lowercase()
        val ws = t.split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        val vague = arr(c, "vague").any { v -> if (' ' in v) t.contains(v) else v in ws }
        return if (ws.size < c.optInt("minWords", 3) && vague && topic.isEmpty()) "Which thing do you mean? Tell me the app, egg or device and I'll take it from there." else null
    }
    fun ridFilter(reply: String, user: String): String =
        if (arr(conv, "ridAsk").any { user.lowercase().contains(it.lowercase()) }) reply else rid.replace(reply, "[ЯID hidden]")
    fun persona(): String {
        val p = spec.optJSONObject("personas")?.optJSONObject(host) ?: JSONObject()
        return "You are ${p.optString("name", host)}: ${p.optString("voice", "helpful lab bot")}.\nRULES:" + arr(conv, "rules").joinToString("") { "\n- $it" }
    }
    private fun activeEggs(): JSONObject = File(filesDir, "eggs/ACTIVE.json").takeIf { it.isFile }?.let { runCatching { JSONObject(it.readText()) }.getOrNull() } ?: JSONObject()
    private fun seated(id: String) = File(filesDir, "eggs/SEATED/$id").list()?.sorted() ?: emptyList()

    fun mindStatus(): String {
        val a = activeEggs().optJSONObject("machine-mind")
        return if (a == null) "machine-mind: not ACTIVE on this device · SEATED: ${seated("machine-mind").joinToString(",")}"
        else "machine-mind ACTIVE ${a.optString("version")} (sha ${a.optString("sha256").take(12)}) · SEATED: ${seated("machine-mind").joinToString(",")}"
    }
    private fun mindDoc(): File? = activeEggs().optJSONObject("machine-mind")?.optString("version")
        ?.let { File(filesDir, "eggs/SEATED/machine-mind/$it/MACHINE-MIND-UNIFIED.md") }?.takeIf { it.isFile }

    /** keyword over markdown headings + exact-ЯID line match; index built once per mind file into filesDir/batibabox/. */
    fun recall(q: String): String {
        val doc = mindDoc() ?: return ""
        rid.find(q)?.let { m -> return doc.useLines { ls -> ls.filter { it.contains(m.value) }.take(3).toList() }.joinToString("\n") }
        val idxF = File(mem, "index-$host-${doc.length()}.json")
        val idx: JSONArray = if (idxF.isFile) JSONArray(idxF.readText()) else JSONArray().also { a ->
            var off = 0L
            doc.inputStream().bufferedReader().useLines { ls -> ls.forEach { l -> if (l.startsWith("#")) a.put(JSONObject().put("h", l.take(160)).put("o", off)); off += l.toByteArray().size + 1 } }
            idxF.writeText(a.toString())
        }
        val qw = words(q).toSet(); if (qw.isEmpty()) return ""
        val scored = (0 until idx.length()).map { i -> i to words(idx.getJSONObject(i).optString("h")).toSet().intersect(qw).size }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(2)
        java.io.RandomAccessFile(doc, "r").use { f ->
            return scored.joinToString("\n…\n") { (i, _) -> f.seek(idx.getJSONObject(i).getLong("o")); val b = ByteArray(600); val n = f.read(b); String(b, 0, maxOf(n, 0)) }
        }
    }
    private fun runRead(id: String, text: String): String = when (id) {
        "recall" -> recall(text.replaceFirst("recall", "")).ifEmpty { "I don't know: recall found nothing." }
        "mind.status" -> mindStatus()
        "egg.list", "egg.status" -> activeEggs().let { a -> a.keys().asSequence().sorted()
            .filter { id == "egg.list" || text.lowercase().contains(it) }.map { "$it ${a.optJSONObject(it)?.optString("version")}" }.toList() }
            .ifEmpty { listOf("No matching ACTIVE egg.") }.joinToString(" · ")
        "ghostchain.read" -> File(filesDir, "eggs/GHOSTCHAIN.jsonl").takeIf { it.isFile }?.readLines()?.takeLast(5)?.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
            ?.joinToString("\n") { "#${it.opt("seq")} ${it.optString("event")} ${it.optString("id")} ${it.optString("ts")}" } ?: "No Ghost Chain copy on this device."
        "spong.report", "rweb.read", "xfiles.read", "lesson.read" -> {
            val name = mapOf("spong.report" to "spong-report", "rweb.read" to "machine-mind-rweb", "xfiles.read" to "machine-mind-rweb", "lesson.read" to "klassroom-lessons")[id]!!
            val v = activeEggs().optJSONObject(name)?.optString("version")
            if (v == null) "No $name egg ACTIVE on this device." else File(filesDir, "eggs/SEATED/$name/$v").walkTopDown()
                .filter { it.isFile && (it.extension == "md" || it.extension == "rzl" || it.extension == "json") }.sortedBy { it.name }.lastOrNull()
                ?.let { it.name + "\n" + it.readText().take(900) } ?: "Egg $name $v has no readable report."
        }
        else -> ""
    }
    private fun propose(id: String, text: String, why: String): String {
        val dir = File(mem, "PROPOSALS").apply { mkdirs() }
        val body = JSONObject().put("schema", "rzl.batibabox.proposal.v1").put("organ", "rzl.organ.batibabox.v1").put("version", "2.1.7")
            .put("host", host).put("adapter", "android-kotlin").put("action", id).put("why", why).put("request", text.take(400))
            .put("decider", spec.optString("decider")).put("state", "awaiting-decider").put("executed", false).put("ts", iso()).toString(1)
        val pid = "${stamp()}-$host-bbx-${sha(body.toByteArray()).take(8)}"
        File(dir, "$pid.json").writeText(body)   // relayed to the Neo Decider queue by the bridge/egg-ping lane; never executed here
        return pid
    }
    private fun logAction(r: JSONObject) {
        val f = File(mem, "BATIBABOX-ACTIONS.jsonl")
        val prev = f.takeIf { it.isFile }?.readLines()?.lastOrNull { it.isNotBlank() }?.let { sha(it.toByteArray()) } ?: ""
        f.appendText(r.put("prev", prev).put("ts", iso()).put("host", host).put("adapter", "android-kotlin").toString() + "\n")
    }
    fun turn(chat: String, text: String): Result {
        val (ctx, topic) = context(chat); val i = intent(text)
        remember(chat, "user", text, i)
        if (i == "chat") clarify(text, topic)?.let { q -> remember(chat, "bot", q, "clarify"); return Result("clarify", "none", q, null, ctx) }
        val a = actions.optJSONObject(i); val gate = a?.optString("gate") ?: "none"
        var out = ""; var pid: String? = null
        when (gate) {
            "read" -> out = runRead(i, text)
            "decider" -> { pid = propose(i, text, a?.optString("why") ?: ""); out = "That needs Rizal's approval. I made Decider proposal $pid; nothing ran." }
            else -> recall(text + " " + topic.joinToString(" ")).takeIf { it.isNotEmpty() }?.let { out = "memory: $it" }
        }
        if (gate != "none") logAction(JSONObject().put("action", i).put("gate", gate).put("proposal", pid ?: "").put("executed", gate == "read").put("chat", chat).put("out_sha256", sha(out.toByteArray())))
        val shown = ridFilter(out, text); if (shown.isNotEmpty()) remember(chat, "bot", shown, i)
        return Result(i, gate, shown, pid, persona() + "\n" + ctx)
    }

    /** ONLINE: run off the main thread. Returns a summary; caches verified items in filesDir/batibabox/FEED-CACHE.json. */
    fun sync(feed: String = "https://rizal.info/$host/appcast.json"): String = try {
        val c = (URL(feed).openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 12000 }
        val doc = JSONObject(c.inputStream.bufferedReader().readText())
        val pk = Base64.decode(EggIntake.PUBLIC_KEY_B64, Base64.DEFAULT)
        val keep = JSONArray(); var ok = 0; var bad = 0
        for (k in listOf("eggs", "items")) doc.optJSONArray(k)?.let { a -> for (n in 0 until a.length()) { val e = a.getJSONObject(n)
            val msg = "rlab-update-v1\n${e.optString("kind", "egg")}\n${e.optString("id")}\n${e.optString("version")}\n${e.optString("name")}\n${e.optLong("size")}\n${e.optString("sha256").lowercase()}"
            val sig = runCatching { Base64.decode(e.optString("ed25519"), Base64.DEFAULT) }.getOrNull()
            if (sig != null && Ed25519Verify.verify(pk, msg.toByteArray(), sig)) { ok++; keep.put(JSONObject().put("id", e.optString("id")).put("version", e.optString("version")).put("sha256", e.optString("sha256"))) } else bad++ } }
        File(mem, "FEED-CACHE.json").writeText(JSONObject().put("feed", feed).put("at", iso()).put("verified", keep).put("unverified", bad).toString(1))
        "$ok signature-verified · $bad unverified · cached"
    } catch (t: Throwable) { "offline: ${t.javaClass.simpleName}" }
}
