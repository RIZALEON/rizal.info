// BATIBABOX-SKILLS 2.1.7 · conversation + operational-action skills for rzl.organ.batibabox.v1 (macOS/iOS/iPadOS).
// Foundation + CryptoKit only. Reads BATIBABOX-SKILLS.rzl (shared spec, same as the Android Kotlin and Linux Go adapters).
// Read-only actions run directly; gated actions only write a Decider proposal. Every action is logged to a chained jsonl.
import Foundation
import CryptoKit

public final class BATIBABOXSkills {
  public struct Turn { public let intent: String; public let gate: String; public let output: String; public let proposal: String?; public let clarify: String?; public let context: String }
  let lab: URL, host: String, spec: [String: Any]
  let fm = FileManager.default
  public init(lab: URL, host: String, spec: URL) throws {
    self.lab = lab; self.host = host
    self.spec = try JSONSerialization.jsonObject(with: Data(contentsOf: spec)) as? [String: Any] ?? [:]
  }
  static func sha(_ d: Data) -> String { SHA256.hash(data: d).map { String(format: "%02x", $0) }.joined() }
  static func iso() -> String { ISO8601DateFormatter().string(from: Date()) }
  var conv: [String: Any] { spec["conversation"] as? [String: Any] ?? [:] }
  var actions: [String: [String: Any]] { spec["actions"] as? [String: [String: Any]] ?? [:] }

  // MARK: intent
  public func intent(_ text: String) -> String {
    let t = text.lowercased(); var best = ("chat", 0)
    if t.hasPrefix("recall ") || t.hasPrefix("/recall ") { return "recall" }
    for i in spec["intents"] as? [[String: Any]] ?? [] {
      for k in i["kw"] as? [String] ?? [] where t.contains(k) && k.count > best.1 { best = (i["id"] as! String, k.count) }
    }
    return best.0
  }
  // MARK: per-chat memory
  func chatFile(_ chat: String) -> URL {
    let d = lab.appendingPathComponent("MACHINE-MIND/DIGEST/CHAT/\(host)", isDirectory: true)
    try? fm.createDirectory(at: d, withIntermediateDirectories: true)
    return d.appendingPathComponent(chat.filter { $0.isLetter || $0.isNumber || $0 == "-" } + ".jsonl")
  }
  func turns(_ chat: String) -> [[String: Any]] {
    guard let s = try? String(contentsOf: chatFile(chat), encoding: .utf8) else { return [] }
    return s.split(separator: "\n").compactMap { try? JSONSerialization.jsonObject(with: Data($0.utf8)) as? [String: Any] }
  }
  func remember(_ chat: String, _ role: String, _ text: String, _ intent: String) {
    let o: [String: Any] = ["ts": Self.iso(), "role": role, "text": String(text.prefix(800)), "intent": intent]
    guard let d = try? JSONSerialization.data(withJSONObject: o, options: [.sortedKeys]) else { return }
    let u = chatFile(chat)
    if !fm.fileExists(atPath: u.path) { fm.createFile(atPath: u.path, contents: nil) }
    if let h = try? FileHandle(forWritingTo: u) { h.seekToEndOfFile(); h.write(d + Data("\n".utf8)); try? h.close() }
  }
  static let stop: Set<String> = Set("a an the what which who is are was were be to of in on for and or how why it its this that with by from as at do does did me my you your i we our can please now".split(separator: " ").map(String.init))
  static func words(_ s: String) -> [String] { s.lowercased().split { !($0.isLetter || $0.isNumber || $0 == "-") }.map(String.init).filter { $0.count > 2 && !stop.contains($0) } }
  /// context block: older turns folded into a keyword digest, last N turns verbatim.
  public func context(_ chat: String) -> (block: String, topic: [String]) {
    let all = turns(chat), n = conv["contextTurns"] as? Int ?? 6
    let recent = all.suffix(n), older = all.dropLast(min(n, all.count))
    var freq: [String: Int] = [:]; for t in older { for w in Self.words(t["text"] as? String ?? "") { freq[w, default: 0] += 1 } }
    let digest = freq.sorted { $0.value > $1.value }.prefix(10).map(\.key)
    var tf: [String: Int] = [:]; for t in recent where (t["role"] as? String) == "user" { for w in Self.words(t["text"] as? String ?? "") { tf[w, default: 0] += 1 } }
    let topic = tf.sorted { $0.value > $1.value }.prefix(5).map(\.key)
    var b = "CHAT MEMORY (\(all.count) turns)"
    if !digest.isEmpty { b += "\nearlier topics: " + digest.joined(separator: ", ") }
    for t in recent { b += "\n\(t["role"] as? String ?? "?"): \(String((t["text"] as? String ?? "").prefix(240)))" }
    return (b, topic)
  }
  public func clarifyQuestion(_ text: String, topic: [String]) -> String? {
    let c = conv["clarify"] as? [String: Any] ?? [:], min = c["minWords"] as? Int ?? 3
    let ws = text.lowercased().split { !$0.isLetter }.map(String.init)
    let vague = (c["vague"] as? [String] ?? []).contains { v in v.contains(" ") ? text.lowercased().contains(v) : ws.contains(v) }
    if ws.count < min && vague && topic.isEmpty { return "Which thing do you mean? Tell me the app, egg or device and I'll take it from there." }
    return nil
  }
  public func ridFilter(_ reply: String, user: String) -> String {
    let asked = (conv["ridAsk"] as? [String] ?? []).contains { user.lowercased().contains($0.lowercased()) }
    if asked { return reply }
    return reply.replacingOccurrences(of: "ЯID-[0-9]{4}-[0-9A-Z]{4}", with: "[ЯID hidden]", options: .regularExpression)
  }
  public func persona() -> String {
    let p = (spec["personas"] as? [String: [String: String]])?[host] ?? [:]
    let rules = (conv["rules"] as? [String] ?? []).map { "- " + $0 }.joined(separator: "\n")
    return "You are \(p["name"] ?? host): \(p["voice"] ?? "helpful lab bot").\nRULES:\n\(rules)"
  }

  // MARK: machine-mind link
  public func mindStatus() -> String {
    let a = (try? JSONSerialization.jsonObject(with: Data(contentsOf: lab.appendingPathComponent("EGGS/ACTIVE/\(host)/machine-mind.json")))) as? [String: Any] ?? [:]
    let seated = ((try? fm.contentsOfDirectory(atPath: lab.appendingPathComponent("EGGS/SEATED/machine-mind").path)) ?? []).sorted()
    return "machine-mind ACTIVE \(a["active"] ?? "?") (\(a["flavor"] ?? "?"), sha \(String((a["sha256"] as? String ?? "").prefix(12)))) · SEATED: \(seated.joined(separator: ",")) · history: \((a["history"] as? [String] ?? []).joined(separator: ","))"
  }
  // MARK: recall (keyword + exact ЯID; app path adds BATIBABOX vectors)
  public func recall(_ q: String) -> String {
    let a = (try? JSONSerialization.jsonObject(with: Data(contentsOf: lab.appendingPathComponent("EGGS/ACTIVE/\(host)/machine-mind.json")))) as? [String: Any] ?? [:]
    let v = a["active"] as? String ?? "", sha = String((a["sha256"] as? String ?? "").prefix(16))
    let doc = lab.appendingPathComponent("EGGS/SEATED/machine-mind/\(v)/MACHINE-MIND-UNIFIED.md")
    guard let fh = try? FileHandle(forReadingFrom: doc) else { return "" }
    defer { try? fh.close() }
    if let r = q.range(of: "ЯID-[0-9]{4}-[0-9A-Z]{4}", options: .regularExpression), let s = try? String(contentsOf: doc, encoding: .utf8) {
      let id = String(q[r]); let hits = s.split(separator: "\n").filter { $0.contains(id) }.prefix(3)
      return hits.isEmpty ? "" : hits.joined(separator: "\n")
    }
    let idxURL = lab.appendingPathComponent("MACHINE-MIND/DIGEST/index-\(host)-\(v)-\(sha).rzl")
    let idx = (try? JSONSerialization.jsonObject(with: Data(contentsOf: idxURL))) as? [[String: Any]] ?? []
    let qw = Set(Self.words(q)); guard !qw.isEmpty else { return "" }
    var scored: [(Int, Int)] = []
    for (i, e) in idx.enumerated() { let hw = Set(Self.words(e["h"] as? String ?? "")); let s = qw.intersection(hw).count; if s > 0 { scored.append((s, i)) } }
    scored.sort { $0.0 > $1.0 }
    var parts: [String] = []
    for (_, i) in scored.prefix(2) {
      let o = (idx[i]["o"] as? NSNumber)?.uint64Value ?? 0; try? fh.seek(toOffset: o)
      parts.append(String(decoding: fh.readData(ofLength: 600), as: UTF8.self))
    }
    return parts.joined(separator: "\n…\n")
  }
  // MARK: read-only actions
  func readText(_ rel: String) -> String { (try? String(contentsOf: lab.appendingPathComponent(rel), encoding: .utf8)) ?? "" }
  func newest(_ dir: String, prefix: String) -> String? {
    ((try? fm.contentsOfDirectory(atPath: lab.appendingPathComponent(dir).path)) ?? []).filter { $0.hasPrefix(prefix) && $0.hasSuffix(".md") }.sorted().last
  }
  func runRead(_ id: String, _ text: String) -> String {
    switch id {
    case "recall": let r = recall(text.replacingOccurrences(of: "recall", with: "")); return r.isEmpty ? "I don't know: recall found nothing." : r
    case "mind.status": return mindStatus()
    case "spong.report":
      guard let f = newest("RNETWORK", prefix: "SPONG-RUN-") else { return "No SPONG report on this device." }
      return f + "\n" + String(readText("RNETWORK/" + f).prefix(900))
    case "egg.list", "egg.status":
      let d = "EGGS/ACTIVE/\(host)"; var out: [String] = []
      for f in ((try? fm.contentsOfDirectory(atPath: lab.appendingPathComponent(d).path)) ?? []).sorted() where f.hasSuffix(".json") {
        let o = (try? JSONSerialization.jsonObject(with: Data(contentsOf: lab.appendingPathComponent(d + "/" + f)))) as? [String: Any] ?? [:]
        let name = String(f.dropLast(5)); if id == "egg.status" && !text.lowercased().contains(name) { continue }
        out.append("\(name) \(o["active"] ?? o["version"] ?? "?")")
      }
      return out.isEmpty ? "No matching ACTIVE egg." : out.joined(separator: " · ")
    case "ghostchain.read":
      let lines = readText("EGGS/GHOSTCHAIN.jsonl").split(separator: "\n").suffix(5)
      return lines.compactMap { l -> String? in
        guard let o = try? JSONSerialization.jsonObject(with: Data(l.utf8)) as? [String: Any] else { return nil }
        return "#\(o["seq"] ?? "?") \(o["event"] ?? "") \(o["id"] ?? "") \(o["ts"] ?? "")" }.joined(separator: "\n")
    case "lesson.read":
      let ls = ((try? fm.contentsOfDirectory(atPath: lab.appendingPathComponent("ЯKLASSROOM/LESSONS").path)) ?? []).sorted()
      if let r = text.range(of: "L[0-9]{3}", options: .regularExpression), let f = ls.first(where: { $0.hasPrefix(String(text[r])) }) { return f + "\n" + String(readText("ЯKLASSROOM/LESSONS/" + f).prefix(900)) }
      return "\(ls.count) lessons; newest: " + ls.suffix(3).joined(separator: ", ")
    case "rweb.read":
      guard let f = newest("RNETWORK", prefix: "RNETWORK-MAP-") else { return "No RWEB map here." }
      return f + ": " + readText("RNETWORK/" + f).split(separator: "\n").filter { $0.hasPrefix("#") }.prefix(12).joined(separator: " | ")
    case "xfiles.read": let x = readText("RNETWORK/XFILES.md"); return x.isEmpty ? "No XFILE list here." : String(x.prefix(900))
    default: return ""
    }
  }
  // MARK: Decider proposal (never executes)
  func propose(_ id: String, _ text: String, why: String) -> String {
    let dir = lab.appendingPathComponent("PLUGINS/SUPERGROK-BRIDGE/PROPOSALS", isDirectory: true)
    try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
    let body: [String: Any] = ["schema": "rzl.batibabox.proposal.v1", "organ": "rzl.organ.batibabox.v1", "version": "2.1.7", "host": host,
      "action": id, "why": why, "request": String(text.prefix(400)), "decider": spec["decider"] as? String ?? "", "state": "awaiting-decider",
      "executed": false, "ts": Self.iso()]
    let d = (try? JSONSerialization.data(withJSONObject: body, options: [.sortedKeys, .prettyPrinted])) ?? Data()
    let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmm"
    let pid = "\(f.string(from: Date()))-\(host)-bbx-\(Self.sha(d).prefix(8))"
    try? d.write(to: dir.appendingPathComponent(pid + ".json"))
    return pid
  }
  func logAction(_ rec: [String: Any]) {
    let u = lab.appendingPathComponent("MACHINE-MIND/DIGEST/BATIBABOX-ACTIONS.jsonl")
    let prevLine = ((try? String(contentsOf: u, encoding: .utf8)) ?? "").split(separator: "\n").last.map(String.init) ?? ""
    var r = rec; r["prev"] = prevLine.isEmpty ? "" : Self.sha(Data(prevLine.utf8)); r["ts"] = Self.iso(); r["host"] = host; r["adapter"] = "swift"
    guard let d = try? JSONSerialization.data(withJSONObject: r, options: [.sortedKeys]) else { return }
    if !fm.fileExists(atPath: u.path) { fm.createFile(atPath: u.path, contents: nil) }
    if let h = try? FileHandle(forWritingTo: u) { h.seekToEndOfFile(); h.write(d + Data("\n".utf8)); try? h.close() }
  }
  // MARK: one turn
  public func turn(chat: String, _ text: String) -> Turn {
    let ctx = context(chat); let i = intent(text)
    remember(chat, "user", text, i)
    if i == "chat", let q = clarifyQuestion(text, topic: ctx.topic) {
      remember(chat, "bot", q, "clarify"); return Turn(intent: "clarify", gate: "none", output: q, proposal: nil, clarify: q, context: ctx.block)
    }
    let a = actions[i]; let gate = a?["gate"] as? String ?? "none"
    var out = "", pid: String? = nil
    if gate == "read" { out = runRead(i, text) }
    else if gate == "none" { let m = recall(text + " " + ctx.topic.joined(separator: " ")); out = m.isEmpty ? "" : "memory: " + m }
    else if gate == "decider" { pid = propose(i, text, why: a?["why"] as? String ?? ""); out = "That needs Rizal's approval. I made Decider proposal \(pid!); nothing ran." }
    if gate != "none" { logAction(["action": i, "gate": gate, "proposal": pid ?? "", "executed": gate == "read", "chat": chat, "out_sha256": Self.sha(Data(out.utf8))]) }
    let shown = ridFilter(out, user: text)
    if !shown.isEmpty { remember(chat, "bot", shown, i) }
    return Turn(intent: i, gate: gate, output: shown, proposal: pid, clarify: nil, context: persona() + "\n" + ctx.block)
  }
}
