window.SPONG_EGG={id:"spong",version:"0.0.2",staged:"2026-10-15",signed:false};
