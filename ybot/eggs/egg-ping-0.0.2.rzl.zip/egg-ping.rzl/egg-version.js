window.EGG_PING={id:"egg-ping",version:"0.0.2",note:"no-op test egg"};
