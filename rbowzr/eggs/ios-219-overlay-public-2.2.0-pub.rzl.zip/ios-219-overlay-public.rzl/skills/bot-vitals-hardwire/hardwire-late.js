/* hardwire-late.js · bot-vitals-hardwire 2.1.9.3 (late piece, loads after every other overlay skill) · ЯBOWZR overlay · 2026-10-16 MT
 * 1) GHOST CHAIN: every Heart call (rosHeart.postMessage, whoever calls it: botwin, chatlist, notes-reader, scout-app) appends one
 *    hash-chained record {schema rzl-ghostchain-heart.v1}. Sinks: the host transcript (ns "ghostchain") and, when paired, the Mac
 *    Botbridge POST /v1/ghostchain (staged runtime patch) which appends it to ~/data Only hashes,
 *    sizes, ЯID, name, mouth and timing are recorded — never prompt/reply text, never tokens.
 * 2) BATIBABOX: rids are canonicalized through the alias map, so BOT (ЯID-pending) sees its 61 chunks filed under
 *    bot:LOCAL-9SJ1-4JPK. Read-only; no data moves.
 * 3) ЯSCRIBE: per-seat notes — every ЯSCRIBE save (RL_NOTES_SAVE hook of rscribe-web 0.2) is stamped with the open bot's ЯID + name
 *    into the transcript (ns "notes", bot "<ЯID> · <name>") so the BATIBABOX index files it under that seat; a per-seat index is kept
 *    in localStorage (rl.rscribe.seat.<ЯID>). Never throws. Deletes nothing. */
(function () {
  "use strict";
  if (window.RL_HARDWIRE_LATE) return;
  const HW = window.RL_HARDWIRE || { canon: (x) => x, seats: {}, version: "2.1.9.3" };
  const mh = () => (window.webkit && window.webkit.messageHandlers) || {};
  function who() { try { if (window.RL_IDGUARD && window.RL_IDGUARD.who) { const M = window.RL_IDGUARD.who(); if (M) return M; } } catch (e) {}
    try { const c = window.ROS_CURRENT && window.ROS_CURRENT(); if (c && c.rid) { const rid = HW.canon(c.rid); return { rid, name: (HW.seats[rid] || {}).name || c.name || "" }; } } catch (e) {}
    return null; }
  // ---- sha256 (WebCrypto when present, pure-JS fallback so file:// pages still chain) ----
  function sha256js(str) {
    const b = new TextEncoder().encode(str), K = []; let H = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    for (let i = 0, n = 2, c = 0; c < 64; n++) { let p = true; for (let d = 2; d * d <= n; d++) if (n % d === 0) { p = false; break; } if (p) { K[c++] = (Math.pow(n, 1 / 3) % 1) * 4294967296 | 0; } }
    const l = b.length, w = new Uint8Array(((l + 9 + 63) >> 6) << 6); w.set(b); w[l] = 0x80; const dv = new DataView(w.buffer); dv.setUint32(w.length - 4, l * 8); dv.setUint32(w.length - 8, Math.floor(l / 536870912));
    const r = (x, n) => (x >>> n) | (x << (32 - n)), W = new Uint32Array(64);
    for (let o = 0; o < w.length; o += 64) { for (let i = 0; i < 16; i++) W[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) { const s0 = r(W[i - 15], 7) ^ r(W[i - 15], 18) ^ (W[i - 15] >>> 3), s1 = r(W[i - 2], 17) ^ r(W[i - 2], 19) ^ (W[i - 2] >>> 10); W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0; }
      let [a, bb, c, d, e, f, g, h] = H;
      for (let i = 0; i < 64; i++) { const t1 = (h + (r(e, 6) ^ r(e, 11) ^ r(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0, t2 = ((r(a, 2) ^ r(a, 13) ^ r(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0; }
      H = [H[0] + a, H[1] + bb, H[2] + c, H[3] + d, H[4] + e, H[5] + f, H[6] + g, H[7] + h].map((x) => x | 0); }
    return H.map((x) => (x >>> 0).toString(16).padStart(8, "0")).join("");
  }
  const sha = (s) => sha256js(String(s == null ? "" : s));
  // ---- Ghost Chain ----
  const GC_KEY = "rl.ghostchain.heart.head";
  let head = { seq: 0, sha: "" }; try { head = JSON.parse(localStorage.getItem(GC_KEY) || "null") || head; } catch (e) {}
  const GC = (window.RL_GHOSTCHAIN_LOG = window.RL_GHOSTCHAIN_LOG || []);
  function chain(ev) {
    const M = who(); const seat = M ? HW.seats[M.rid] || {} : {};
    const rec = Object.assign({ schema: "rzl-ghostchain-heart.v1", event: "heart-call", seq: head.seq + 1, prev: head.sha, ts: new Date().toISOString(),
      host: "rbowzr", egg: "bot-vitals-hardwire", version: HW.version, rid: M ? M.rid : null, name: M ? M.name : null, mouth: seat.mouth || null }, ev);
    rec.sha256 = sha(JSON.stringify(rec)); head = { seq: rec.seq, sha: rec.sha256 }; try { localStorage.setItem(GC_KEY, JSON.stringify(head)); } catch (e) {}
    GC.push(rec);
    try { const t = mh().rosTranscript; t && t.postMessage({ cmd: "append", role: "system", ns: "ghostchain", text: "GHOSTCHAIN " + JSON.stringify(rec), bot: M ? `${M.rid} · ${M.name}` : undefined }); } catch (e) {}
    try { const rt = typeof botbridgeRoute === "function" ? botbridgeRoute() : null;
      if (rt && rt.url && typeof fetch === "function") { const h = { "content-type": "application/json" }; if (rt.token) h.authorization = "Bearer " + rt.token;
        fetch(rt.url + "/v1/ghostchain", { method: "POST", headers: h, body: JSON.stringify(rec), mode: "cors", credentials: "omit", cache: "no-store" }).catch(() => {}); } } catch (e) {}
    return rec;
  }
  function wrapHeart() {
    const h = mh().rosHeart; if (!h || h.__rlHardwire) return !!h;
    const orig = h.postMessage;
    if (typeof orig !== "function") return false;
    const wrapped = async function (msg) {
      const t0 = Date.now(); const p = String((msg && msg.prompt) || "");
      try { const r = await orig.call(h, msg); const txt = String((r && r.text) || "");
        chain({ ok: !!txt, promptSha256: sha(p), promptChars: p.length, replySha256: sha(txt), replyChars: txt.length, ms: Date.now() - t0, from: msg && msg.from ? String(msg.from).slice(0, 40) : null }); return r; }
      catch (e) { chain({ ok: false, promptSha256: sha(p), promptChars: p.length, error: String(e && e.message || e).slice(0, 120), ms: Date.now() - t0 }); throw e; }
    };
    try { h.postMessage = wrapped; } catch (e) {}
    if (h.postMessage !== wrapped) { try { Object.defineProperty(h, "postMessage", { value: wrapped, configurable: true, writable: true }); } catch (e) {} }
    const ok = h.postMessage === wrapped; if (ok) { try { Object.defineProperty(h, "__rlHardwire", { value: true }); } catch (e) {} }
    return ok;
  }
  // ---- BATIBABOX alias resolution (read-only) ----
  function wrapBbx() {
    const B = window.RL_BBX; if (!B || B.__rlHardwire) return !!B;
    const s0 = B.search, c0 = B.context;
    B.search = (q, opt) => s0(q, Object.assign({}, opt || {}, { rid: HW.canon((opt || {}).rid || "") }));
    B.context = (q, rid, budget) => c0(q, HW.canon(rid), budget);
    B.__rlHardwire = true; return true;
  }
  // ---- ЯSCRIBE per-seat notes ----
  const prevSave = window.RL_NOTES_SAVE;
  window.RL_NOTES_SAVE = function (name, rev, text) {
    try { if (typeof prevSave === "function") prevSave(name, rev, text); } catch (e) {}
    const M = who(); if (!M) return;
    const line = `ЯSCRIBE note ${name} rev ${rev} · ${M.rid} · ${M.name} · ${String(text || "").replace(/\s+/g, " ").slice(0, 160)}`;
    try { const t = mh().rosTranscript; t && t.postMessage({ cmd: "append", role: "system", ns: "notes", rid: M.rid, bot: `${M.rid} · ${M.name}`, text: line }); } catch (e) {}
    try { const k = "rl.rscribe.seat." + M.rid; const ix = JSON.parse(localStorage.getItem(k) || "[]"); ix.push({ name, rev, at: new Date().toISOString(), sha256: sha(text) }); localStorage.setItem(k, JSON.stringify(ix.slice(-500))); } catch (e) {}
  };
  const status = () => ({ version: HW.version, heartWrapped: !!(mh().rosHeart && mh().rosHeart.__rlHardwire), bbxAlias: !!(window.RL_BBX && window.RL_BBX.__rlHardwire),
    rscribeSeat: typeof window.RL_NOTES_SAVE === "function", ghostchainHead: head, seats: Object.keys(HW.seats).length });
  function boot() { wrapHeart(); wrapBbx(); }
  boot(); setTimeout(boot, 1500); setTimeout(boot, 5000);
  window.RL_HARDWIRE_LATE = { chain, sha256: sha, wrapHeart, wrapBbx, status };
})();
