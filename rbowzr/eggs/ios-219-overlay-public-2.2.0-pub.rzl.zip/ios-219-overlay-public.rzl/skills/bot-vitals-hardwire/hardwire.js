/* hardwire.js · bot-vitals-hardwire 2.1.9.3 (early piece, loads right after rid-roster.js) · ЯBOWZR overlay · 2026-10-16 MT
 * HARDCODE RULE (Rizal 2026-10-16): every bot seat on the roster — current or added later — is a FULL, CALLABLE bot by default,
 * wired to all vitals: Heart (via the mouth relay), Botbridge entry, identity guard, BATIBABOX, ЯSCRIBE, Ghost Chain, THUNDR.
 * A seat is receive-only ONLY if its row says so explicitly (state "receiver-only"/"receive-only" or receiveOnly:true).
 * Egg-only · no network · deletes nothing · the ЯID stays the only authoritative key (never edited). */
(function () {
  "use strict";
  if (window.RL_HARDWIRE) return;
  const VERSION = "2.1.9.3";
  const VITALS = ["heart", "mouth", "botbridge", "identity-guard", "batibabox", "rscribe", "ghostchain", "thundr"];
  const CANON = /^ЯID-\d{4}-[0-9A-Z]{4}$/;
  const RECV = /^(receiver-only|receive-only|receiveonly)$/i;
  const HOLD = /^(human|retired|rebuild-later|group|bridge)$/i;   // explicit non-bot / parked states are left as they are
  const fold = (s) => (window.ROS_FOLD ? window.ROS_FOLD(s) : String(s || "").toUpperCase());
  const mouthFor = (r) => "ya" + fold(r.rosterName || r.name || r.id).replace(/^[ЯR]/, "").replace(/[^A-Z0-9]/g, "").toLowerCase();
  const L = window.ROS_RID_LIST || { rows: [] };
  const seats = {}, alias = {};
  (L.rows || []).forEach((r) => {
    if (!r || r.kind !== "bot" || !CANON.test(String(r.rid || ""))) return;
    const st = String(r.state || "").trim();
    const recv = RECV.test(st) || r.receiveOnly === true;
    if (!recv && !HOLD.test(st)) {
      if (st.toLowerCase() !== "callable") { r.formerState = r.formerState || st || "(none)"; r.state = "callable"; }
      if (!r.mouth) r.mouth = mouthFor(r);
      r.vitals = VITALS.slice();
      r.hardwired = r.hardwired || "bot-vitals-hardwire " + VERSION;
    } else if (recv) { r.vitals = ["identity-guard", "batibabox", "rscribe", "ghostchain", "thundr"]; }
    (r.aliasIds || r.formerIds || []).forEach((a) => { if (a && !CANON.test(a)) alias[a] = r.rid; });
    seats[r.rid] = { rid: r.rid, name: r.rosterName || r.name, state: r.state, mouth: r.mouth || null, outside: !!r.outside, vitals: r.vitals || [] };
  });
  const canon = (rid) => { const k = String(rid || ""); const A = Object.assign({}, alias, window.ROS_RID_ALIAS || {}); return A[k] || k; };
  function vitals(rid) { const s = seats[canon(rid)]; return s ? s.vitals.slice() : []; }
  function callable(rid) { const s = seats[canon(rid)]; return !!(s && s.state === "callable" && s.mouth); }
  // Botbridge entries the app can show/join (mirrors the staged registry.json patch; the Mac Botbridge stays the source of record)
  function botbridgePeers() {
    return Object.values(seats).filter((s) => s.state === "callable" && s.mouth).map((s) => ({
      id: s.outside ? s.mouth : "mouth-seat-" + s.mouth, name: s.name + (s.outside ? " (outside bot)" : " mouth seat"),
      kind: s.outside ? "outside-bot" : "mouth-seat", mouthId: s.mouth, seat: s.rid }));
  }
  window.RL_HARDWIRE = { version: VERSION, VITALS, seats, alias, canon, vitals, callable, botbridgePeers, mouthFor };
})();
