/* RZL EGG CONVERT skill (2.1.9.15) - page-side half of ~/data
   Packs a confirmed change set (paths relative to the base egg + content, any type as base64) into rzl.eggmod.v1 JSON that host converts,
   signs with the Keychain key and injects. Signing never happens here; the page holds no key or token. */
(function () {
  if (window.RZL_EGG_CONVERT) return;
  const KEY = "rzl-eggmod-queue";
  function b64(s) { return btoa(unescape(encodeURIComponent(s))); }
  function request(files, note) {
    const mod = { schema: "rzl.eggmod.v1", base: "ios-219-superdragon", at: new Date().toISOString(), note: String(note || ""),
      files: (files || []).map((f) => ({ path: String(f.path), b64: f.b64 || b64(String(f.text || "")) })) };
    try { const q = JSON.parse(localStorage.getItem(KEY) || "[]"); q.push(mod); localStorage.setItem(KEY, JSON.stringify(q.slice(-20))); } catch (e) {}
    return mod;
  }
  window.RZL_EGG_CONVERT = { version: "0.1.0", request, queue: () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; } } };
})();
