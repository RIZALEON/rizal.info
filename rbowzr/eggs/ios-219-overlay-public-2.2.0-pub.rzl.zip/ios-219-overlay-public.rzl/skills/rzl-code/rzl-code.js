/* RZL CODE (2.1.9.15) - mainline coding from the bar/composer.
   /code <ask> · /fix <ask> · /egg <ask>  (bar: /fix natively arrives here as "FIX <ask>"; /code and /egg are typed in the composer).
   Opens a page-land coding panel, logs the request, forwards it to the current bot through ROS_SEND (Botbridge / mouth relay).
   Bots answer with changed files or a patch; the user confirms in the panel; host converts it with rzl-egg-convert.sh (Keychain key, never in the page)
   and pushes it with rzl-inject.sh. The page holds no token. Every action is logged (localStorage rzl-code-log, window.RZL_CODE.log). */
(function () {
  "use strict";
  if (window.RZL_CODE) return;
  const V = "0.2.0", KEY = "rzl-code-log", RX = /^\s*\/?(code|fix|egg)\b[:\s]*([\s\S]*)$/i;
  const log = (ev, o) => { const e = Object.assign({ at: new Date().toISOString(), ev }, o || {});
    try { const a = JSON.parse(localStorage.getItem(KEY) || "[]"); a.push(e); localStorage.setItem(KEY, JSON.stringify(a.slice(-300))); } catch (x) {}
    try { window.webkit && webkit.messageHandlers && webkit.messageHandlers.rosHeart && 0; } catch (x) {} return e; };
  let panel, list, reqs = [];
  function css() { if (document.getElementById("rzl-code-css")) return; const s = document.createElement("style"); s.id = "rzl-code-css";
    s.textContent = "#rzl-code{position:fixed;left:8px;right:8px;bottom:calc(env(safe-area-inset-bottom) + 70px);max-height:46vh;overflow:auto;z-index:2147481000;" +
      "background:#120e14;border:1px solid #ff7a1a;border-radius:10px;color:#eee;font:12px ui-monospace,Menlo,monospace;padding:8px}" +
      "#rzl-code h4{margin:0 0 6px;color:#ff7a1a;font:700 12px system-ui}#rzl-code .rq{border-top:1px solid #333;padding:6px 0}" +
      "#rzl-code button{background:#ff7a1a;color:#120e14;border:0;border-radius:6px;font:700 11px system-ui;padding:4px 8px;margin:4px 4px 0 0}" +
      "#rzl-code .x{position:absolute;right:8px;top:6px;background:none;color:#aaa}"; document.head.appendChild(s); }
  function show() { css(); if (panel && panel.isConnected) return; panel = document.createElement("div"); panel.id = "rzl-code";
    panel.innerHTML = '<h4>RZL CODE · requests to bots · fixes come back as eggs</h4><button class="x" aria-label="Close">✕</button><div class="l"></div>';
    panel.querySelector(".x").onclick = () => { panel.remove(); log("panel-close"); }; list = panel.querySelector(".l"); document.body.appendChild(panel); draw(); }
  function draw() { if (!list) return; list.innerHTML = "";
    reqs.slice().reverse().forEach((r) => { const d = document.createElement("div"); d.className = "rq";
      d.textContent = "[" + r.kind.toUpperCase() + "] " + r.ask + " · " + r.state; if (r.state === "answered") { const b = document.createElement("button");
        b.textContent = "Confirm → convert to egg on host"; b.onclick = () => { r.state = "confirmed"; log("confirm", { id: r.id }); draw(); }; d.append(document.createElement("br"), b); }
      list.append(d); }); }
  function handle(kind, ask, orig) { kind = kind.toLowerCase(); const r = { id: "RC-" + Date.now().toString(36), kind, ask: ask.trim() || "(no text)", state: "sent" };
    reqs.push(r); log("request", { id: r.id, kind, ask: r.ask }); show(); draw();
    const msg = "RZL " + kind.toUpperCase() + " REQUEST " + r.id + ": " + r.ask + "\nReply with the changed files (full content, with paths relative to the 2.1.9.x base egg) or a unified diff. Do not include tokens or keys.";
    try { orig(msg); } catch (e) { r.state = "send failed"; log("send-fail", { id: r.id, err: String(e) }); draw(); } }
  function wrap() { const S = window.ROS_SEND; if (typeof S !== "function" || S.__rc) return;
    const w = function (t) { const m = RX.exec(String(t == null ? "" : t)); if (m && !/^\s*RZL /.test(t)) return handle(m[1], m[2], (x) => S.call(this, x)); return S.apply(this, arguments); };
    w.__rc = 1; w.__sd = S.__sd; window.ROS_SEND = w; }
  function hookComposer() { const f = document.querySelector("#composer"), i = document.querySelector("#message"); if (!f || !i || f.__rc) return; f.__rc = 1;
    f.addEventListener("submit", (e) => { const m = RX.exec(i.value || ""); if (!m || !/^\s*\//.test(i.value)) return;
      e.preventDefault(); e.stopImmediatePropagation(); const v = i.value; i.value = ""; handle(m[1], m[2], (x) => (window.ROS_SEND.__rc ? window.ROS_SEND : window.ROS_SEND)(x)); log("composer", { chars: v.length }); }, true); }
  function watchReplies() { try { new MutationObserver(() => { const open = reqs.filter((r) => r.state === "sent"); if (!open.length) return;
    const txt = (document.querySelector("#thread") || document.body).innerText || ""; open.forEach((r) => { if (txt.lastIndexOf(r.id) !== txt.indexOf(r.id) || /```|^\+\+\+ /m.test(txt.slice(txt.indexOf(r.id)))) { r.state = "answered"; log("answered", { id: r.id }); draw(); } }); })
    .observe(document.body, { childList: true, subtree: true }); } catch (e) {} }
  let n = 0; const iv = setInterval(() => { wrap(); hookComposer(); if (++n > 60) clearInterval(iv); }, 500);
  document.addEventListener("DOMContentLoaded", () => { wrap(); hookComposer(); watchReplies(); });
  async function editBar(patch) { let cur = {}; try { cur = await (await fetch("./bar.json", { cache: "no-store" })).json(); } catch (e) {}
    const next = Object.assign({}, cur, patch || {}); const t = JSON.stringify(next, null, 2);
    const mod = window.RZL_EGG_CONVERT ? window.RZL_EGG_CONVERT.request([{ path: "bar.json", text: t }], "bar.json edit") : null;
    log("bar-edit", { keys: Object.keys(patch || {}) }); return { bar: next, queued: !!mod }; }
  window.RZL_CODE = { version: V, editBar, bar: () => fetch("./bar.json", { cache: "no-store" }).then((r) => r.json()), handle: (k, a) => handle(k, a, window.ROS_SEND), log: () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; } }, open: show };
  log("boot", { v: V });
})();
