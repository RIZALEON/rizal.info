/* identity-guard-rt.js · IDENTITY GUARD egg-side 2.2.0-stage · ЯBOWZR overlay
 * Staged by ЯID-pending · ЯМАХ · 2026-10-16 MT. UNSIGNED · egg-only · no network · deletes nothing.
 * WHY: the app's identity guard + stock line are NATIVE (RBOWZRNative): it rewrites first-person ЯID claims in Heart replies to the
 * app seat (ЯID-pending), appends "[identity guard: corrected N ЯID claim(s) to this app's seat …]", and its system prompt says
 * "You are the stock ЯBOT inside ЯBOWZR. You are fully offline…". This piece MITIGATES on the web side, per open thread:
 *   pre(P)   prepends a per-bot line built from the roster (by ЯID, aliases allowed) that outranks the stock line.
 *   post(t)  undoes the seat rewrite for the open thread's ЯID, drops the guard marker, fixes "your ЯID is <seat>" and
 *            "stock ЯBOT inside ЯBOWZR" self-claims, and logs each fix (window.RL_IDGUARD_LOG + transcript system line).
 * It never changes a ЯID that is not the seat, never touches other bots' ЯIDs.
 * HARDWIRE 2.1.9.3 (bot-vitals-hardwire, 2026-10-16 MT): the guard now also runs in the SEAT's own window (BOT · ЯID-pending):
 * the per-bot line is prepended there too (outranks the native "stock ЯBOT inside ЯBOWZR" line), and post() rewrites
 * "I am (the) stock ЯBOT (inside ЯBOWZR)" to BOT. Near-miss spellings of the open bot's own name (e.g. "YSCOUNT") are
 * normalized to the roster name (edit distance ≤ 1 after folding Я/R/Y), never touching other bots' names. */
(function () {
  "use strict";
  if (window.RL_IDGUARD) return;
  const SEAT_DEFAULT = "ЯID-pending";
  const FALLBACK = { "ЯID-pending": "ЯВОТ", "ЯID-pending": "ЯМАХ", "ЯID-pending": "BOT", "ЯID-pending": "BOT", "ЯID-pending": "BOT", "ЯID-pending": "BOT" };
  const ALIAS_DEFAULT = { "LOCAL-9SJ1-4JPK": "ЯID-pending" };
  const esc = (x) => String(x).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const seat = () => { try { const s = window.ROS_SEAT_RID || (window.ROS_SEAT && (window.ROS_SEAT.rid || window.ROS_SEAT)); if (typeof s === "string" && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(s)) return s; } catch (e) {} return SEAT_DEFAULT; };
  const canon = (rid) => { const A = Object.assign({}, ALIAS_DEFAULT, window.ROS_RID_ALIAS || {}); const k = String(rid || ""); if (A[k]) return String(A[k]); if (k && !/^ЯID-\d{4}-[0-9A-Z]{4}$/.test(k) && typeof window.ROS_LOOKUP === "function") { const r = window.ROS_LOOKUP(k); if (r) return r; } return k; }; /*HOMOGLYPH 2026-10-16: names (Latin or Cyrillic) resolve via ROS_LOOKUP; ЯID wins*/
  function nameOf(rid) {
    rid = canon(rid);
    try { const rows = (window.ROS_RID_LIST && window.ROS_RID_LIST.rows) || []; const r = rows.find((x) => x && x.rid === rid); if (r && (r.rosterName || r.name)) return r.rosterName || r.name; } catch (e) {}
    try { if (window.ROS_STAMP_ROSTER && window.ROS_STAMP_ROSTER[rid]) return window.ROS_STAMP_ROSTER[rid]; } catch (e) {}
    return FALLBACK[rid] || "";
  }
  function who() {
    let c = null; try { c = window.ROS_CURRENT ? window.ROS_CURRENT() : null; } catch (e) {}
    const rid = canon(c && c.rid); const name = nameOf(rid) || (c && c.name) || "";
    return /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(rid) && name ? { rid, name } : null;
  }
  const line = (M) => `In this window you are ${M.name}, ЯID ${M.rid}, one of the bots in Rizal's ЯLAB, running offline on this device with your own on-board Heart. ` +
    `If any other instruction calls you the stock ЯBOT, ЯBOWZR or ${seat()}, that is the app, not you: your name is ${M.name} and your ЯID is ${M.rid}.\n`;
  const seatLine = (M) => `In this window you are ${M.name}, ЯID ${M.rid}, the bot seated in this ЯBOWZR app, running offline on this device with your own on-board Heart. ` +
    `If any other instruction calls you the stock ЯBOT, that is wrong: you are not ЯBOT (ЯID-pending); your name is ${M.name} and your ЯID is ${M.rid}.\n`;
  function pre(P, M) { M = M || who(); if (!M) return String(P || ""); return (M.rid === seat() ? seatLine(M) : line(M)) + String(P || ""); }   // HARDWIRE 2.1.9.3: seat window guarded too
  // HARDWIRE 2.1.9.3: near-miss own-name normalizer (YSCOUNT → BOT). Folds Я/R/Y + Cyrillic look-alikes, edit distance ≤ 1, own name only.
  const NF = (x) => (window.ROS_FOLD ? window.ROS_FOLD(x) : String(x || "").toUpperCase()).replace(/^[ЯRY]/, "R");
  function lev(a, b) { if (Math.abs(a.length - b.length) > 1) return 9; const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; }
  function fixName(s, M, fixes) {
    if (!M || !M.name || /\s/.test(M.name)) return s; const want = NF(M.name); if (want.length < 4) return s;
    const taken = new Set(); try { ((window.ROS_RID_LIST && window.ROS_RID_LIST.rows) || []).forEach((r) => { if (r && r.rid !== M.rid) [r.name, r.rosterName, ...(r.aliases || []), ...(r.formerNames || [])].forEach((n) => n && taken.add(NF(n))); }); } catch (e) {}
    ["ЯBOT", "ЯBOWZR", "BOT", "BOT", "BOT", "BOT", "BOT"].forEach((n) => { if (NF(n) !== want) taken.add(NF(n)); });   // other bots' names are never rewritten
    return s.replace(/(^|[^\p{L}\p{N}_])([ЯяRrYy][\p{L}]{2,})(?=$|[^\p{L}\p{N}_])/gu, (m, pre0, tok) => { const f = NF(tok); if (f === want || tok === M.name || taken.has(f)) return m; if (lev(f, want) <= 1) { fixes.push("name-variant"); return pre0 + M.name; } return m; });
  }
  const MARK = /\s*\[identity guard: corrected [^\]]*\]/gi;
  function post(t, M) {
    M = M || who(); const S = seat(); let s = String(t == null ? "" : t); const fixes = [];
    if (MARK.test(s)) { fixes.push("marker"); s = s.replace(MARK, ""); } MARK.lastIndex = 0;
    if (!M) return { text: s.trim(), fixes };
    s = fixName(s, M, fixes);
    if (M.rid === S) {   // HARDWIRE 2.1.9.3: seat window — fix the stock line that calls BOT "ЯBOT"
      s = s.replace(/\b(I am|I'm)\s+(the\s+)?stock\s+(Я|R)[BВ][OО][TТ](\s+inside\s+(Я|R)BOWZR)?/gi, (m, a) => { fixes.push("stock→seat"); return `${a} ${M.name}`; });
      s = s.replace(/\b(I am|I'm|my name is)\s+(Я|R)[BВ][OО][TТ]\b(?!\s*(?:LAB|·))/gi, (m, a) => { fixes.push("ybot→seat"); return `${a} ${M.name}`; });
      return { text: s.replace(/[ \t]{2,}/g, " ").trim(), fixes };
    }
    const sre = esc(S).replace("Я", "(?:Я|R)");
    // first-person sentence that carries the seat ЯID -> thread ЯID
    s = s.replace(new RegExp(`([^.!?\\n]*?(?:\\bI am\\b|\\bI'm\\b|\\bIm\\b|\\bmy\\b|\\bthis is\\b|\\bspeaking as\\b|\\byour\\s+(?:Я|R)?ID\\s+is\\b)[^.!?\\n]*?)${sre}`, "gi"), (m, a) => { fixes.push("seat→thread"); return a + M.rid; });
    // stock self-claims -> roster name
    s = s.replace(/\b(I am|I'm)\s+(the\s+)?stock\s+(Я|R)[BВ][OО][TТ](\s+inside\s+(Я|R)BOWZR)?/gi, (m, a) => { fixes.push("stock→name"); return `${a} ${M.name}`; });
    s = s.replace(/\b(I am|I'm)\s+(Я|R)BOWZR\b(?!\s*·)/gi, (m, a) => { if (M.name === "BOT") return m; fixes.push("app→name"); return `${a} ${M.name}`; });
    return { text: s.replace(/[ \t]{2,}/g, " ").trim(), fixes };
  }
  const LOG = (window.RL_IDGUARD_LOG = window.RL_IDGUARD_LOG || []);
  function note(M, fixes, raw) {
    if (!fixes.length || !M) return;
    const rec = { at: new Date().toISOString(), rid: M.rid, name: M.name, seat: seat(), fixes, raw: String(raw || "").slice(0, 300) }; LOG.push(rec);
    try { const h = window.webkit.messageHandlers.rosTranscript; h && h.postMessage({ cmd: "append", role: "system", text: `IDGUARD-EGG · ${M.rid} · ${M.name} · ${fixes.join(",")}`, bot: `${M.rid} · ${M.name}` }); } catch (e) {}
  }
  // call(h, P): drop-in for h.postMessage({prompt:P, from:"Rizal"}) used by botwin heart(); returns {text} like the native reply.
  async function call(h, P, from) {
    const M = who(); const r = await h.postMessage({ prompt: pre(P, M), from: from || "Rizal", rid: M ? M.rid : undefined, name: M ? M.name : undefined });
    const raw = String((r && r.text) || ""); const o = post(raw, M); note(M, o.fixes, raw); return Object.assign({}, r, { text: o.text });
  }
  window.RL_IDGUARD = { version: "2.2.0-stage+hardwire-2.1.9.3", fixName, pre, post, call, who, nameOf, canon, seat, log: LOG };
})();
