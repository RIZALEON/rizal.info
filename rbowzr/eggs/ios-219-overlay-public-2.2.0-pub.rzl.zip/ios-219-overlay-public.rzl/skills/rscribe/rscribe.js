/* rscribe.js · ЯSCRIBE web skill 0.3 · 1:1 web port of the Mac native ЯSCRIBE (Shared/RScribe.swift: RScribeBody / Sidebar / Row /
 * Editor / Toolbar / FormatBar / Reader). Same layout, order, labels, colours (Theme.swift RZ), fonts and spacing.
 * Store unchanged: localStorage "rlab.rscribe.notes.v1" (rzl.doc.v1 revs + chain). Add-only: every save is a new rev, archive never erases.
 * 0.3 crash fixes: switching notes (NOTES ~8.7k chars ↔ short ↔ New note) snapshots the note before any await, saves are
 * serialized, caret/selection is clamped to the new text length. Offline only: no network. */
(function () {
  "use strict";
  if (typeof document === "undefined") return;
  if (window.RL_RSCRIBE) return;
  var DOC = window.RL_RSCRIBE_DOC;
  var LS = "rlab.rscribe.notes.v1";
  var FONTS = ["System", "New York", "SF Mono", "Helvetica Neue", "Avenir Next", "Georgia", "Menlo", "Courier New"];
  var FONTCSS = { "System": "-apple-system,system-ui,sans-serif", "New York": "ui-serif,'New York',Georgia,serif", "SF Mono": "ui-monospace,'SF Mono',Menlo,monospace",
    "Helvetica Neue": "'Helvetica Neue',Helvetica,sans-serif", "Avenir Next": "'Avenir Next',Avenir,sans-serif", "Georgia": "Georgia,serif", "Menlo": "Menlo,monospace", "Courier New": "'Courier New',Courier,monospace" };
  var SIZES = [11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36];
  var COLORS = [["default", "Default"], ["#F2EDE4", "Paper"], ["#FF6A3D", "Ember"], ["#FFC857", "Gold"], ["#7BD389", "Leaf"], ["#5AB0FF", "Sky"], ["#C792EA", "Violet"], ["#FF5C7A", "Rose"], ["#9AA0A6", "Fog"]];
  var state = { notes: {}, sel: null, mode: 0, timer: null, search: "", showArchived: false, folded: false, last: {}, caret: {}, chainP: Promise.resolve() };

  function load() { try { state.notes = JSON.parse(localStorage.getItem(LS) || "{}") || {}; } catch (e) { state.notes = {}; } }
  function persist() { try { localStorage.setItem(LS, JSON.stringify(state.notes)); } catch (e) { status("not saved: storage full"); } }
  function stamp(d) { d = d || new Date(); function p(n){return(n<10?"0":"")+n;} return d.getFullYear()+""+p(d.getMonth()+1)+p(d.getDate())+"-"+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  var MON = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function dateLine(d) { return d.getDate() + " " + MON[d.getMonth()] + " " + d.getFullYear() + " at " + p2(d.getHours()) + ":" + p2(d.getMinutes()); }
  function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
  function short(d) { var now = new Date(), y = new Date(now - 864e5); if (sameDay(d, now)) return p2(d.getHours()) + ":" + p2(d.getMinutes()); if (sameDay(d, y)) return "Yesterday"; return p2(d.getDate()) + "/" + p2(d.getMonth() + 1) + "/" + String(d.getFullYear()).slice(2); }

  // ---- SF Symbol stand-ins (inline SVG, stroke = currentColor) ----
  var SYM = {
    "sidebar.left": '<rect x="2.5" y="3.5" width="15" height="13" rx="2.5"/><line x1="7.5" y1="3.5" x2="7.5" y2="16.5"/>',
    "square.and.pencil": '<path d="M9 4H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-4"/><path d="M14.5 2.5l3 3L10 13H7v-3z"/>',
    "magnifyingglass": '<circle cx="8.5" cy="8.5" r="5"/><line x1="12.3" y1="12.3" x2="17" y2="17"/>',
    "checklist": '<path d="M3 5l1.5 1.5L7 4M3 11l1.5 1.5L7 10"/><line x1="10" y1="5.5" x2="17" y2="5.5"/><line x1="10" y1="11.5" x2="17" y2="11.5"/><line x1="10" y1="16" x2="17" y2="16"/>',
    "tablecells": '<rect x="2.5" y="3.5" width="15" height="13" rx="2"/><line x1="2.5" y1="10" x2="17.5" y2="10"/><line x1="10" y1="3.5" x2="10" y2="16.5"/>',
    "list.bullet": '<circle cx="4" cy="5" r="1"/><circle cx="4" cy="10" r="1"/><circle cx="4" cy="15" r="1"/><line x1="8" y1="5" x2="17" y2="5"/><line x1="8" y1="10" x2="17" y2="10"/><line x1="8" y1="15" x2="17" y2="15"/>',
    "list.number": '<text x="2" y="7" font-size="5" stroke="none" fill="currentColor">1</text><text x="2" y="12" font-size="5" stroke="none" fill="currentColor">2</text><text x="2" y="17" font-size="5" stroke="none" fill="currentColor">3</text><line x1="8" y1="5" x2="17" y2="5"/><line x1="8" y1="10" x2="17" y2="10"/><line x1="8" y1="15" x2="17" y2="15"/>',
    "code": '<path d="M7 5l-4.5 5L7 15M13 5l4.5 5L13 15M11.5 3.5l-3 13"/>',
    "bolt": '<path d="M11 2L4 11h5l-1 7 7-9h-5z"/>',
    "link": '<path d="M8.5 11.5a3.5 3.5 0 0 0 5 0l2.5-2.5a3.5 3.5 0 0 0-5-5L9.8 5.2"/><path d="M11.5 8.5a3.5 3.5 0 0 0-5 0L4 11a3.5 3.5 0 0 0 5 5l1.2-1.2"/>',
    "pencil": '<path d="M13.5 3.5l3 3L7 16H4v-3z"/>',
    "pin": '<path d="M7 3h6l-1 5 3 3H5l3-3z"/><line x1="10" y1="11" x2="10" y2="17"/>',
    "pin.slash": '<path d="M7 3h6l-1 5 3 3H5l3-3z"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="3" y1="3" x2="17" y2="17"/>',
    "archivebox": '<rect x="2.5" y="3.5" width="15" height="4" rx="1"/><path d="M4 7.5v8a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-8"/><line x1="8" y1="10.5" x2="12" y2="10.5"/>',
    "tray.and.arrow.up": '<path d="M3 12v4h14v-4"/><path d="M10 13V3M6.5 6.5L10 3l3.5 3.5"/>',
    "import": '<rect x="6.5" y="2.5" width="11" height="11" rx="2"/><path d="M4 6.5H3.5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1V16"/><path d="M12 5v6M9.5 8.5L12 11l2.5-2.5"/>',
    "square.and.arrow.up": '<path d="M6 8H5a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1h-1"/><path d="M10 12V2M6.5 5.5L10 2l3.5 3.5"/>',
    "xmark": '<line x1="5" y1="5" x2="15" y2="15"/><line x1="15" y1="5" x2="5" y2="15"/>',
    "note.text": '<rect x="3.5" y="2.5" width="13" height="15" rx="2"/><line x1="6.5" y1="7" x2="13.5" y2="7"/><line x1="6.5" y1="10" x2="13.5" y2="10"/><line x1="6.5" y1="13" x2="11" y2="13"/>',
    "pin.fill": '<path d="M7 3h6l-1 5 3 3H5l3-3z" fill="currentColor"/><line x1="10" y1="11" x2="10" y2="17"/>',
    "bold": '<path d="M6 3.5h5a3 3 0 0 1 0 6H6zM6 9.5h6a3.5 3.5 0 0 1 0 7H6z" stroke-width="2"/>',
    "italic": '<line x1="12" y1="3.5" x2="8" y2="16.5"/><line x1="8.5" y1="3.5" x2="15" y2="3.5"/><line x1="5" y1="16.5" x2="11.5" y2="16.5"/>',
    "underline": '<path d="M6 3v6a4 4 0 0 0 8 0V3"/><line x1="4.5" y1="17" x2="15.5" y2="17"/>'
  };
  function sym(name, px) { var s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 20 20"); s.setAttribute("width", px || 13); s.setAttribute("height", px || 13);
    s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor"); s.setAttribute("stroke-width", "1.6"); s.setAttribute("stroke-linecap", "round"); s.setAttribute("stroke-linejoin", "round");
    s.setAttribute("aria-hidden", "true"); s.innerHTML = SYM[name] || ""; return s; }
  function iconBtn(symbol, help, fn, cls, px) { var b = el("button", "rz-tool" + (cls ? " " + cls : "")); b.type = "button"; b.title = help; b.setAttribute("aria-label", help); b.appendChild(sym(symbol, px)); b.addEventListener("click", function (e) { e.stopPropagation(); fn(e); }); return b; }

  // ---- host hooks (unchanged from 0.2) ----
  function toTranscript(name, rev, text) {
    try { var h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosTranscript;
      if (h) h.postMessage({ cmd: "append", role: "system", ns: "notes", text: "ЯSCRIBE note " + name + " rev " + rev + " · " + text.replace(/\s+/g, " ").slice(0, 160) }); } catch (e) {}
  }
  function toBatibabox(name, rev, text) {
    toTranscript(name, rev, text);
    try { if (typeof window.RL_NOTES_SAVE === "function") window.RL_NOTES_SAVE(name, rev, text); } catch (e) {}
    try { if (window.RL_BBX && typeof window.RL_BBX.refresh === "function") window.RL_BBX.refresh().catch(function(){}); } catch (e) {}
  }

  // ---- note helpers ----
  function head(n) { return n && n.revs && n.revs.length ? n.revs[n.revs.length - 1] : null; }
  function textOf(n) { var h = head(n); try { return h && h.page && h.page.blocks ? DOC.human(h.page.blocks) : ""; } catch (e) { return ""; } }
  function updated(n) { var h = head(n); return new Date((h && h.at) || n.created || Date.now()); }
  function titleOf(name, n) { if (n.title) return n.title; var t = textOf(n).split("\n").map(function (l) { return l.replace(/^#+\s*/, "").trim(); }).filter(Boolean)[0]; return t || "New Note"; }
  function snippetOf(n) { var ls = textOf(n).split("\n").map(function (l) { return l.replace(/^#+\s*/, "").trim(); }).filter(Boolean); return (ls[1] || "").slice(0, 80); }
  function styleOf(n) { var s = (n && n.style) || {}; return { font: FONTS.indexOf(s.font) >= 0 ? s.font : "System", size: SIZES.indexOf(+s.size) >= 0 ? +s.size : 14, color: s.color || "default", bold: !!s.bold, italic: !!s.italic, underline: !!s.underline }; }

  // ---- DOM (RScribeBody: HStack(spacing 0){ Sidebar | 1px edge | Editor }) ----
  var panel, side, sideTitle, sideKind, searchEl, listEl, archBtn, countEl, editorCol, tb, fmt, fmtDiv, dateEl, content, editor, viewer, empty, statusEl, progEl, modeBtns = {}, pinBtn, archTool, unfoldBtn, fFont, fSize, fColor, fDot, fB, fI, fU, fileIn;
  function ensurePanel() {
    if (panel) return;
    panel = el("section", "rscribe"); panel.id = "rscribe"; panel.hidden = true; panel.setAttribute("aria-label", "ЯSCRIBE notes");
    var body = el("div", "rz-body");
    // Sidebar
    side = el("aside", "rz-side");
    var sh = el("div", "rz-side-head");
    sideTitle = el("span", "rz-brand", "ЯSCRIBE"); sideKind = el("span", "rz-kind", "NOTES");
    sh.append(sideTitle, sideKind, el("span", "rz-spacer"),
      iconBtn("sidebar.left", "Fold sidebar", toggleSidebar, "rz-fog", 13), iconBtn("square.and.pencil", "New note", newNote, "rz-ember", 14));
    var sb = el("label", "rz-search"); sb.appendChild(sym("magnifyingglass", 11)); searchEl = el("input"); searchEl.type = "search"; searchEl.placeholder = "Search";
    searchEl.addEventListener("input", function () { state.search = searchEl.value; renderList(); }); sb.appendChild(searchEl);
    listEl = el("div", "rz-list");
    archBtn = el("button", "rz-archlink"); archBtn.type = "button"; archBtn.addEventListener("click", function () { state.showArchived = !state.showArchived; renderList(); });
    countEl = el("div", "rz-count");
    side.append(sh, sb, listEl, archBtn, countEl);
    var edge = el("div", "rz-vedge");
    // Editor
    editorCol = el("div", "rz-editor");
    tb = el("div", "rz-toolbar");
    unfoldBtn = iconBtn("sidebar.left", "Unfold sidebar", toggleSidebar, "rz-ember", 13); unfoldBtn.hidden = true;
    var aa = menuBtn("Aa", "Heading", [["Title", function () { insert("# "); }], ["Heading", function () { insert("## "); }], ["Subheading", function () { insert("### "); }]], "rz-aa");
    var seg = el("div", "rz-seg"); ["Write", "Reader", "Bot"].forEach(function (t, i) { var b = el("button", "rz-segb", t); b.type = "button"; b.addEventListener("click", function () { setMode(i); }); modeBtns[i] = b; seg.appendChild(b); });
    pinBtn = iconBtn("pin", "Pin", togglePin); archTool = iconBtn("archivebox", "Archive… (asks first, never erases)", toggleArchive);
    var exp = menuBtn(null, "Export", [["ЯZL page (.rzl)", function () { exportAs("rzl"); }], ["Markdown (.md)", function () { exportAs("md"); }], ["Plain text (.txt)", function () { exportAs("txt"); }]], "rz-tool", "square.and.arrow.up");
    fileIn = el("input"); fileIn.type = "file"; fileIn.accept = ".md,.txt,.rzl,.json,text/plain,text/markdown"; fileIn.hidden = true; fileIn.addEventListener("change", importFile);
    tb.append(unfoldBtn, aa,
      iconBtn("checklist", "Checklist", function () { insert("- [ ] "); }), iconBtn("tablecells", "Table", function () { insert("| Column | Column |\n|---|---|\n|  |  |"); }),
      iconBtn("list.bullet", "List", function () { insert("- "); }), iconBtn("list.number", "Numbered list", function () { insert("1. "); }),
      iconBtn("code", "Code", function () { insert("```text\n\n```"); }), iconBtn("bolt", "Live value (computed by the ЯSEED reader)", function () { insert("::live chain.entries Ghost Chain entries"); }),
      iconBtn("link", "Link to a page block", function () { insert("::link RZL-DOC-SPEC#0 RZL-DOC spec"); }),
      el("span", "rz-flex"), seg, el("span", "rz-flex"),
      iconBtn("pencil", "Rename…", rename), pinBtn, archTool, iconBtn("import", "Import .md · .pdf · .txt · .rzl… (or drag files in)", function () { fileIn.click(); }), exp,
      iconBtn("square.and.pencil", "New note", newNote), iconBtn("xmark", "Close ЯSCRIBE", close, "rz-close", 12), fileIn);
    // Format bar
    fmt = el("div", "rz-format");
    fFont = menuBtn("System", "Font", FONTS.map(function (f) { return [f, function () { setStyle({ font: f }); }, FONTCSS[f]]; }), "rz-fmenu rz-w118");
    fSize = menuBtn("14 pt", "Size", SIZES.map(function (z) { return [z + " pt", function () { setStyle({ size: z }); }]; }), "rz-fmenu rz-w48");
    fColor = menuBtn("Colour", "Text colour", COLORS.map(function (c) { return [c[1], function () { setStyle({ color: c[0] }); }, null, c[0] === "default" ? "#f2ebe3" : c[0]]; }), "rz-fmenu");
    fDot = el("span", "rz-dot"); fColor.insertBefore(fDot, fColor.firstChild);
    fB = iconBtn("bold", "Bold", function () { setStyle({ bold: !styleOf(cur()).bold }); }, "rz-tog", 12);
    fI = iconBtn("italic", "Italic", function () { setStyle({ italic: !styleOf(cur()).italic }); }, "rz-tog", 12);
    fU = iconBtn("underline", "Underline", function () { setStyle({ underline: !styleOf(cur()).underline }); }, "rz-tog", 12);
    fmt.append(fFont, fSize, fColor, el("span", "rz-vbar"), fB, fI, fU, el("span", "rz-flex"), el("span", "rz-fmtnote", "whole note · saved as a new rev"));
    fmtDiv = el("div", "rz-hedge");
    dateEl = el("div", "rz-date");
    content = el("div", "rz-content");
    editor = el("textarea", "rz-text"); editor.spellcheck = true; editor.setAttribute("autocapitalize", "sentences");
    editor.addEventListener("input", function () { remember(); schedule(); });
    ["select", "keyup", "mouseup", "touchend"].forEach(function (ev) { editor.addEventListener(ev, remember); });
    viewer = el("pre", "rz-mono"); viewer.hidden = true;
    empty = el("div", "rz-empty"); empty.appendChild(sym("note.text", 34)); empty.appendChild(el("div", "rz-empty-t", "No note selected"));
    var nb = el("button", "rz-bordered", "New note"); nb.type = "button"; nb.addEventListener("click", newNote); empty.appendChild(nb);
    content.append(dateEl, editor, viewer);
    var sbar = el("div", "rz-statusbar"); progEl = el("span", "rz-prog"); progEl.appendChild(el("i")); statusEl = el("span", "rz-status", "ready · offline"); sbar.append(progEl, statusEl);
    editorCol.append(tb, el("div", "rz-hedge"), fmt, fmtDiv, content, empty, el("div", "rz-hedge"), sbar);
    body.append(side, edge, editorCol); panel.appendChild(body);
    (document.body || document.documentElement).appendChild(panel);
    document.addEventListener("click", closeMenus);
  }
  // pop-up menu (SwiftUI Menu)
  function menuBtn(label, help, items, cls, symbol) {
    var wrap = el("span", "rz-menuwrap"); var b = el("button", cls || "rz-tool"); b.type = "button"; b.title = help; b.setAttribute("aria-label", help);
    if (symbol) b.appendChild(sym(symbol, 13)); else { b._t = el("span", "rz-mlabel", label); b.appendChild(b._t); if (/rz-fmenu/.test(cls || "")) b.appendChild(el("span", "rz-chev", "⌄")); }
    var m = el("div", "rz-menu"); m.hidden = true;
    items.forEach(function (it) { var o = el("button", "rz-mi"); o.type = "button"; if (it[3]) { var d = el("span", "rz-dot"); d.style.background = it[3]; o.appendChild(d); } o.appendChild(el("span", "", it[0])); if (it[2]) o.style.fontFamily = it[2];
      o.addEventListener("click", function (e) { e.stopPropagation(); m.hidden = true; it[1](); }); m.appendChild(o); });
    b.addEventListener("click", function (e) { e.stopPropagation(); var was = m.hidden; closeMenus(); if (was) { var r = b.getBoundingClientRect(); m.style.left = Math.max(4, Math.min(innerWidth - 200, r.left)) + "px"; m.style.top = (r.bottom + 4) + "px"; m.hidden = false; } });
    wrap.append(b, m); wrap._btn = b; wrap.setLabel = function (t) { if (b._t) b._t.textContent = t; }; return wrap;
  }
  function closeMenus() { if (!panel) return; var ms = panel.querySelectorAll(".rz-menu"); for (var i = 0; i < ms.length; i++) ms[i].hidden = true; }

  // ---- behaviour ----
  function cur() { return state.sel ? state.notes[state.sel] : null; }
  function open() { ensurePanel(); load2(); panel.hidden = false; renderList();
    if (!state.sel || !state.notes[state.sel]) { var first = sortedNames(false)[0]; if (first) select(first); else showEmpty(); } else select(state.sel, true);
    window.RL_RSCRIBE.opened = true; }
  function load2() { /* superdragon may have seeded NOTES into the live object; nothing to reload */ }
  function close() { if (!panel) return; flush(); closeMenus(); panel.hidden = true; window.RL_RSCRIBE.opened = false; try { document.body.classList.remove("sd-sheet"); } catch (e) {} }
  function toggle() { ensurePanel(); if (panel.hidden) open(); else close(); }
  function toggleSidebar() { state.folded = !state.folded; side.hidden = state.folded; side.nextSibling.hidden = state.folded; unfoldBtn.hidden = !state.folded; }
  function setMode(m) { state.mode = m; for (var k in modeBtns) modeBtns[k].classList.toggle("sel", +k === m); draw(); }
  function showEmpty() { state.sel = null; content.hidden = true; fmt.hidden = true; fmtDiv.hidden = true; empty.hidden = false; renderList(); }

  function remember() { if (state.sel && editor) state.caret[state.sel] = [editor.selectionStart || 0, editor.selectionEnd || 0, editor.scrollTop || 0]; }
  function clampSel(name) {
    var len = editor.value.length, c = state.caret[name] || [len, len, 0];
    var a = Math.max(0, Math.min(len, c[0] | 0)), b = Math.max(a, Math.min(len, c[1] | 0));
    try { editor.setSelectionRange(a, b); } catch (e) {}
    try { editor.scrollTop = Math.min(c[2] || 0, editor.scrollHeight || 0); } catch (e) {}
    return [a, b];
  }

  function newNote() {
    flush();
    var name = "SCRIBE-" + stamp(), i = 1; while (state.notes[name]) name = "SCRIBE-" + stamp() + "-" + (++i);
    state.notes[name] = { created: new Date().toISOString(), revs: [], chain: [], pinned: false, archived: false, title: "" };
    state.showArchived = false; state.search = ""; if (searchEl) searchEl.value = "";
    select(name); status("new note · writes on first edit · offline");
    try { editor.focus(); } catch (e) {}
  }

  function select(name, keep) {
    if (!state.notes[name]) return;
    if (state.sel === name && (keep || editor.value === state.last[name] || state.last[name] != null)) { remember(); flush(); empty.hidden = true; content.hidden = false; renderList(); draw(); return; }
    if (state.sel && state.sel !== name) { remember(); flush(); }
    state.sel = name; var n = state.notes[name], text = textOf(n);
    try { editor.blur(); } catch (e) {}
    editor.value = ""; editor.value = text;            // reset first so WebKit never keeps a range past the new end
    state.last[name] = text; clampSel(name);
    empty.hidden = true; content.hidden = false;
    applyStyle(); setMode(0); renderList();
    var h = head(n); status(h ? name + "@" + h.rev + " · " + ((h.page && h.page.blocks) || []).length + " blocks · rzl.doc.v1 · offline" : "new note · offline");
  }

  function schedule() { if (state.timer) clearTimeout(state.timer); state.timer = setTimeout(flush, 1200); }

  // snapshot everything synchronously, then save in a serialized queue (no await ever reads state.sel / editor)
  function flush(force) {
    if (state.timer) { clearTimeout(state.timer); state.timer = null; }
    var name = state.sel, n = name && state.notes[name]; if (!n || !editor) return state.chainP;
    var text = editor.value, last = state.last[name];
    if (!force && text === last) return state.chainP;
    if (!force && !text.trim() && !n.revs.length) return state.chainP;
    state.last[name] = text;
    var extra = force && force.extra || {};
    state.chainP = state.chainP.then(function () { return saveRev(name, n, text, extra); }).catch(function (e) { status("save error · " + (e && e.message)); });
    return state.chainP;
  }
  async function saveRev(name, n, text, extra) {
    var h = head(n), rev = (h ? h.rev : 0) + 1; prog(0.2);
    var ex = {}; if (n.title) ex.display_title = n.title; if (n.style) ex.style = n.style; for (var k in extra) ex[k] = extra[k];
    var page = await DOC.page(name, rev, DOC.parse(text), n.created, ex); prog(0.55);
    n.revs.push({ rev: rev, page: page, at: new Date().toISOString() });
    var rec = await DOC.chainAppend(n.chain, { kind: "doc.edit", op: "set", name: name, rev: rev, at: new Date().toISOString(), app: DOC.VERSION });
    n.chain.push(rec); persist(); prog(0.85);
    toBatibabox(name, rev, text); prog(1);
    renderList(); if (state.sel === name) { dateEl.textContent = dateLine(new Date()); if (state.mode) draw(); }
    status("1/3 page @" + rev + " ✓ · 2/3 chain ✓ · 3/3 BATIBABOX mirror ✓ · " + name + "@" + rev);
  }
  function prog(v) { if (progEl) progEl.firstChild.style.width = Math.round(v * 100) + "%"; }

  function insert(s) {
    if (!state.sel) newNote(); if (state.mode !== 0) setMode(0);
    var len = editor.value.length, a = Math.min(editor.selectionStart || len, len), b = Math.min(editor.selectionEnd || a, len);
    var pre = editor.value.slice(0, a); if (pre && !/\n$/.test(pre) && /^(#|- |1\. |\||```|::)/.test(s)) s = "\n" + s;
    editor.value = pre + s + editor.value.slice(b); var c = a + s.length; try { editor.setSelectionRange(c, c); editor.focus(); } catch (e) {}
    remember(); schedule();
  }
  function rename() { var n = cur(); if (!n) return; var t = window.prompt("Rename\nSaved as a new revision. Earlier revisions keep their old name.\n\nName", titleOf(state.sel, n)); if (t == null || !t.trim()) return;
    n.title = t.trim(); flush({ extra: { display_title: n.title } }); renderList(); }
  function togglePin() { var n = cur(); if (!n) return; n.pinned = !n.pinned;
    n.chain.push({ kind: "doc.log", op: n.pinned ? "pin" : "unpin", name: state.sel, at: new Date().toISOString() }); persist(); renderList(); status(n.pinned ? "pinned" : "unpinned"); }
  function toggleArchive() {
    var n = cur(); if (!n) return;
    if (!n.archived && !window.confirm("Archive this note?\n\nNotes are never erased. Archived notes keep every revision and can be restored from Archived.")) return;
    flush(); n.archived = !n.archived; n.chain.push({ kind: "doc.log", op: n.archived ? "archive" : "restore", name: state.sel, at: new Date().toISOString() });
    persist(); status(n.archived ? "archived (not erased)" : "restored");
    if (n.archived && !state.showArchived) { var nx = sortedNames(false).filter(function (k) { return k !== state.sel; })[0]; if (nx) select(nx); else showEmpty(); } else renderList();
  }
  function setStyle(ch) { var n = cur(); if (!n) return; var s = styleOf(n); for (var k in ch) s[k] = ch[k]; n.style = s; applyStyle(); flush({ extra: { style: s } }); }
  function applyStyle() {
    var s = styleOf(cur()); fFont.setLabel(s.font); fSize.setLabel(s.size + " pt"); fDot.style.background = s.color === "default" ? "#f2ebe3" : s.color;
    editor.style.fontFamily = FONTCSS[s.font]; editor.style.fontSize = s.size + "px"; editor.style.color = s.color === "default" ? "" : s.color;
    editor.style.fontWeight = s.bold ? "700" : ""; editor.style.fontStyle = s.italic ? "italic" : ""; editor.style.textDecoration = s.underline ? "underline" : "";
    fB.classList.toggle("on", s.bold); fI.classList.toggle("on", s.italic); fU.classList.toggle("on", s.underline);
  }
  function exportAs(kind) {
    var n = cur(); if (!n) return; flush(); var text = editor.value, name = state.sel, data, type, ext;
    if (kind === "rzl") { data = JSON.stringify(head(n) ? head(n).page : { name: name, blocks: DOC.parse(text) }, null, 1); type = "application/json"; ext = ".rzl"; }
    else { data = text; type = kind === "md" ? "text/markdown" : "text/plain"; ext = "." + kind; }
    try { var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([data], { type: type })); a.download = (titleOf(name, n) || name).replace(/[\\/:*?"<>|]+/g, "-") + ext; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000); status("exported " + ext); } catch (e) { status("export not available here"); }
  }
  function importFile() {
    var f = fileIn.files && fileIn.files[0]; if (!f) return; var r = new FileReader();
    r.onload = function () { var t = String(r.result || ""); try { var j = JSON.parse(t); if (j && j.blocks) t = DOC.human(j.blocks); } catch (e) {}
      newNote(); editor.value = t; state.notes[state.sel].title = f.name.replace(/\.[^.]+$/, ""); flush(true); select(state.sel); status("imported " + f.name); fileIn.value = ""; };
    r.readAsText(f);
  }
  function status(t) { if (statusEl) statusEl.textContent = t; }

  function sortedNames(arch) {
    return Object.keys(state.notes).filter(function (k) { var n = state.notes[k]; return n && (!!n.archived === !!arch); })
      .sort(function (a, b) { var A = state.notes[a], B = state.notes[b]; if (!arch && !!B.pinned !== !!A.pinned) return B.pinned ? 1 : -1; return updated(B) - updated(A); });
  }
  function sectionOf(n) {
    if (n.pinned && !state.showArchived) return "Pinned";
    var d = updated(n), now = new Date(), days = Math.floor((now - d) / 864e5);
    if (sameDay(d, now)) return "Today"; if (sameDay(d, new Date(now - 864e5))) return "Yesterday";
    if (days < 7) return "Previous 7 Days"; if (days < 30) return "Previous 30 Days"; return MON[d.getMonth()] + " " + d.getFullYear();
  }
  function renderList() {
    if (!listEl) return;
    var q = (state.search || "").toLowerCase(), names = sortedNames(state.showArchived);
    if (q) names = names.filter(function (k) { var n = state.notes[k]; return titleOf(k, n).toLowerCase().indexOf(q) >= 0 || textOf(n).toLowerCase().indexOf(q) >= 0; });
    listEl.textContent = ""; var lastSec = null;
    names.forEach(function (name) {
      var n = state.notes[name], sec = sectionOf(n);
      if (sec !== lastSec) { listEl.appendChild(el("div", "rz-sec", sec)); lastSec = sec; }
      var row = el("button", "rz-row" + (name === state.sel ? " sel" : "")); row.type = "button"; row.setAttribute("data-note", name);
      var l1 = el("span", "rz-l1"); if (n.pinned) { var pi = sym("pin.fill", 9); pi.setAttribute("class", "rz-pin"); l1.appendChild(pi); } l1.appendChild(el("span", "rz-rt", titleOf(name, n)));
      var l2 = el("span", "rz-l2"); var sn = snippetOf(n); l2.append(el("span", "rz-rd", short(updated(n))), el("span", "rz-rs", sn || "No additional text"));
      row.append(l1, l2); row.addEventListener("click", function () { select(name); }); listEl.appendChild(row);
    });
    if (!names.length) listEl.appendChild(el("div", "rz-none", q ? "No results" : (state.showArchived ? "No archived notes" : "No notes")));
    sideKind.textContent = state.showArchived ? "ARCHIVE" : "NOTES";
    archBtn.textContent = ""; archBtn.appendChild(sym(state.showArchived ? "note.text" : "archivebox", 11)); archBtn.appendChild(el("span", "", state.showArchived ? "Back to notes" : "Archived"));
    countEl.textContent = Object.keys(state.notes).filter(function (k) { return !state.notes[k].archived; }).length + " notes · rzl.doc.v1 · offline · backed up";
    var n = cur(); if (pinBtn && n) { pinBtn.title = n.pinned ? "Unpin" : "Pin"; pinBtn.replaceChild(sym(n.pinned ? "pin.slash" : "pin"), pinBtn.firstChild);
      archTool.title = n.archived ? "Restore" : "Archive… (asks first, never erases)"; archTool.replaceChild(sym(n.archived ? "tray.and.arrow.up" : "archivebox"), archTool.firstChild); }
  }
  function draw() {
    var n = cur(); if (!n || !editor) return;
    var h = head(n); dateEl.textContent = dateLine(h ? updated(n) : new Date());
    fmt.hidden = state.mode !== 0; fmtDiv.hidden = state.mode !== 0;
    if (state.mode === 0) { editor.hidden = false; viewer.hidden = true; }
    else if (state.mode === 1) { editor.hidden = true; viewer.hidden = false; viewer.textContent = DOC.human(DOC.parse(editor.value)); }
    else { editor.hidden = true; viewer.hidden = false; viewer.textContent = h ? JSON.stringify(h.page, null, 1) : "(no saved rev yet)"; }
  }
  function search(q) { q = (q || "").toLowerCase(); return Object.keys(state.notes).filter(function (k) { var n = state.notes[k]; return titleOf(k, n).toLowerCase().indexOf(q) >= 0 || textOf(n).toLowerCase().indexOf(q) >= 0; }); }

  function wireButton() {
    window.RL_RSCRIBE_TOGGLE = toggle;
    var existing = document.getElementById("rscribe-btn");
    if (existing) { existing.addEventListener("click", toggle); return; }
    var hero = document.getElementById("bot-hero");
    if (hero) { var b = el("button", "rsc-open-btn", "ЯSCRIBE"); b.id = "rscribe-open"; b.type = "button"; b.title = "Open ЯSCRIBE (notes)"; b.addEventListener("click", toggle); hero.appendChild(b); }
  }

  window.RL_RSCRIBE = { version: "0.3 (web · Mac 1:1)", open: open, close: close, toggle: toggle, newNote: newNote, search: search, select: select,
    get notes() { return state.notes; }, get selected() { return state.sel; }, flush: flush, refresh: function () { renderList(); }, opened: false };

  function injectCss() { if (document.getElementById("rscribe-css")) return; var l = document.createElement("link"); l.id = "rscribe-css"; l.rel = "stylesheet";
    var me = document.querySelector('script[src*="rscribe/rscribe.js"]'); l.href = me ? me.getAttribute("src").replace(/rscribe\.js.*$/, "rscribe.css") : "./skills/rscribe/rscribe.css"; document.head.appendChild(l); }
  function boot() { injectCss(); load(); wireButton(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
