/* superdragon.js · THE SUPERDRAGONEGG 2.1.9.14 (2026-10-17 MT; egg-editable home.html (rabbit + THUNDR) via RVM core-base handoff · 2.1.9.13: chat-list rabbit undone → 2.1.9.10 text button; rabbit right of Send kept · 2.1.9.12: home rabbit directly right of the home bar · 2.1.9.11: rabbit ЯSCRIBE on home + composer, re-attached by observer · 2.1.9.10: was 2.1.9.6 2026-10-16) · iOS ЯSCRIBE = Mac 1:1 (rscribe 0.3) · RZL CODE REPAIR 0.2 egg layer · egg-only, offline, append-only, deletes nothing.
 * 1 ЯSCRIBE everywhere: buttons in the chat-list top bar (.cl-top, next to the profile/⌕/+) and the chat header (#thread-head, next to ⚡);
 *   they call window.RL_RSCRIBE_TOGGLE / RL_RSCRIBE directly (2.1.9.5 waited for #rscribe-open, which never exists when the shell
 *   provides #rscribe-btn or #bot-hero is hidden). The panel opens as a fixed sheet over any screen. /rscribe in the address bar
 *   (BASE-COMMANDS token → ROS_SEND "RSCRIBE") opens it too.
 * 2 THUNDR pinned: one always-on THUNDR pill (0.4 clay art) fixed on every screen, never hidden, narrating app / egg / bot events.
 * 3 NOTES: the existing host note NOTES (rev 24 seed) shows in ЯSCRIBE, pinned. When the user asks a bot to "write … NOTES",
 *   the bot's reply is appended as a NEW stamped rev "ЯID · name · YYYY-MM-DD HH:MM MT: text" (ЯID is the key; ЯВОТ/ЯBOT, ЯМАХ/BOT
 *   both map to the same seat). Never erases. Mirrored to the transcript so botableta.py sweep can carry it to host.
 * 4 LOCAL ids: display-only — LOCAL-9SJ1-4JPK shows its alias ЯID-pending; any other LOCAL-XXXX-XXXX shows "ЯID pending". */
(function () {
  "use strict";
  if (window.RL_SUPERDRAGON) return;
  const V = "2.2.0.2", HERE = (document.currentScript && document.currentScript.src) ? document.currentScript.src.replace(/[^/]*$/, "") : "./skills/superdragon/";
  const ATLAS = HERE.replace(/superdragon\/$/, "thundr-live/atlas");
  const LS = "rlab.rscribe.notes.v1";
  const ALIAS = { "LOCAL-9SJ1-4JPK": "ЯID-pending" };
  const CYR = { "ЯВОТ": "ЯBOT", "ЯМАХ": "BOT" };   // 2.1.9.8: display/log the Latin roster name; both spellings = same seat (no rename of files/seats)
  const LATIN = (s) => String(s || "").replace(/ЯВОТ|ЯМАХ/g, (m) => CYR[m]);
  function readSeed() {
    return new Promise((ok, no) => { try { const x = new XMLHttpRequest(); x.open("GET", HERE + "botableta-seed.json"); x.onload = () => { try { ok(JSON.parse(x.responseText)); } catch (e) { no(e); } }; x.onerror = no; x.send(); } catch (e) { no(e); } })
      .catch(() => fetch(HERE + "botableta-seed.json").then((r) => r.json()));
  }
  const SEATS = { "ЯID-pending": ["ЯBOT", "ЯВОТ"], "ЯID-pending": ["BOT", "ЯМАХ"], "ЯID-pending": ["BOT"], "ЯID-pending": ["ЯBOWZR", "BOT"],
    "ЯID-pending": ["BOT"], "ЯID-pending": ["BOT"] };
  const ASK = /\bwrite\b[\s\S]*\bNOTES\b/i;
  const log = [];
  let pill = null, pillTx = null, dragon = null, lastAsk = "";

  // ---------- THUNDR pinned narrator ----------
  function css() {
    if (document.getElementById("superdragon-css")) return;
    const s = document.createElement("style"); s.id = "superdragon-css";
    s.textContent =
      "#thundr-pin{position:fixed;right:8px;bottom:calc(env(safe-area-inset-bottom) + 72px);z-index:2147483000;display:flex;align-items:center;gap:6px;" +
      "max-width:min(78vw,420px);font:600 12px system-ui,sans-serif;color:#f2ecfa;pointer-events:none}" +
      "#thundr-pin .tp-tx{text-shadow:0 1px 2px #000,0 0 6px #000,0 0 1px #000}" +
      "#thundr-pin[hidden]{display:flex!important}#thundr-pin thundr-live{flex:0 0 auto;width:auto;min-width:32px;min-height:32px;overflow:visible}#thundr-bar{display:none!important}#thundr-pin .tp-tx{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
      ".sd-rsc{font:600 12px system-ui,sans-serif;appearance:none;-webkit-appearance:none;background:transparent;border:none;box-shadow:none;padding:0 4px;color:#efe8ff;margin:0 4px;flex:0 0 auto;text-shadow:0 1px 2px #000}" +
      "body.sd-sheet #rscribe{position:fixed;inset:calc(env(safe-area-inset-top) + 8px) 6px calc(env(safe-area-inset-bottom) + 8px) 6px;z-index:2147482000;" +
      "margin:0;overflow:hidden;background:#0a080c}";   // 2.1.9.10: Mac 1:1 layout (sidebar | editor) on every width, no stacked phone layout
    document.head.appendChild(s);
  }
  function say(text, state) {
    text = String(text || "");
    log.push({ at: new Date().toISOString(), text, state: state || "" }); if (log.length > 200) log.shift();
    pinMount(); if (pillTx) pillTx.textContent = "";   // 2.1.9.15: THUNDR is free-floating, no caption (narration stays in RL_SUPERDRAGON log)
    if (dragon && state) { try { dragon.setState ? dragon.setState(state) : dragon.setAttribute("state", state); } catch (e) {} }
  }
  function pinMount() {
    if (pill && pill.isConnected) return true;
    if (!document.body) return false;
    css();
    pill = document.createElement("div"); pill.id = "thundr-pin"; pill.setAttribute("role", "status"); pill.setAttribute("aria-live", "polite");
    if (window.customElements && customElements.get("thundr-live")) {
      dragon = document.createElement("thundr-live"); dragon.setAttribute("size", "32"); dragon.setAttribute("base", ATLAS); dragon.setAttribute("state", "idle"); pill.append(dragon);
    }
    pillTx = document.createElement("span"); pillTx.className = "tp-tx"; pillTx.textContent = "";   // 0.4: blank when idle
    pill.append(pillTx); document.body.appendChild(pill); return true;
  }
  function upgradeDragon() {
    if (dragon || !pill || !window.customElements || !customElements.get("thundr-live")) return;
    dragon = document.createElement("thundr-live"); dragon.setAttribute("size", "32"); dragon.setAttribute("base", ATLAS); dragon.setAttribute("state", "idle"); pill.prepend(dragon);
  }
  document.addEventListener("thundr-adapter", (ev) => { const d = ev.detail || {}; if (d.text || d.state) say(d.text || (d.state === "idle" || d.state === "sleeping" ? "" : d.state), d.state); });

  // ---------- ЯSCRIBE buttons + sheet ----------
  function toggleScribe() {
    const R = window.RL_RSCRIBE; if (!R) { say("ЯSCRIBE loading…"); return; }
    const p = document.getElementById("rscribe");
    if (p && !p.hidden) { try { R.close(); } catch (e) {} document.body.classList.remove("sd-sheet"); say("ЯSCRIBE closed"); return; }
    try { R.open(); } catch (e) {}
    const q = document.getElementById("rscribe"); if (q && q.parentElement !== document.body) document.body.appendChild(q);
    document.body.classList.add("sd-sheet"); say("ЯSCRIBE open · NOTES pinned", "success");
  }
  function scribeBtn(id) { const b = document.createElement("button"); b.id = id; b.type = "button"; b.className = "sd-rsc"; b.textContent = "ЯSCRIBE";
    b.setAttribute("aria-label", "Open ЯSCRIBE (notes)"); b.addEventListener("click", (e) => { e.stopPropagation(); toggleScribe(); }); return b; }
  function buttons() {
    let n = 0;
    const top = document.querySelector("#chatlist .cl-top");
    if (top && !document.getElementById("sd-rsc-list")) { const sp = top.querySelector(".cl-spacer"); const b = scribeBtn("sd-rsc-list"); if (sp) sp.insertAdjacentElement("afterend", b); else top.appendChild(b); }
    if (document.getElementById("sd-rsc-list")) n++;
    const head = document.getElementById("thread-head");
    if (head && !document.getElementById("sd-rsc-thread")) { const bolt = head.querySelector(".th-bolt"); const b = scribeBtn("sd-rsc-thread"); if (bolt) bolt.insertAdjacentElement("beforebegin", b); else head.appendChild(b); }
    if (document.getElementById("sd-rsc-thread")) n++;
    const hero = document.getElementById("bot-hero");
    if (hero && !document.getElementById("sd-rsc-hero") && !document.getElementById("rscribe-open")) { hero.appendChild(scribeBtn("sd-rsc-hero")); }
    return n;
  }

  // ---------- 2.1.9.8 re-cut 2: THUNDR drag + magnet (Mac + iOS) ----------
  // Only the figure takes pointer events; .tp-tx stays pointer-events:none and follows him. Default: stays where dropped;
  // snaps flush to an edge/corner only when released within 24px of it. Position saved in localStorage "rlab.thundr.pos.v1".
  const POSK = "rlab.thundr.pos.v1", SNAP = 24, DRAGPX = 6;
  function dragCss() {
    if (document.getElementById("sd-drag-css")) return;
    const s = document.createElement("style"); s.id = "sd-drag-css";
    s.textContent = "#thundr-pin{background:none!important;border:0!important;box-shadow:none!important}" +
      "#thundr-pin thundr-live{pointer-events:auto;touch-action:none;cursor:grab;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}" +
      "#thundr-pin.sd-dragging thundr-live{cursor:grabbing}#thundr-pin .tp-tx{pointer-events:none}";
    document.head.appendChild(s);
  }
  function clampPos(x, y) {
    const r = pill.getBoundingClientRect(), W = innerWidth, H = innerHeight;
    return { x: Math.max(0, Math.min(W - r.width, x)), y: Math.max(0, Math.min(H - r.height, y)) };
  }
  function placeAt(x, y) { const p = clampPos(x, y); pill.style.left = p.x + "px"; pill.style.top = p.y + "px"; pill.style.right = "auto"; pill.style.bottom = "auto"; return p; }
  function magnet(p) {
    const r = pill.getBoundingClientRect(), W = innerWidth, H = innerHeight;
    if (p.x <= SNAP) p.x = 0; else if (W - (p.x + r.width) <= SNAP) p.x = W - r.width;
    if (p.y <= SNAP) p.y = 0; else if (H - (p.y + r.height) <= SNAP) p.y = H - r.height;
    return p;
  }
  function restorePos() {
    try { const v = JSON.parse(localStorage.getItem(POSK) || "null"); if (!v) return;
      placeAt(v.fx * innerWidth, v.fy * innerHeight); } catch (e) {}
  }
  function savePos(p) { try { localStorage.setItem(POSK, JSON.stringify({ fx: p.x / innerWidth, fy: p.y / innerHeight, at: Date.now() })); } catch (e) {} }
  function dragWire() {
    if (!pill || !pill.isConnected || !dragon || dragon.__sdDrag) return;
    dragCss(); dragon.__sdDrag = 1; restorePos();
    let st = null, moved = false, eatClick = false;
    dragon.addEventListener("pointerdown", (e) => {
      if (e.button && e.button !== 0) return;
      const r = pill.getBoundingClientRect(); st = { id: e.pointerId, sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top }; moved = false;
      try { dragon.setPointerCapture(e.pointerId); } catch (x) {}
    });
    dragon.addEventListener("pointermove", (e) => {
      if (!st || e.pointerId !== st.id) return;
      const dx = e.clientX - st.sx, dy = e.clientY - st.sy;
      if (!moved && Math.hypot(dx, dy) < DRAGPX) return;
      moved = true; pill.classList.add("sd-dragging"); e.preventDefault(); placeAt(st.ox + dx, st.oy + dy);
    });
    const end = (e) => {
      if (!st || e.pointerId !== st.id) return;
      try { dragon.releasePointerCapture(e.pointerId); } catch (x) {}
      if (moved) { const r = pill.getBoundingClientRect(); const p = placeAt(magnet(clampPos(r.left, r.top)).x, magnet(clampPos(r.left, r.top)).y); savePos(p); eatClick = true; }
      pill.classList.remove("sd-dragging"); st = null;
    };
    dragon.addEventListener("pointerup", end); dragon.addEventListener("pointercancel", end);
    // a drag must not fire the figure's click; a plain click (no drag) passes through to the existing behaviour untouched
    dragon.addEventListener("click", (e) => { if (eatClick) { eatClick = false; e.stopImmediatePropagation(); e.preventDefault(); } }, true);
    addEventListener("resize", () => { if (pill.style.left) { const r = pill.getBoundingClientRect(); placeAt(r.left, r.top); } });
  }

  // ---------- 2.1.9.8 re-cut 2: iOS ЯSCRIBE right of the composer bar ----------
  const IOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.maxTouchPoints > 1) || !/Macintosh/.test(navigator.userAgent);
  // 2.1.9.11: image inlined (no path lookup can break it); file copy kept as rscribe-button.png
  const RABBIT = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAIAAAD+96djAAAAAXNSR0IArs4c6QAAQABJREFUeAHkvPeTJWl2HZY+82Xmy+ddvfK+q6u925npMb27IBbLxQIgHEEDAmLoB4EKSUFGSBEKBUO/gQQlBilKCkmgDCACBCiSAGF2sbOzM7Njumemp70p+6rqee/ypbc62bvQP6GKnoqaqvdeZn7fveeee+69H0mSJPGXX2GIn6L//n/4Rf9/CxGGoUATl1bl1YUk4zsXl0SFJ0rZ2Oa8FLrehbWUzIWFJH9uSfYdZ2c1vZBmCd+7tJ4W6SAZ5y6uJgnfXinG14p86PmXNjNpgRA4+uJahnDNhZKyNS+5ln1+JTmXoMgwvLaVVvhAEZndlSQ+cGVOWcmynutd3MwmOJ+l6Atr+AA3kxDOLci+bS2XE4tZwbHsS5vZkkKGnndpI50RQ5okLm9kYqQjCsyVjTTj2bm0uFGMObaztpDIy1QYhOeXUwobCCy1UZYo388nOI4mdPvH240VwBfzo//DKmwuKL/xSxd2805uedUKWH9wmlm9OmkeSCKtEdlwXGFTS86sK7Ck6orkrJlZ3h6ONdbsxRcvDBsnikQaRMrpH5dW1ydGEKotKb/SOjnN5RWfL+rdg8LicndgMdpZYfPK6VlbCaeptUutk71sKjV1aHd4ml/e7g5mEjHjc2uDxmmctdnMUu/0MF/IWYRsDU8y5bXeyOTdbqq81mm0Fc4UC5uN46OkwvDp+ehaaYmWMoP6UaE8PzEJs3taXNkYjDXRH/OF7UGzKnOuiZu0pgQnf3rv8EXLevfBwPEC+EFkEViF1y8W/tHfu7K5uUEwzJfv39VsrtXo1iudhMKfPj+S0yXPnHZrIz6e6p6d0mKG54LaYStbXtZNvXnaUzKZdrVDckmWsZ99eSzEU4FnNKvD3Fxm3GnNNArGUjuqCnJOnw4qh73S0mL98LDd1vOF5PGTpwGl+M7s6MVJqrCgDurt+mhupdw6ORyPAyFGNio1KpYOXb2yd5rIFCfdWqc+Subnm5XDbmuSLuXqx8fDnp0vKqfP93wyxnPk2XGT5uKWNj05qKeLpUm71m2ribSy92hPThfyWZ6LJcpp//ZustrST3vmK5sARoThP/zb67tzbK2p90c6wzCm4YUByVBeSMC0AprySYYnHNvwGEmifcejGJpl/JkeSgnZ1Wa6FSQSgm06FMswhOc4AcEI8ZivGQTLUb7jWh4lxwjH8u2Q4ZmADIkgJHkmnFkkfg+PcAJGjpHqzJEVkSY9XQ94gWYJz3AoXmAc0/YCmhMI3BjNspk4XulSLJeIBZrh43cpmVE1l+dZiQtHmsfyrG87TsjiBaZD+ASVl/2JHoYkNRhYC0splnau3txc3Nj4vT/87Df/YJ/4kWvQFFnKJXML+aUd/od/8cX3PhukZVqzqZAiY6Q7tcO5JNMZW7JIEYE7rrvw3bHhiDFKoPxuZTyfYgmSelo355OkGxC2F+ZkqjaykhKD11eHwUKKdonQdMOSQtSHtsQLMdZqTYP5NBOGQbcWLqSF077NM2ScC0ZVLS1TMh+eDa0C0MJzR4a7kqW7amTB+FO1bxUVWmDDg+5sKcPyNF7pLmX5IHCbE7ucpInQ7+nOQprujDWSposJ6nndXspzPBnWx16MJSrj0e48G1MyrdOTpVS4XBBPuwZuJcylBIEl5Hzp6Q9/eFhVH7dCMaaIQpyiKJGL0TR7CttmQtXyaRK24TWtkObYkWYKfIyXhaYTOq5NcZQu5HiGNdXJ04Eai8XgiGNtHM8mZhQ1MzRcaDzyxJgYivLD2kFSSp6opBd4Ahc7mvokT1oUPbNtj/QNk3JnDrZvNiFxRZpmXo4Q0EKGJKYTgo7RNd2GQ8987XDE+r7H0FxlIji+i4190XdDWABBD1okBY8MgtOxA6N/2gpwAzB+P/Bhf9vzzLjThClu7y4J/6FGEBFYkrblxASy9vhTAtdkqGQ8V85vzGVLHMPYbsDzMZFjgzCYabOkokxVVYCx0rRm6Ukl7QcIEYHjOpIQc1zj8Ozo8vbl1qAzny8Hvo9boWDRfEzTZ5PZRBLjge+VcvmF4pLv+jFBxMeqps7SEWbDOhDJTcfmWd60TJZhA9x84OMB4KgUSSqSxLE8PsG0TcM2NNNQpISqT3lWgDvjmXmWo8nQsEw3CPDhoe/aroPPiAhCxBKwmCFBEuOZSjFVwhhuvPH1+/eetYZR/MAdhDFZbFZ712/tJF3zo/sDlk2uza/JnIj3YBUG02lKyZIUkUlm8TwrC2vRp5FkFouLa5DUdDbDnziGfnLweGvlgiwlBXWSTxUdDxcITctOxTOJeMr1Q1mUXdcbq6phGOlkTjNmuMGMknU8B4vueB5uNS6nJ7PpXGGRpiiGonElPHlcVhzXbXTqQUAKMZll+ZlplvMrLFaLjcXFODY5m8qwNGeY+lQfm7arSHE/8LA0PmzG97zAFwUxk0i7vn9Uq6SV0dr13ZOnz/RuMx3np7ZFYTE4KpgrZ7AmX370OHC8fCorC+Jxq1Lvd+JyApuPLU3IiU63lc8WcSWe40VBEmNStV3nOB7mjZ2hKUaKKeXiAq7negGLewTYEVRcUhRZkWKyFJMyyYwkSviQzeVzhWxRFOSkkrEsC79PKymGooKQ4FhhaW4lxosZJRUXRYFlKYrkeZgVn8/ms+lcOTfXGw1kMZlJ5ThOkEUlJkilfDmTyGDtFDmB94pCLKmkUvFk4HkJWcHzMzS/PL+K/RNYYS5XdkJB65xNe73rN7eKaR4bhoUgeyN7Zjit49qlW7vZJIc7xl5LYuri1tUYH4PdCkIMi7q5sh0E/nHjFGuHm6MJ6vzajmHpXhDSDO354VJp+ZXXULht3dJVXX21IXAdGI+HX+ZSedhUjBOwWIgUK/Mr+VRuqbyIl+ES+EzHAQbHYWWGacKOYSGe7wuckFEy2XSGJsDQONzw6uKaJMrYCdd1YDcCL67ML+MDDcvADcBgKYqVRdE0tIDwaYAM/p9lLcv4i0+/2xw00sk0RfrDzmD3zTdrPaveNaInwn+yzPfbo8X1JXOmn/V9y/awjXPZsgRw4Dj4niDw2NJEPAlvLGXLeEvkbPiwwGt22huLW74fwuZTSpJjqOeHzyVRkWNyNplR4gpWajwbAy/G6pii6JSSVjUNi1vMFVu9xnufvatqKtwXpjsYD/HwCGGmacBw8EuOYvE9lysIsVjgBVgR/MMrx+rIcm3L0uBEIi/lMjnHtnE/SSWJPcfnJOIJ09Qsz947O8Y6mI7p4179YG3h3O7GJayIpmqljd36yVnr8IShkFXA9fEt8HOFtK5bZwdnxQSNK1mONZcv8Czd6taBn3iB61r4ARc4t7alKAl49Wgy2D85XF7YhKeEAXxbGanT08ZpKlVcW1iFK840fTgetvptIF5cShAB0R914QXtQd8LYFv4TP/6hVvAfGyXbduAQBAd7HAqmSbBMviY57ksx2dSWWAKA8PkBdMyXMehgfEhgcstza3CbbErsZgIdJzps2rrBFijyHLkUCx/8+LryUSq2qnjEqVM6fXLX4GvdQZtn8tbamfSqN64uVLMipFrYAmneqDqzqjVuvLmRUWMmKaq62eN0/3Ky95ovLG0DlCc6hrW4qxeGY57g2EP1ntQPdlcO7+zvhWXpJgA3GaX5hcyieRyqWw7Vj6dSadSAscDBZLxJB4DqwMyy/FMKVcAmIF5AfyAZGklgTXQtJlh26X8nCTFLdMCwaFpEsEID4OYAcdBmECQBij6YVAulJNyAjgFYILdjycTnhdgLfeefNYbj89v7HIU5Xn++uJ6SpZq7ZPeaLQwt0jTtOe6MMzuaFDMyuN26/KddwYm0x45sAYKwSmdYD1DO3f90rQ/rg19+DwcIR5PJZPFaxeuw09lWc5ncoh/uWw+F1HUQqvb3Nm6cG5tY6ZOKSLsjTrAgVan9vmzLxELeoMu+Oj9p1+AzywU5sAFELzikiyJUda0vbpFwEXVydryVi6dh2Mn04k3furq7duv8ZwImEBQ3760yBUDIUNhw/HwkTtMRyAGluPAYXHPssDHBR6kADaPyMJxbLvX2lk99/rl1xJSDK9X4imQF9e1D8/Oru7cyCdzMEyGoc9aFZ6NBbZbWD/XrjdPnu2DJv7YNQCtyWxmNBgf7TXSIvYCv6dTidRyuezYmhy5KwlTFgTRsmykIE/2n+i2c255G1xAkqSpMalUj+H2iJRfufwGUMCyDcO2UskswELVZ47nntQqWI3RuAcQrbdq+BCA60p5iYj4O51YSD2pqaICaHQMXb/2xvp+5/i//M0P91qq4Y/uP/vyxcFT2BReCQtHNFRnU3wswhKN94dBqVhS1Umr2yhl86YFgAz7455mqDB4x/dL+fnV+WXD0JAWnTZP+qPxQmnZJxXP1Jr7hzeuryyWpB+7xlgPEMMm3fb1Ny/xSFBD0vMcliaf7T/++OHd4WQC19ANYzabjgFOsXguXb64fQ23ARydzkY//OKjzbVzMMW4FAfB5zkOmAePQ/iEXcAvmt16s9+W4+JwMgZRBOm8vHUlHU/gIXhGWNmav3fU63Thhb3xaLx7dfXp2cE//hcfzgx2r+pMrNGrcCghgkbsyPMQGuWYtFBagL84rjmdgVAxzXYjpWTAb+AjLA0mRsiSDAwEbc0k09hLGOxp+xTwtLqwBcviGL11Wrt6562hw1c7emQRr1yDJ1xrfm213xpUOqBiJMdyo8mwPxlf2LoO0jAcDwBI+Crkci7EhUIx8B3EKNt2m912PjtXzJZwl/DYci531jyBacAOsXy41zD0++Ph7Zu3u70OODtCCUNGvop4DNYox2NUUvjgy3ZW0g3dmVvJjbzBP/4fPg5on44BFr2EFEdohHvDB0bjoSBI9W7z5enLTx9+/Ojg4aP9R4BPdaYBcUEc8PC1dq3d755bPzeajMazCZLrbDKN761eczSZLpZWgSkzbWroXnljs9dqnT47QmDCF5hllB1yUnzUHw3avZUCp3axQAR8L5ssgkfFBGYy6STjaRCBVq99WKsUM3PA/2wmC2MFh0aQn6ozpCSIWO3KwcwwVhY2qq0WCDUeFZQBYR+OQ5Ecwv6//d4f4JMRO1NK6sXRi9dvXzttJjiGTMbZgcqXN5L/zT+7N3OKbHrd88WL2yqiGt5lmMhCIrwgyBAPbHteZzjAza8v7Wwsr4N+IpzBfQ/ODk3Hh4EAUPZOD9bn15HlIrICiRvdVrmwiP81TAP74VJpx6i3jjo3ri0sPrZOBzYDGIOOMlbNyXB04ca5Wu8QBmbbVik9n4hTiiS2Ome1Tnu+tOw6diqRvrGbg223B52F+ZVCMuN6HklzYG/ArXw2tRzMgYaYjlPKZA3bbPU6SVlOSkqr06w2z8qFedU0yvm5xdJiIZMH6U4Vyv/yD0/PL3uO7c3N5z/4bP/4jGYzMsEoc/HarUuLjWcTJpFAvACZBijqugY+Ggdaycm5/Hy5UBiO+nIiE/3JmOmGOVdcxtqBUq+UVwvZPBYRPgvUTMZTcH9ADNiqqhuFVDhElHznnUa93uiZP3KNIBVHyuJsXNpt1/sva4ZpW3iq1qBrWuqz/UcnzQb8yrBs4GJSVgqZ5NODRyRBJSQFMUuJJ8CaXM/lOWY47OxV9ojQnUz6lqWDfZiOpYDqJlJP95+eNKtu4OH541ISb4cnSCKnE+BX1nyewq5nS/k/+d5jNuZyxMAbvygmOM8Ek4hC5OPDp589/+LlyWEuVZhowy9e3P9RVua5TnfUeXnyvN6pYf/8EKDAu66Lzy+mcvjrq7ASpZuSGH1JMW4y7okMY01781vr3U6v8uwkQNz5sWv4QTyljJr1SW+4XmTHLQbWG8dGxvCcqQUC68h2+tXTurU0t3jv8V3LDd75ytfw0YjzYI3pZB52wbggmsj5IlSbmbOF0nwUAsyZZTkMEySVRLFQBmsaTyeKmEKGgrfTLDmYOrlMvJAJpTjz4HF1ZJcYok3YVhjMXzwXVwd2jJPwzOfXLmbTRSS+CEbZVP7KDtKHbEzgfnj//d64jwB0bnWnnC/DDeHUP4qyEepHpm2DCiDiSHzMD73JZAD2YViuanPGdNSpjm/eXJ3/0jwdjhgwU90K1Zk56pE7N88fNp+DiiJWZ5U4ghzuuJxfnOrRg4HMwSNoRvzmm3ckgbMtUzXGAKeF0gryu5muIQssF+Ye7z0cTKaaqVdblalmgOj4gUszHLLjCC/m14Am0AVAH0KaOBu4rIB7qhU2rvzRd5+5sxbNdkNmPZ3Oz6dZtWWADjuehPQJCfZcPmealm5Zw1EH/l1vNyiGBcHnOWl9aQVLADYJRAeRhyV2sUCeM5mNAGHghATgHUYtyiN15PtkLsENW4NLt19r1IedkfXKIgIQKo5w7bVLtyqPnzeHUXLNsfRJvbJXrazOrxczrqpNdF1FvonE5taVG0k5NhpPRDF29+G9ufwC1hvWiHedtuq6MQXn2Vrenmkax4nn1lYm6kSR5I3Fjc5oWMoXHMeFrgGGDqYhxKCrqdtF1/f0dt89rg2VRNxgS64W3rjAIfOrdIce4ctifDDuITbHRWSx8Uwq4/pO72S4sbKbVjIxqJokKUvSeDyCnIKfsRYgZld3wL7ZZqeJmKWbBgGxA6GbobuTYTFVtPXpwvZGtzs5enL0l65BYhG8VDY9qFXV4XApx5xMkAr4/cno8vY1RVKQtFi2vTBXhhQJl0Ec6Q+GyCwOq/tBSG2tbiJvAA7LUnxhbg5uiUtiT0Cf2r2mLESRYqLNEvH4aNKHg2BLX2WHoKMErPQX7uQG7eHdh5NFglpeLdSb3em4s7GQvrJkTPoscseFfBmkHlkWkAsBDjIUYzApGUJsdi43D4HDsq1kIhHAOQMHWTnMAt+z6ZTER0pEb9jhBRkrgPw3Ugw8d7O8PjPUSk+1NL952Hnj9vp/eGpX+hasiZw5xBhGrOm7ty44XiS72LaTUnIRPssyEBgPg+/4A3I+PCGWBmFsv3J47cJNy9QCzx1OkX0Etcbxv//+vzmuHlm2WW1Wvn/3+8f1EzHGg3SPZ3gSA29NJBRktDBFrCn2/603L96+89X/9O/95+W55HRGWI49l0n+zFtz9jjojScQ1kxTxR4jZCKDfHL0+KNHn0Jv6k96wF2sO5RDvAWVCxCWwWiIWA7YSsRF37N6wy4SP2hoMBBAJmjYYNTt9tuGqT4+eppKsb166+pbN3taWO8hDScpbH46zlC+u33jcuO4WetB+aORfS7OzaeTSUWWkEcM1RFSADgIkjFQBghHw3EfWblpmriD/rj7/PCpAzZu6BvL55PJLIIIONzFnevl0hK84KRx/Ojl42KuzLCMpmmgWkgu184t/MTPvUnzQr5UAo4gbi0VRc+QfvrtAm0gx6aAuN0R+GYXmAIFDHD47Ts/89PvfBtcDKxkZ3UL4fzBiy9VbRpG3hCCgCLEwjWQHIFoTtUJ9hiYhZdRJCRlB0xM913dtdOpksKKi+e2+0Ot+vIUJvyjqAGQ9pR0snV8NO4P18t8u0LYrovFS8izZss4qp9ure7qJoAHq7NqWk4K2b5jUiSEXxh4+Gj/8c76Rah2i3PLABiOY4Cj8/l5KPCQlTzHhMp2YesqyJdpGJEPE0R2Pvnmz10JqUCdqEDZ4XikzaaK0C3ltVDrdWcJ8EUIE3DR56cvtyHVSQqy29P6yWg6ymdL+BmiC/CPpnn4PXQd1LUAAfhkxKwXh8+fHz+HAX+T5QvZghTj4YfDyUiJZ5Eltjv1lYIyswb6dNQ47V++sVb6TD/uWmCfEMjIW2t8MkasnN9+8LheG6cWissMy000DQ9z5dzlcq4gC9CXcghUMG+k/hCosFG5bK7ZrdEUv760OdNU09ShtuEHfCZktWQ8IXBsd9CZmcZiaekVlET1JIajvv6LN1mBHPX7B4f7pq5jJxOy5LjeSeWMcQVssmFBOplE12D50WycT+dmunrv6Weg2DGOi/GQZ7wXJwfn13ewjulEChwXeb2qa61efe90f2NlB2wahAqKT3/YBdB2R32QY7y3PexyDLT3apKsXrh9uz82/+B7lbHhI9iCe3Cvr7Ff+dotFLXuPp1N3dxicWG+UIYxgwjHOOa9e9/bPzssZgog6g4WA0lHNofIjGgF78plSnAc4CWw4PH+I9txkZshACM7xMM3+82YIIOS4gV4KpjQ1pXFtfP58WDw+//mDz9+/71mo7GzswssFGl/aTGNcNNstg1b9yDPhyGLAhFJg7xFjp3IIcs+PD2AVJOKRzoQwvl4OoRuhlACXAcWQP7aWN7KZ0rYsEImNxz1Xuk9PHIbpOs8y+aS6c6o45l7b7+zMpnax08PPzsyRroXycQMGX777RUmNGrHDUSgzixXgChk6cBk5E7dQbvSqF/d/Qr+BCUO7gRTr7ebeZBo3eBo/hVxMl9xJEgOybkCTJcbT1TkfJAJEE0FToS4hDtDyozlWDmfBfF58uWDP/vud5EJIB9ZXN2Ao37+578DhW5xcxMss9sbznTYF+RPHpsNb19fWAedOzzdG+uzYiYPzS7G8YbjFDIF27F7ox6CdFyUwXcsO6LVeG8iLkE3gQQLCxX5mG45Q3VYaRwhkGcS0lZp3KzUdy+tfPJ8WB9EKjZpumSnPRi2hxdunsdDIvTVOo0nR8+ns4ll6lCFzm9cyqVzMOBUMpFOxIuZlOfaTw9fiLIsyAJiBNQBmDFSQLzsrF6DCJ7LZKutOiA9FYVM5Dk0VgGmhACE7YSTt3s9ydMOjisr53ZTiTi0hrUrd86efRJYk4WV/PVbW0uLRcQ/RCusZn86BJNqtqtYzQtrO4APBLlIy4fvMFwxW8DnD2AaCJmurZtT2zFjMQHRDiogvOzp4RMgVFISE3Imm4E8cW4xx46a7ctvvzY0iWY/IlQRDy2m2NdWuds/dfvs5cmHD4Yzr5BLFzeWz8H8IGwhOsCocaNxWQCCNjsNBIVsJtPsdsALsNe9QSdaPpoWRRmaGxgOrPrw7BAyCsJKrVPj2BiyQy8KwGEszl+5vQHZojy/IGdLr91+c3t9xTRt1HFILtZtHAHb8uX19fWVb37zJzRdr9c6UdJJkBz03kwJqEmTdKQ1hJDRpJE6QbDH00Jtny+UpuoUukOlcSbjkZEBWFGi2el3CJoF9QgCDylwJC+5HuPXrt3K6IZz8vz48yN9pPtMlLeZXjyT6ddOJ/3RuQXh3ZdaIZ2HcALvgEmD3gIVsPiObXWGPcP2fIKFIg4J6JUAb0ML5XgZ4pVKjautaiqRhGculRdoihNjcgTybESrwD5AR8Q436idoLhs6hoZuDPk7yQpcsx4PEU5wk+sysWNjY319Y0tCBa/8jd/BpL+3rOqLMfHuoqLJuQkGAE0fphKvVtHKtkejSBeQ1bEriLLPm3VwEQzCQUEBDpdJJHkF6ARubb5KtOboeYI6Ub3E7PhcaejXrq8MHdPO+7ZUdSAXV1fRknI2b6y/ehp91mDidybYcALkL0jO0JFE2IGzFI3bUTQRBx1JwPlKmgBSBmOqscr86uQ/FGag0LJMjzce6oOo6JbGMZlqBIh+B9JRooWtOve+Agoe/fu3Wa7NZvpUQZuG4glx0dHkG2Tifj1W1/hxTgiIq4uxpijgypP4+NjU22KdAYKI6RH1JawvmBcY3WqiAr0HttCCd+HToG8w9CnyNxhLBT+kRByIUpEiTxuBmELcJ6V6lJQuXj7td7Y/Nffr05Q5gcXSCugit75r1w5ePCi2XeQJiPeIAGACobqNjscjif7AAKEwOXykuMGssi9OD7aXt9CqRpQijQnQlya8UL3qLoHxIYRbq/vur6NfgHcCB4PlTmEN4qmOt2RANTxThWIU5b09OCZNZOsVDqZZeqN5uJCOWQRImWQIoalDB0LNckU5E5NhYeitHJUPyykCoVMcbG4CEbSHrRQ9YQ4CM+F0SLTzSRStglYBGWG5ojiy49qUXRIBlN9wrso2Sm4j8C25re3er0J0CBi+1EaToaa4aVzmX71ZDwYrhb5cSA1u03gP6oGUJyRBQ/kFLw6YmAkmUqKH93/CJQxp6Qb3cbeyeFKeeNV4kcgNWr0e/lsGVSv1m2gpFLIztl+JMDTDOsGUYaKbNLouWMo4tNZtlj6G7/yC2q/1xtNXuy9yGdSjXbnjbfuAOTgRwayZc8bjMepTKxy2II+BqkSvPHF2SGqJBB7QBYH01EqWQKnAjSg8BVVZBgDN4xa8VHtCH99++pb2IDnx8/qvSZQTObj51a20a4xDQVDbTZrk2s3VoqfmZU+FCqEQ58c9IZJNn7h5oWzzgsQm0w6u7m0nVKUybSPNUWBl+PiSRn34VdqJyHJXNm5Vm+dPdl/ihw8KreinKOjhJlPRDKBoFmzUiLSY3Bn0FspjnYDl0T9lucNAFuCnU5sUPXzl7dy+RLSwpNmV1EUQONrt27kMhlInhzLWGYUkqEwMRzJCRToANRw2DmA0PZchJLJZLK5vI1AibQFajFMA2aP7BbvRYl8OJvduPAGx3MPnt8fzrQrO7egFQD7dRvmyfCB2mt0r779drPeaQ6gUL2qa6QkmqPCC69faZ/WK83oVtPxDILoVB19/OXHnVGPJgPokYNR5/nRC9N2ru1eR27/8OWDbKaUjTILTzNnfuhP9en+2QsXvB6VUFgfgc4az0VyG1gelHrC120TdRnIE25otbud5eW56unJq3KeC7S7fGF3fW0DNYzpeMxwPBIAmKzrWEj6EJ1QGUSFCaoydhj/Jto0Ch+CpOmgoQbgPOoGgPrqR1wblQvoFCxNQLmKVmT3KwkYeGkB4g3C7WQ27g56axd2uu1h46DK0REtjNxbN7xYXGke7E1G6vIc53lmAmmnGANflMVUOpEBn4UiCFllc2kdWhjIDBAWUVkSZDAFLAQEEp8MU7n0xvntMTWh81x8SbIFO4wRfsx3eZfgSDtwUKnDnWoq0W5PUAHb2t4AHMYk6fabb62tbWxsbuXzRYTex48fol6BPqB2qwUFAGZF0oBdFC9dbDsKqjQVcDEQVyZSd0JQDTguAgSqEC6iBvgrMA76GogZosba4hYIMDCYpoiJ2h/Ohkf1Y0Za0gb9zvHxlZtreXQARdVwknBCcjJWJ2Nz5+ZF2w5GmgoVcK/yEiX2167cTCWUwXiA+DEzIDrVqp0GlhxQur60hYXUQ72Xas3iU50xNEF3FGNf2xdWhX5iMEtptmybguHzPgEvpqCA+MBLyEQJKXfx4mVBhJ7GnB4fLK2srq6ulcoLiAf9brvXb5uGDp+NxVDLinRnACcaUpCDwEHA5Xgh6kWIx9Ftga5CERsKAwEZr7XrEIRH0wneC5YJf0mKiURMhmMi6wGCnrWroDzL81uLWX7UG12588bQpBu9HytUZFKKWpK2r+1Wnh2edT2OESBDQs9AvaXVg1qmoysD+TXAD7W1hTyqRpHJ5AH0BPdEf/Se/6dCyC+JS6zGu6TLzsdnBdvmgAk+OAdHUJIRQ+HS9Ew5FkdxDJ8DFnrhEgp/oT5TX758hvpuJp1wLX1/f/+sdgZAQu8OGZEFaB1uiM4bOD+aNP0Y7aILQ0KPRi6XAztCXRqeH7g+8GiqTZq9zsrCFpASkgc0a/wF6Q5Lo9GJh8kgP1yZW0Yg8XxSm04XXlvvdwbNgwoaNKOogSA0MzxOTvRqZ516b6PEds5gZTSsC4Vp9Cqt5IrAp+hyng8hFObQGw6RDi8U0ZuRKNMlowElQg3is96hli6lzn9tOyyLbpL0+sB419EIroPGKouDNukaUReQH6LrYvfS+ngw6nU7BwctSnjxrW+8jawknc2jouvCBdAc4DpIZ0GrACLd7hAyJKiixGMVjMGkj3+gFnExbRouQSETZ9FkwDLCQq6A6IYsHloWHtNy3SUEuESqP+5//uJBMdrgGMuhayWnjSvdrnbh8lLmY41ooEsMBMMjpmO13Zhc++otQWRg9qCMUdtOEOTSGZiZOhvC36KeOvTCRO0SUfEe4WNmaSWutKjMm6HXf6oFfb/9ceeL3/78k3/67tPfeX8yPTZyPW1l1hEHNm8HXGiHNoIIpOCLVzfjSWE0HEBFaXY0VMOBAa4f5PO5uVIRcQ6lPfwG+4HLoQ2LxVsDmITVGbVfnr10YOoxEfQJKuYr4Qt1MDTbRN02yI/IEP06nG5oR80T1FxQeQQlR/PmfGEpmymChoGb5dPktNe9dPt6X0NipcHHGZCDtMxQgXv+5k1kY6ctFzeABAn+DBuL+iIcABKBNpeJOpIlZaJrCgiaGJuqBGo2G0sby/zqc+KZpZGhGrIBa3q+1ocEYYIIzh8U4xcLVDnHaazfmwWQeC1qbj73tb96YzLp+a5ZrXcDV7+1nd/Y3AQqjvoDSMSolcD5o7iOFUJFGzUI/3A/sKqDGc9wl7cvkiFaH120rFimMzNmspwaTIalbAnaeaVRpQj02dGZVG55bqOUhfRdQMpT7zYW59bRNxTpSQQFQWj+1la/O67vn4rovEb4jBzVdHk5CRRF9+xKkcWqwPFgXWgPAVaDLEXh19QRmSCQFjIpXKk/6gOuHcfqDfrzxHxMiZFZgkTrKO0xPODXN5lgxASTkTl62rYlta50x8LEibkhH/7UT7/GsSHqjod7L3/w2QEtxoyDD/7dv/vgD95/0a6+QA/fa6/fxrZp6hQJtds68g7vVhqzkc0gYCEKYudg3XPFEgxnag5npo4NG06GTw+fg7nHeCmTzkeCDsOtlqHxkxAT2v0WVM9iOo2SkxJD6dgxAnnY7NcPjm/d3k4no6gBZ0SXKEQxv15p7X5lt/LHz7AzCIrAJEhyBGqHngcosn37FWMhYjw/mQ5gsaqpSoI4NVSJi6eZZDfXC9EhBM7Qd1mFcVoumQorR7qg8Nev5L76E2++bV2hpzA2JJHJ48PD6snhDz/8UCInN8qF92py4+BDgTWYbe4X/uP/yqX4Zr2Kr+lkcv9sOpnSKMCGBA2cRaiutVrl+RIEdUhYR41jlpQi9yEo1JZUYyYJEtQqcB941PLcPEkEqgoC4i3kyqjnQ91Arx9LhiI7nfaHV+58rdHs1aNqOMJaQKbjbGhqW1+70T5tnHXQ6UllU2lk9c1eDW2hyO103UT+p5uz/bN9lBLK+XngMrIHiALwAd6mmSYbxJBRwtVeBUk7oGNU0PRIkTBFV9wnf/1bXw0n1NRBjSfeajffe+97P/jBe4Q7uV7wHFdk5lffSK9++xvXivPLVZRcuu1+f3hwdPzRDz+W3AkhADIckXTrmgdVBnyKlulYDeIDwrUPQdJEjKIgGkHISkKM8307nykiQqGaDrqF9AGgAEIIeRWMA7YTiyV6g+Hyne0edJv907jIEUMbuQYBQgUCrY0GrVpvvci3DFHXZyAWa0ubaF6CPIcECcT+xcl+JlGC3qWbFmonoDfw5OF0Up8Ro2ky1M6oGBtSPgGBNkFDYbPRHIBqVpI5O2g1GycFZpGj6MbZ6UHlZP/ocGJMf/bqPJot5q9+47VrV4R4Gj0S9+5+CjoJmnja6n7x5YOs02HiKVBSzzA7LhAtyEqcwvtJclzmJbSyzsQAScT3n0yKyexacS6H5i7XxVogSUXSBbLbn/RXF9ehcRqGjgfRbAvS0Umjhjgy6fa6ff3yjY3k3aewCCg3kfj72gp6lezzty5XKr0XDaizmNrYSIjJKCLDBVkOGpQf0CulFTT7gOpDQBdY5mWj8Ul1jIqlx5CU0qWckJnjgxm6NBhSD+iACfWQaAZ0nHr78g23ie0Z//l3v08wrBKX/sZf/5U7f+UXN65+dWVlDYn10eH+J59+QvOx1998e21tc3tr51t/9Zu763MTTB/0/UQyfDjxVlKSQJPNsepYGmENPG3Emv1VSXdJ8vPTwVG3D9+J82i5DqBTICFFiO1OxkvFJXQFo1/RskxEADStNceja2tcPKhceONmZ2D9/vdOVdMHd0UhkHl9hb7+5hXUPD57MmpO07lUFr0fWCcg4quGZpgV8mnk8yjQANIRycxn9fpHJz0NJgduEPVd9YKxFXpkOPH9vku5qI5QoRNiH+Z3C1le8ftTzQr+1//rX/3Cz/7cG6+/VUbPGZg3h8578/PPP/vO995dWl751rd+Jp/LR8WkwK0cHhgIuZOjXnMao0ErLDdk7iAOSLzhhoOp67hhXGJzEnE8UgFTuI1Kuzs1TIWnxKjg6qMuq8QzADL0OuJJUExBuJvoU45TRGp87ZqEYH724uRx3emrbqRQGaYfsrHpsFs/aaP0+qIPwsaBMsGfYzwLdXyhsIDAk0+lEFbROgG49kn2fss00RGKCA4xAksWpEJaJU2CFugQeOsitXCZJENkyeZseHhWo9hMp3OMDBLlv067NZlOz2q15cWFj9/9kx988exv/9rf/bVf/TuQnlAT6Q8HvXb76PDAQmuQDxpONow8R2oOSZ1YMZvh4iku5vhosjw5nYCzqw7Fsb35jEDYxGm3BTqKLlyUelDxAMxD40fQRYoMDREM/dzKbn88NY2h2j+dqO7VW2upz+EaOtLw0PZJy/E7J91zVzbP3j1G+2PU9cOB6XPAm9XyaqffRlEDylcsJgNs0PL3rNYbay6meTB8gBIHki7CTNN8m0AdC76M+SLYENIDlFHdsLw1dzg4qbx83Os5SiLT6Xa7g1Gr05krz/93//x/ahzvpefmf/KrdwaDEZ6h1WydVs+6rYYTyVNStTczCaptk0lEREdf8FutUOq44dnUQ0l2ht5YnqZDQTdIPaZBEicDpjnqPzjeOz+/xDEcQgbCJyZdeEBpHCIxWjk8yJligAma0aU7b7XaarUZRY2orpFPcrcWqZtvXVaHow/vj3p6GnWqch5hLpKbQfIiFYjn0A0PyJhqM8j6P9yvQyllSKACuowcn+YDjJ64Hs3bhBRSIkNi3MCManNeCmMogdrXchz8yUCXNrxV0/RWqwN3/bPvv499ZpBbo282EX/86PHde3d70a4SFEpAFPXkyQPeHgwnel4IXCK4mIjy+7UEUMjHJA1on8gQhoeObCElkn2doTgZn2aaE0XgIXCigxW9Zcix0UyAGiKy+FeJPKuNn1+7kQA21Y/Ovjy1+qoTRQ3NcDi5AGpfeXm6mmcbBg90Qfqwd/ri8vbVTCZPDvuqAYE4gO6AbEi1/bHugE+5psMm0j6BZ6Fsl/R8zLFh1G1EpkyPD0ibdiyX6pAzasq5zAQdyqI4nrk//PhjZMrgStBa0aAVl0TEtd/9wz9A1Q+4PdNNNI3BKEGTUXavtQbnZDIIXYX01wtofSMETCo43kqS608IPmqIIHlaL8TZjkr6dBp5AZIDjFC0Rz3YJIYEJIipPpuIg1MSjV5rbW4JLmOFito/mJ12N3cWk/FJxCOg6gCFoMqevTy8dPvy6P0KGquRHQ9GAxAKKGXzBVG3TOjlSJ8Hk1G5tLDfhDprRvm/awoh6bsqTcXTmVV91o/WxhLJxoiUNJrXXk1KoERNM3FugKTTZDASkS1lp8Op45hQ/pBQOT7ILfqsOUh6vU778wdPJrOZwDFI82zHRxKLCaW5BOlK8b4bSKFtuq4kUHtNdWp6Mibt7BBp5lFXQ+GSIl2CEQnIQaEL1RuFDM2YwkvREhkRZJpBoZjjMQziyJw5HY0vvfNm5bh51npFqFCbjjpv9dnS9mUwtOMWkgsfFB/WCvYGnQqNc3hm8Eue4RfKK/hNZzQOaAmaJ0lhEIHG5BSe3hm3wVeg64WUEIQZ0hADO6BoC4QQRkQmGAekVxIyyznN9GaDsYpNR+c9EU50aErkT/7s2//Zf/IbTx492Ds86Q3HaCzELuHLociJR8DFVAjcbGBBw/bNacDqTqDwKJuHbhigUyokoodB3wLGEaL5DLQa65OcCY+Jo90SuQKyARTcIKzjgYBEmmEsbCwNkCmctaFCNCevBldMy4/JCvjE/Q8fp2MAhKARSZ3scnkjm45q/JA9EkoGxRWkHihfo95I+iqaxihKsGZ1RlQIVkJLAvQu8E3YLQQF6LUkkSMDUPMxNQ7YAloZwg7ntE7OyIGNLqs84UsYX/JCtOgAXh88fH5wcNBFM2YPfYMIZZEEjS88o8D5pViIF5fiTE91n/bdsevqGB4LcCkgMp4fr0dZHD2dADS0r0fzF8jlUT1OyZhUsfmAA9dGMwIYM1pZ0P3b1y11MJ3MhleuLymfoT/CiFwD/g4F5fTl0fXbO7OP6n4FwxqJtaV1zMTEYzL6ZsGgYjEJeVdU7KUZlCVxdcwPIS13XTawSUmEO/F0LOmoVQnVBhY7zQZyjkKTpDEC7dBfaCjQjgIN25Ggg/NzzGqCanvk6QA2FCdD9A1pv/Uvfsc2R6CtJMGhfIUZE5LGdMIsCOySHBABWRmGHUtshfFhNGuD37vRiBnCJIg9BGYuTofwOHTkYKYLUw2hgetamt0zFgsr0PUo+CZJwtJenrxcQXthb3rjJ9863G9U20jDMbMWkpgVJB1zbfcKOMFhPVLR0YiXlOMAG/T7PDt8tjS3jkwWu43CVx9t0Cj/wx6hzzvR9AAX9W7pvJQXOdeymkwsSxASD3ENxQPbYAKd4uM0KThuUmBikN5QeL47NU8cmwydoSESfJwgLMSIhxWIUTzFbdBcCl4XYiECnwmtY0M9q4fwM8N2Q1rBSAcLuibmULWB3cBzQfQouxp1HntofeYj2SowwQCQX82ihhu25LtTY7qRzU218aODLw0bwpewtL3URLPMcFTKiK0pIiAVvpLMAcbMp9/5IhNDAZoGMxuM+hjB6Q77C6UlKGtwLfgIbE8zbaAbTDdChwDTfyQGK4ECEjrzug3bQm6DlIPT1Y5l9lAqpDmR51GqaeKeaTHrWWMPxSA63vThjGRIo7E6hSVDBQhoBjqFZ/UdjSRjGN1A2EPjiUcmHAxloygBuwsZH1fDsEJAR9UwE9BAseHYsgfoSIOv8Lxi29GoGPSDqGE9DEvpPDADsgVc6PNnn1E0j0kjnmuMu48x8Ly1u0S/O44sAv9B7IKF7d1/dvHmpvZ52zvB+A9TbdfQlYXhK2whbggCMf5F9Wf0fwIRcSVaIKEHEpCPUV6xp6NW6OsI05j5Yz1Qtx60eAjrkLVMDXovlpKB4aDTBC8H7WTCnuNpAVRFNhVD24SfYPiEb546WhfBFY1xzgwiFdzeBM2FF0ATw7OjRYCMuI/nW4NU/KKBIUtYlVEFPIWI4tA5PRPghBuCpIgWYPRZ2I5+PGqnktBRLVStMol8VL4LJygpXvva6w+/OHw1yhQpVKEis7aulde2BTlx0jyL9HnPRcjBwAEakBACQfLgNeB5WDVoM5hbQncmxM6oeQl6IRc6ehvpDOAKq+Q7uDZELVSr0PgH0XIKTI1WBN+j4eIZfDri6CjvRtuAdUalDfO9rme10B5JUajxohswmrNiWAGyG+Iidh0lJMREn01hubFs8D7HGiF0O7YOHQl3E3UeAw+paNuAmXgP7m+ijSH1Z5QcqqeDCTpvCiDmKNyYAZ0tZfYf7QfabLEotdVxZBEIY6KopDKJD77zUGZAIojuuLdUXFWhgPoBz6FPA00ZLMzRcn1Uw2F4r9bBAB/0fcI2B0Al+Hl0czbMDCiOkAnL5n0valYnqWhaLnQxQIF+OotgEoSDl+E12GrcPwZowBpQbgJo4QmjNkLcFc0o6AGDM8ChcY8wXIJAGyFWAS+QSU6GbI1HJVz00MNGIHnjpn60tHgi3AN+g/FrVNeSLKs4AQWVrTsZSQJ2hYEs1qv1oPWv7sybfwrjfUWoVCSNSIQfHWxcWJ54He/YxZCHpR1+bWVGeROei1DD9whYlB/SrZn45Ng66sH+oPECa90YMbizbV6a8yRhYOj22YR73mUrIzQZYe4TMk8sdM3FDHttzt7I2hIbTq3B8YD4tMoMDfIrq+zFUoC5f56KIhBMxvGZw374rMvUplCwvWKC+NnzbAz7TLKW57xfoVQ38dPnqTinkoEO7odOJiwyzgZ42SOfdHzgaTLGfG2bWkjg11gbHdQMXQfopwEv8AjuWb+AVnwr6BCctHF194u7e/0pdgKuEZIJibVnWjy9mCikIOljz8nQ+vr8syWuGY+zmITGPBdG10UBfZbh5RJ18dvyb3288BcHLDxop6D/1re8lTjZGpH5uBuD7UfTj8F7e85/+wOir5NQRn/jnfBvXUPCj+kBF/U1pGrIk170wn/0QfBPvkXFqDApomZFiDQxNglUmITz4UD3f+9F8HuP2V+/Qf/8bjhRfeQ0AuMmGJgC90u7NprxMBdtuUQ0FkoEWTmaMfioRv2zu9TfukL9/bepWhfD5gjWlunB14Ox3hFZIhMLYn7xj6q3LIIrziWffvkSA+yr84n2ywFyjahmxgnxRCbx6fcfAdxY4Fqg+nqv5xHPJxaYTTZOQUrQABeYOY+HMUb7O7uV425haJG/9a2Z6FuPK05KwmNzEN5QKJUldjEZns+5HxnUP/wG+9fO+5WeN1CRKaK4gp7AyB2TTHAhS540pkWFa/QAz6HpU/WhrwgR/khs8GuXqZEZYGixPaBMj5pq/nIuypKN8ey0Qx73I77reqESI9JCqNnE0AhemyeD1+ECVrXHdDEgHwZtlYjHwLsQ5EhM5CgxJA2qbU9D1j1+WVs+vxpPp8aTGm4o8is8JLzm9GVlfQvit4jphNbYas5ivYmTFMPNYnR6QmMUnciBYchHVQ8jgaGj7SSbv3hxXOam+3Urr+C2iN7IkwWqMQnGmnfUBY75377Ifes89eke8gPvXIlaypASE4AMKRyB5T4bej2HTYrBzHTjIqHqwWIKiSuRi4NxEiDRX19z9/thRiZR7iqnyESMetH1Pz5180kmJRIFJczFI0gUObQd04pA7nX8C3nvdBCiM4pniJnppaVgTgkXU0Q5QeQVlOWBocAw37MnsUQimU09+vJkYgCYIkKF+TsGQy6p4qqSSZ282/TwybyE9H8xRWKlTY/8v++59Wl4rki8sxkuZigpFuoeIRDGN9bJJ3U/n0TnJfO/vW/t9/w7W+ybmwxatT47RsZN/up1TNVBbqcwigJY/GgP1bLw4jxZzvMnHQ9WkBKDkz6gAQyU+M5ztzENfmKTubmCiQcEpLAohjxL8CykH9QyId4j9pLo0wAQzmxERxIa1+9+7qRjxDd2mGycyMdJnIqA8ieYd0ZESImkknsnwVDzIdBiTghr0Z+hvaRDKw7kwidf7C0UUksluTWBeBvZaYDxidxc8t57z6O9okj0qQi0PrNxEAvqAhGx+WLod3zymxfZrBx21ADrjXtlQi8RCxcy7IuG29HCz0ehfkLcWCLee2Q8qPnZBFPiXRUMEfVPjvvtD7TGOBiaAZJ+jvE/PnDHZqRvoa1BhvxkE1Mv/GIYyE3/9TUamIrQJKONwQ41j4rmzJD2e1gIrEJ0RAWeFiLdICCeqaE3Cn/hOrGYJmtDQuRRuAtPRxHiTCzAB1EZEf/PS5+nCZ72kaeRLDd1ZuW4267pa5c3UScdjk4isMRrNZTDGfrw4f7iWr5vISZF85FwBBUnOqBvGAPlUQcBMZ+i13Phy2aQVUCfCbRzT81AYqj6wFvNM790jVwq+n9+4P2DP/MSbFiZkX/3dQq9RegNzsj0D54YZ0P/wZCY2GHvqbfX82uT8FSFAQdxgXhcD1KxEH11uKF8il3IEo/OQoWlmmNSs4jeDI0WgWoQMwvt5cCFYIzTbGQaoQyaRoonlkrUlWW60o0Ss7FOdHRgbajMU1UvTAhhXAgVkYhzqIyDHDPHI/R6mqhNKfkyZv0f3T+FyIaQj7oGAeR0NC1zcSGeyx2927I81KpI1WTO5TAWgDaE8NY6985FYneO7kz8oUGt5On3X9g9PfyiRn51NZIBemqwmiNeX6H+5hXut+8H//oJNixYTmNUjzJdD1uBtoi2iVWAkZM1NaiBUsAtKVgf3dO8kgLfob69Q/z8Zfqr57iJTjRVv5AITnpwAYB1UIQe4WFLQfQjihAXyM4wRB/2QjL8nb/OADvOeiESAEWiPqkELQ3iDWH6oJ84qwRldOLr6xyWAyDQ1cP/+vt+R3emFgoP1pPP9tbXSotzZn1kRQoV1hlSXG4u9cl7zzlovUieXVtkgfNYBpwzQG8W0ZuCcyKCvkrulMjDjl8d+n2H+ODUe3uZGYHj47EC7BvyjvAfvMlcmmN+8wM7LYZQHXDSCyWRrk+M0eX24y+YfZRmA6gR9iGuyHJ03sz1JRYjkM+rHpb1jTVmrIdn42DiBCB4SOGhkEMaiegjzJcKcwreDqpODTXmtAdtIkC42e+SP6j4qhuZMB4qH6eOewGgoa2GQyNad9AzDt/Bknmy251imA99Z802cpNXUUO1vIBhj59WSnOJhUIMXcnR0G10xExUssFwJ3Icw3Q1082D7DH0s4Z7NA7HdvC84/2rR1Atw7yIGWUYEcJYODbI15e5n99BIgaPpZCooWsIK2W9imG4JIwiStnwA4pFTAhtBy6Gk3Cqfac7ww9BQcG1qXsV7/M2umRCtLEZEUxEyIdmKawgapSGEww0BPJAorz5RJBAOcUKs1L4lZVI/sR6ZeNkb+ZbEV7SaYkAWK5liVddQtg2uKyPgygEkT6t9NF3h5uJCDk6MH3dEGRlYXvlpBc1LaFJEQ3NJSXUzAAhynQRXkMsLXbg/RfOp2f+Zxj+jhSR8I/27X92N/iyGloY6SZJTFQj1WMpZycHG0EHdCBQeCN1vkxjf16xbzxI9A/rgG9g6JBpYb2lBImImAApD1B5Jz586X33ODiZBthbdKVD44BuGdF0D+cqRDVAqDk4QAUSwB8/DT45Cve6oAlUXwvfXiZuL0J2wN9JANxSmqoNgz95Gn5yHH7nBfG4iaJAhAi6T/Ck8/z+4fpyspRDZ2/EzUkURXFqzsJa/pP3X0T6GjqDPAjQ5Mt2gG0NVeL377s/e5mWOWCbe2eTkgX2+K43Mn2kondWGWzOP/08uHwa/PpNVoyK1TRInsQSp303yUFKw9OGqRh5vUgeDKOgiHf98iUOVvCDCk5FiJJl7F5fD/6XTxA76ZxCTXV/O08stOmnw8iwiykaxS50FKTYyE2w4YgLQNCNHHU28P/9Iawk/LXLzFIOHbxocSAuFwCrZISsIdWZRv71bw+BU4AYiDvkODpQhsyITLc1vfTGJV032q8meKBQRZaJUbu9h8f5vLgwDMl9CGiB7oZZgcRtoTWuM7MfNKk3l4IYR01t4o1VujIM/s/Hwd+/I//qZfK05/zzT7y7df9By9/IkfVJxPZgHY9q/kaG1WwXURNB95evUAtZ9kkn+OYO+9ObZGvG4C5x5FLgEEOdgB57MPaKfeIt0YfgobDhz+1QH9dh14iUfl8N8wjsIdYFyg7OP2JwyNXJCMIaCQkYr7+wQOAgpYc1IiEQCk+29RBolZJCgQhyMh4cxZ4QJ2QJTEQua5MAvYGp0iImRc9ORq/8NIwIFUZcTFWjS+nFrcU/+/yZ4Xoy4cc5ZMHRSGl14KJa/kHFf3uFHsxQ3POlBPX6AnmvQb+15P/FYxejov/jL/Jt1c8pdLOHgnVQSjIPhu7zbvhzQYjDqeBEUyPE2Va/fIn8a+cjGenTk0i5TXAQoMPBBEkRDWKSFAJkTe8s4cwn7DmZl4JbZfJkEhhR4CBQnoyhxSOMNJBkDNXdAIUMMM5fvUS9tkLeXmM+PYwKjFFL4ThAJpuRiKmGcgFxrkD+k79CzyvogABSkAOL/i/+3AM38Szjyef7W7sr86XZ6asxBdhqBODr58qP7h1akaYMaAvRzQNm1Z16KZlCuDoa+oeDVwV6LxjO/KJCfG0lKv2v5Cg0iVT7oWFQh1X/qOWtRvPJVHMStvTwO/sgKVhraBgRJN078Q/7RGPsA0rW8pFuAHZfVMEZQCIAAAdwSURBVECoAuyVyMJ3cMxYFCYBjSBaX18lBWhgmKqnCQwYAR3wA2QAhCf8EsehgX3/4iVuXmG+qESH8K2nQ6SF1QlwNVpKYOogangiQNhAc5EBziwC9U2c4aVw5HSsXby+jW2rNqYRWCJ1U83oUKOTvaoUo1HFwPJnRC+nEKoRzCDM8vTtdXZJIT+qRmMnabQ8oB07RkOAjWQZpBio6/necRc6hX9+gQYreXLm9g0kUeGf7jvPWpgQg0+iD8hL8iFuIisRMNr96IQscj5Ng0GACCAD2MzS8MfjCcQP4CuOVguWU8TNMur7UUgC1wbcrqSptQwD/G5NfGA1Zhz3Wrh0gHPOkBaxLPkQmzEmtvM4Cygc4YA4MmxMEWuBbpHOMkVzXMQ2UXjwS4sljDS3a31ILdFCQNXAeL05g68xm5dWO1M0ygbbOSPJolZMonaHaIO7B1n8rO5PIaag6GrQMZ4563n/84fOUQfpAOgDKjSY46SrI+JPn7gP6t7jQRS0NTf4lw+dDyuwAtr2Qc+Q+dDdGfmnj4P3Dn0ccBang8YEW0djE8/lEXCJuzW0l1LIr2cWlOnoB9vGuAuEBgIhLBsLV1JR9o0tzUgALyrGYY1w4B3dmpLfe+H9ySHgPrxeJmtjpExgEBEhRhAdGOTIJKLpe+SkIWRGztamB08q5XImieMqo6QLshEqlU5QWsidHDYFRBCaeNr0/xilOwNABYRykAh2DIgfwf/+hb8qo88w/KxqVUf+uzXii064lfIAURwRAMzBknG9Z6Nw9Jf0aWD5/8cT/0qOnpeBVYRUCfu6j0nTZ0MI08Tv3ot4OoiGwJBNHKpHEA/bwR8+wF6DTEc9bfdahEBBGYsMBCyoqgZjVDwtcqCj3h69McaSKPPAm9CGfKKGJ9MQ6Pb9vaA1jEgEgiX+F6EUtgbXe9QAnQlxh7fWyIBiL7+21WiqaOvDQkSsFSnhja30YpZM5LKkZWRoSI7UfCFWHZjQVlfn+IO+uzQn7eRREfJ2V+WRFZyO/OX5OLpBMTM6l+OOe66MViqFPeh7pbyYknDaH3EHx/AwQVlhX9+QuzMXvT35jPC4icF9HpuoWf71RQHg1JwGiwWpM/NUh7i9DphGOyolysKLjp1QYkjJD/t+NhmbuZGRL+QEzcY6UkqcOxm6CRl96/TJyE0lBOjCI514bVGQ2bA9pYoZAS/A4JckMWcTD6eIgnSrOCwxGc+K1Bs7yaWtOZBLdTT7smKMo2aTSIQl/qM30zsl6tadS5Xn1XNXL7+4/2UxLxVXzr2898nquVWPUU6fPrr69lfrJ7Vpr3nujbf3P/80hfOhVjYe/+Dd1Z1zlCAd3b936a03O42+NW5t3nrr4fsfKoqwdu3G4w9/WFzEFE350Qcfb169jNMlKo+fXHvnjV6z3TmrX33njZOXh+gS3Lx68fHH90rzhdxC6dnd+6vndxAh9h8+v/bmrU6tiibx8zeuvPz8Prr/ljaWvvz4/tLmekwSDh4+PXft0rjbwXV3X7uOGhVKUBduXMQnxPPFhbWl5/fure1iLiFon5xtXbnQqhzxMrrAkuhQ01yqVW/idMj//o+bA0z5IcTCMOQYdb7IzaYGtHfLCc9d26keVR1SnF9MHOy1xQyadvzDg1a2oKiDPhpWl5YT3WptZoaFvFA5qBEsOtV9nNippGV9PDw86s7Nx4c4omRoJhNE/aQJ+SCZII+PWnRMijH28X4dRXvHnJ2eDTDbMGi3URXOFcVaBUchcrIcnmLeUEpRnlqvD4VEcjYeVRvjdE5u1bpjHSfCoVwM52N5ymo1BhjvQR2o0ZriBDjS05pdI5XhtdFoMIPyHjSrINEYPzBaPS2eiXcb7d40wMkRnqHKkvDgxP78eBqx/UiAjUQT4icvKGUpKIDqxugeBjsEEjmjE0CqDA3d131wZBI/QO7FeZu6jUMJcTSZb3nRC3BiJ6o8kIPUGQkjg9BmolWARc+ehyGhuIiaVnT8JjrkDQ19FGxCRKM8jm5kwMhxCpYgcTLtddUwHovQamqRmQRlm77hk6UkPdFCVDMkjsJixdEX4fi6Q+B4V4yFax6TS5DTKRo0oFmRMwOqOJ2VqfEsiMTzwEPCnsAxnDgsyI0Y6hjlYxxqI9L9GTF0EETC9x6PLBSswLmikZ8oB0CwB1QRkBULccrykdVAIwODQhEcAgnZGrsZjJATBKwoC0XLfUU9ZXpsRJlnUiD7mg/Shhfjh7QIbTKE7gK+gGwfiJuRIt6Ni+A1UCJjDIl8rD/zFPAEnAhm+lh9RGUIv/gNVHXwaGQcyGtBAZD+gs6jMwr1c9xVQiDRsoRXpmKUGh3M9v8Wcu44AIIwAI2Dk4v3P6OJ0Rji4ue9ghgGYweU/qhNhRYj2OyG5dDzm0Y3bapipHU/MYOjVglwfDGni6WU/HVJxziQ7/INynTJBMJK2P0B3g6XVpzCI5HAWlEDQS9toeopXIfcy+BdBTQwQ6NYhTH7BKd0gg+cXfFcKEqqKhk+QKnHmCybR2/YM1OD+utESR+OMASu8waCrpTnO0NxrgAAAABJRU5ErkJggg==";
  function rabbitBtn(id) {
    const b = scribeBtn(id); b.className = "sd-rabbit"; b.textContent = ""; b.setAttribute("aria-label", "ЯSCRIBE"); b.title = "ЯSCRIBE";
    const im = document.createElement("img"); im.src = RABBIT; im.alt = ""; im.draggable = false;
    im.onerror = () => { im.src = HERE + "rscribe-button.png"; };
    b.appendChild(im); return b;
  }
  function rabbitCss() {
    if (document.getElementById("sd-rabbit-css")) return;
    const s = document.createElement("style"); s.id = "sd-rabbit-css";
    s.textContent = ".sd-rabbit{all:unset;display:inline-flex!important;align-items:center;justify-content:center;flex:0 0 auto!important;width:40px!important;height:40px!important;" +
      "min-width:40px;padding:0!important;margin:0 0 0 6px!important;border:0!important;background:transparent!important;box-shadow:none!important;line-height:0;cursor:pointer;" +
      "visibility:visible!important;opacity:1!important;-webkit-tap-highlight-color:transparent;align-self:center}" +
      ".sd-rabbit img{width:40px!important;height:40px!important;display:block!important;border:0!important;background:transparent!important;pointer-events:none;object-fit:contain}" +
      "#chatlist .cl-top .sd-rabbit{margin:0 4px!important;width:34px!important;height:34px!important;min-width:34px}#chatlist .cl-top .sd-rabbit img{width:34px!important;height:34px!important}";
    (document.head || document.documentElement).appendChild(s);
  }
  // composer: image-only rabbit right of Send
  function composerScribe() {
    if (!IOS) return false;
    const f = document.getElementById("composer"); if (!f) return false;
    rabbitCss();
    let b = document.getElementById("sd-rsc-composer"); if (!b || b.className !== "sd-rabbit") { if (b) b.remove(); b = rabbitBtn("sd-rsc-composer"); }
    const send = f.querySelector('button[type="submit"]');
    if (send) { if (send.nextElementSibling !== b) send.insertAdjacentElement("afterend", b); } else if (b.parentNode !== f) f.appendChild(b);
    return true;
  }
  // 2.1.9.13: home rabbit withdrawn from the chat list (Rizal: "home" = the ЯBOWZR browser bar with GO, which is native SwiftUI
  // RFrameBar, not in the web page, so an egg cannot place a button there). Chat list is back to the 2.1.9.10 text ЯSCRIBE button.
  function homeScribe() {
    const h = document.getElementById("sd-rsc-home"); if (h) h.remove();
    const old = document.getElementById("sd-rsc-list"); if (old && old.hidden) old.hidden = false;
    return false;
  }
  function rabbits() { try { homeScribe(); composerScribe(); } catch (e) {} }
  let rabT = 0;
  function rabbitWatch() {
    if (window.__sdRabbitObs || !window.MutationObserver || !document.body) return;
    window.__sdRabbitObs = new MutationObserver(() => { if (rabT) return; rabT = setTimeout(() => { rabT = 0; rabbits(); }, 150); });
    window.__sdRabbitObs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "hidden"] });
    ["hashchange", "popstate", "pageshow", "focus"].forEach((ev) => addEventListener(ev, rabbits));
    document.addEventListener("visibilitychange", rabbits);
  }

  function wrapSend() {
    const S = window.ROS_SEND; if (typeof S !== "function" || S.__sd) return;
    const w = function (text) {
      const t = String(text == null ? "" : text).trim();
      if (/^\/?(RSCRIBE|SCRIBE)\b/i.test(t)) { toggleScribe(); return; }
      lastAsk = t; if (ASK.test(t)) say("NOTES write requested · waiting for the bot", "thinking");
      return S.apply(this, arguments);
    }; w.__sd = 1; window.ROS_SEND = w;
  }

  // ---------- NOTES ----------
  function mt(d) { try { const f = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Denver", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(d);
      const g = (k) => (f.find((x) => x.type === k) || {}).value; return `${g("year")}-${g("month")}-${g("day")} ${g("hour")}:${g("minute")}`; } catch (e) { return d.toISOString().slice(0, 16).replace("T", " "); } }
  function seatOf() {
    let c = null; try { c = window.ROS_CURRENT && window.ROS_CURRENT(); } catch (e) {}
    let rid = c && c.rid ? String(c.rid) : ""; rid = ALIAS[rid] || rid;
    const name = c && c.name ? String(c.name) : "";
    if (!/^ЯID-\d{4}-[0-9A-Z]{4}$/.test(rid)) { for (const k in SEATS) if (SEATS[k].includes(name)) rid = k; }
    return { rid, name: (SEATS[rid] || [])[0] || LATIN(name) || "bot" };   // 2.1.9.8: Latin roster name by ЯID (ЯВОТ/ЯBOT same seat)
  }
  async function seedBotableta() {
    const R = window.RL_RSCRIBE; if (!R || !R.notes) return false;
    const notes = R.notes;
    if (notes.NOTES && notes.NOTES.revs && notes.NOTES.revs.length) { notes.NOTES.pinned = true; return true; }
    try {
      const s = window.RL_NOTES_SEED || await readSeed();   // 2.1.9.8: file:// fetch is refused in the Mac WKWebView → script-tag seed first
      notes.NOTES = { created: new Date().toISOString(), revs: [{ rev: s.rev, page: s.page, at: new Date().toISOString(), from: "host-seed" }], chain: [], pinned: true, archived: false, title: "NOTES" };
      localStorage.setItem(LS, JSON.stringify(notes)); say("NOTES rev " + s.rev + " ready in ЯSCRIBE");
      return true;
    } catch (e) { say("NOTES seed not readable"); return false; }
  }
  async function appendBotableta(text, who) {
    const R = window.RL_RSCRIBE, DOC = window.RL_RSCRIBE_DOC; if (!R || !R.notes || !DOC) return { ok: false, why: "ЯSCRIBE not ready" };
    await seedBotableta();
    const n = R.notes.NOTES; const head = n.revs[n.revs.length - 1];
    const w = who || seatOf();
    if (!/^(ЯID-\d{4}-[0-9A-Z]{4}|EXT-[A-Z0-9]+)$/.test(w.rid)) { say("NOTES refused · no real ЯID on this thread", "error"); return { ok: false, why: "no ЯID" }; }
    const clean = String(text || "").replace(/\s*\([^()]*\)\s*$/, "").replace(/\s+/g, " ").trim().slice(0, 1200); if (!clean) return { ok: false, why: "empty" };
    const line = `${w.rid} · ${w.name} · ${mt(new Date())} MT: ${clean}`;
    const rev = (head ? head.rev : 0) + 1;
    const body = (head ? DOC.human(head.page.blocks) : "NOTES") + "\n\n" + line;
    const page = await DOC.page("NOTES", rev, DOC.parse(body), n.created, { display_title: "NOTES" });
    n.revs.push({ rev, page, at: new Date().toISOString(), from: "superdragon " + V });
    try { n.chain.push(await DOC.chainAppend(n.chain, { kind: "doc.edit", op: "append", name: "NOTES", rev, at: new Date().toISOString(), app: "superdragon " + V, rid: w.rid })); } catch (e) {}
    localStorage.setItem(LS, JSON.stringify(R.notes));
    try { const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosTranscript;
      if (h) h.postMessage({ cmd: "append", role: "system", ns: "notes", text: "NOTES rev " + rev + " · " + line.slice(0, 400) }); } catch (e) {}
    try { if (typeof window.RL_NOTES_SAVE === "function") window.RL_NOTES_SAVE("NOTES", rev, body); } catch (e) {}
    say(`NOTES @${rev} · ${w.name} wrote`, "success");
    return { ok: true, rev, line };
  }
  // IDENTITY-STAMP 2.1.9.7 (Rizal GO 2026-10-17 03:17 MT): asked for name / ЯID → the reply must carry the roster name (Latin or
  // Cyrillic look-alike) AND the seat ЯID, and no other roster name as its own; else it shows "<name> · <ЯID>." from the seat.
  const ID_ASK = /(your|bot)\s+(bot\s+)?name|your\s+(ЯID|RID|seat)|who\s+are\s+you/i;
  const HG = { "А":"A","В":"B","Е":"E","К":"K","М":"M","Н":"H","О":"O","Р":"P","С":"C","Т":"T","Х":"X","У":"Y" };
  const nz = (x) => String(x || "").replace(/[АВЕКМНОРСТХУ]/g, (c) => HG[c]).toUpperCase();
  function idStamp(ask, text) {
    if (!ID_ASK.test(ask || "")) return text;
    const W = seatOf(); if (!/^ЯID-\d{4}-[0-9A-Z]{4}$/.test(W.rid)) return text;
    const own = (SEATS[W.rid] || [W.name]).map(nz), T = nz(text);
    const hasName = own.some((n) => T.includes(n)), hasRid = text.includes(W.rid);
    const others = Object.keys(SEATS).filter((k) => k !== W.rid).flatMap((k) => SEATS[k]).map(nz);
    const wrong = others.some((n) => new RegExp("(NAME IS|I AM|I'M|THIS IS)\\s+" + n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b").test(T));
    const dodge = /^\s*(I DON'T KNOW|I DO NOT KNOW|I CAN'T|I CANNOT|SORRY)/.test(T);
    return (hasName && hasRid && !wrong && !dodge) ? text : `${(SEATS[W.rid] || [W.name])[0]} · ${W.rid}.`;
  }
  function wrapTurn() {
    const P = window.pushTurn; if (typeof P !== "function" || P.__sd) return;
    const w = function (role, text) {
      if (role === "bot") { const fixed = idStamp(lastAsk, String(text || "")); if (fixed !== text) { text = fixed; arguments[1] = fixed; } }
      const r = P.apply(this, arguments);
      if (role === "user") { lastAsk = String(text || ""); }
      if (role === "bot") { const W = seatOf(); say(`${W.name} answered`, "success"); if (ASK.test(lastAsk)) { lastAsk = ""; appendBotableta(text, W); } }
      return r;
    }; w.__sd = 1; w.__thundr = P.__thundr; window.pushTurn = w;
  }


  // ---------- 2.1.9.7 HEART ROUTE (Rizal GO 2026-10-17 03:17 'all green asap') ----------
  // Root cause r3: chatlist canHeart() = heartReply && bbIsIOS() and every non-local thread went to the local ЯBOWZR shell, so Mac
  // never reached the Heart. Now a plain message in a roster bot's thread goes to Botbridge POST /v1/heart/turn with THAT bot's own
  // ЯID → mouth-fused-turn.sh (seat mouth, notes lookup, identity guard + stamp) → reply here. The bridge appends the Ghost Chain line
  // and the NOTES rev (botableta.py). If the bridge is not reachable the original path runs unchanged.
  const LIVE = ["ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending"];
  function threadRid() {
    if (!document.body || !document.body.classList.contains("thread")) return "";
    const t = (document.querySelector("#thread-head .th-rid") || {}).textContent || "";
    const m = /ЯID-\d{4}-[0-9A-Z]{4}/.exec(t); const r = m ? m[0] : "";
    return r === "ЯID-pending" ? "ЯID-pending" : r;
  }
  function threadName() { const r = threadRid(); return (SEATS[r] || [])[0] || LATIN(((document.querySelector("#thread-head .th-name") || {}).textContent || "").trim()); }
  function show(role, from, text, source) {
    try { if (typeof transcript !== "undefined" && Array.isArray(transcript)) { transcript.push(role === "user" ? { role: "user", text } : { role: "peer", from, at: new Date().toISOString(), text, source }); if (typeof draw === "function") draw(); return; } } catch (e) {}
    try { window.pushTurn && window.pushTurn(role === "user" ? "user" : "bot", text); } catch (e) {}
  }
  async function heartTurn(rid, v) {
    const route = (typeof botbridgeRoute === "function") ? botbridgeRoute() : { url: "http://127.0.0.1:4873" };
    const hdr = (typeof bbHeaders === "function") ? bbHeaders(route, true) : { "content-type": "application/json" };
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 190000);
    const r = await fetch(route.url + "/v1/heart/turn", { method: "POST", headers: hdr, signal: ctl.signal,
      body: JSON.stringify({ rid, text: v, via: "app-thread", host: (/iPhone|iPad/.test(navigator.userAgent) ? "ios" : "macos") + "-" + V }) });
    clearTimeout(t); return r.json();
  }
  document.addEventListener("submit", async (ev) => {
    const m = document.getElementById("message"); const v = m && m.value.trim(); const rid = threadRid();
    if (!v || v.startsWith("/") || !LIVE.includes(rid)) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); m.value = "";
    const name = threadName() || (SEATS[rid] || [rid])[0];
    show("user", "", v); lastAsk = v;
    say(`Sending to ${name}'s Heart · ${rid}`, "working");
    try {
      const j = await heartTurn(rid, v);
      if (j && j.reply) {
        const reply = idStamp(v, j.reply);
        show("bot", `${name}`, reply, `Heart · ${j.mouth} · ${rid} · ${j.ms} ms${j.ghostchain && j.ghostchain.ok ? " · Ghost Chain ✓" : ""}${j.botableta && j.botableta.ok ? " · NOTES ✓" : ""}`);
        say(`${name} answered · ${Math.round((j.ms || 0) / 1000)}s${j.botableta && j.botableta.ok ? " · NOTES written" : ""}`, "success");
        if (ASK.test(v)) appendBotableta(reply, { rid, name });   // in-app ЯSCRIBE copy (the host note is written by the bridge)
        return;
      }
      say("Heart restarting… · answering on this device", "error");
    } catch (e) { say("Botbridge not reachable · answering on this device", "error"); }
    try { if (typeof respond === "function") await respond(v); } catch (e) {}
  }, true);

  // ---------- 2.1.9.7 pinned list order ----------
  const ORDER = ["ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending", "ЯID-pending"];
  let ordering = false;
  function pinOrder() {
    const ul = document.querySelector("#chatlist .cl-rows"); if (!ul || ordering) return;
    const rows = [...ul.children]; if (rows.length < 2) return;
    const rank = (el) => { const a = el.getAttribute("aria-label") || el.textContent || ""; const m = /ЯID-\d{4}-[0-9A-Z]{4}/.exec(a); const r = m ? (m[0] === "ЯID-pending" ? "ЯID-pending" : m[0]) : ""; const i = ORDER.indexOf(r); return i < 0 ? 100 : i; };
    const sorted = rows.map((el, i) => ({ el, i, k: rank(el) })).sort((a, b) => a.k - b.k || a.i - b.i).map((x) => x.el);
    if (sorted.every((el, i) => el === rows[i])) return;
    ordering = true; for (const el of sorted) ul.appendChild(el); ordering = false;
  }
  function watchOrder() { const ul = document.querySelector("#chatlist .cl-rows"); if (!ul || ul.__sd) return !!ul; ul.__sd = 1; new MutationObserver(() => pinOrder()).observe(ul, { childList: true }); pinOrder(); return true; }

  // ---------- LOCAL id display ----------
  const LOCAL = /LOCAL-[0-9A-Z]{4}-[0-9A-Z]{4}/g;
  function fixText(root) {
    const it = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT, null); const hits = [];
    for (let t = it.nextNode(); t; t = it.nextNode()) if (/LOCAL-[0-9A-Z]{4}-[0-9A-Z]{4}/.test(t.nodeValue)) hits.push(t);
    for (const t of hits) { const p = t.parentElement; if (p && /^(INPUT|TEXTAREA|SCRIPT|STYLE)$/.test(p.tagName)) continue; if (p && p.closest("#rscribe")) continue;
      t.nodeValue = t.nodeValue.replace(LOCAL, (m) => ALIAS[m] || "ЯID pending"); }
    // 2.1.9.8: Latin roster names on rows / thread head / turns (display only)
    const it2 = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT, null); const cy = [];
    for (let t = it2.nextNode(); t; t = it2.nextNode()) if (/ЯВОТ|ЯМАХ/.test(t.nodeValue)) cy.push(t);
    for (const t of cy) { const p = t.parentElement; if (p && /^(INPUT|TEXTAREA|SCRIPT|STYLE)$/.test(p.tagName)) continue; t.nodeValue = LATIN(t.nodeValue); }
    // 2.1.9.8: the built-in row for LOCAL-9SJ1-4JPK = ЯID-pending is BOT (former names ЯBOT / ЯBOT LOCAL, roster 0013-XXXX.json).
    // Relabel its display name only; the row, its ЯID and its seat are kept (never deleted or merged).
    const isBat = (el) => /LOCAL-9SJ1-4JPK|ЯID-pending/.test((el.getAttribute("aria-label") || "") + " " + (el.textContent || ""));
    const relabel = (el) => { const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      for (let t = w.nextNode(); t; t = w.nextNode()) if (/^\s*(ЯBOT|ЯВОТ)(\s+LOCAL)?\s*$/.test(t.nodeValue)) t.nodeValue = t.nodeValue.replace(/(ЯBOT|ЯВОТ)(\s+LOCAL)?/, "BOT");
      const a = el.getAttribute("aria-label"); if (a) el.setAttribute("aria-label", LATIN(a).replace(/^(ЯBOT)(\s+LOCAL)?(?=\s)/, "BOT").replace(LOCAL, (m) => ALIAS[m] || "ЯID pending")); };
    document.querySelectorAll("#chatlist .cl-row").forEach((el) => { if (isBat(el)) relabel(el); else { const a = el.getAttribute("aria-label"); if (a && (/ЯВОТ|ЯМАХ/.test(a) || LOCAL.test(a))) el.setAttribute("aria-label", LATIN(a).replace(LOCAL, (m) => ALIAS[m] || "ЯID pending")); LOCAL.lastIndex = 0; } });
    const th = document.getElementById("thread-head"); if (th && isBat(th)) relabel(th);
  }

  // ---------- app / egg narration ----------
  let lastMode = "";
  function narrateMode() {
    const b = document.body; if (!b) return;
    const m = b.classList.contains("listing") ? "chat list" : b.classList.contains("thread") ? "chat · " + seatOf().name : b.classList.contains("editing") ? "editing profile" : "bot view";
    if (m !== lastMode) { lastMode = m; say(m); }
  }
  function boot() {
    css(); pinMount(); say("egg superdragon " + V + " active · " + (navigator.onLine ? "online" : "offline") + " · Heart on board");
    window.addEventListener("online", () => say("online")); window.addEventListener("offline", () => say("offline · Heart on board"));
    document.addEventListener("visibilitychange", () => { if (!document.hidden) say("back · " + lastMode); });
    let n = 0; const iv = setInterval(() => { pinMount(); upgradeDragon(); buttons(); dragWire(); rabbits(); rabbitWatch(); wrapSend(); wrapTurn(); seedBotableta(); fixText(); narrateMode(); watchOrder(); if (++n > 40) { clearInterval(iv); setInterval(() => { pinMount(); buttons(); dragWire(); rabbits(); wrapSend(); wrapTurn(); narrateMode(); watchOrder(); fixText(); }, 1500); } }, 250);
    try { new MutationObserver((ms) => { for (const m of ms) for (const a of m.addedNodes) if (a.nodeType === 1 || a.nodeType === 3) fixText(a.nodeType === 1 ? a : a.parentNode || document.body); }).observe(document.body, { childList: true, subtree: true, characterData: false }); } catch (e) {}
  }
  window.RL_SUPERDRAGON = { version: V, say, log, appendBotableta, seedBotableta, toggleScribe,
    status: () => ({ pin: !!(pill && pill.isConnected), rscList: !!document.getElementById("sd-rsc-list"), rscThread: !!document.getElementById("sd-rsc-thread"), rabbitHome: !!document.getElementById("sd-rsc-home"), rabbitComposer: !!document.getElementById("sd-rsc-composer"),
      botableta: !!(window.RL_RSCRIBE && window.RL_RSCRIBE.notes && window.RL_RSCRIBE.notes.NOTES), sendWrapped: !!(window.ROS_SEND && window.ROS_SEND.__sd), turnWrapped: !!(window.pushTurn && window.pushTurn.__sd) }) };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
