/* public build: no seed data */
window.RL_NOTES_SEED = {"name":"NOTES","rev":0,"page":{"blocks":[]}};
