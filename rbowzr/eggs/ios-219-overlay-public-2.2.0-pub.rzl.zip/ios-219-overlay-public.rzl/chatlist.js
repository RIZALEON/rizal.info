"use strict";
// ЯBOWZR landing list 1.0.0 (Decider 2026-10-07 19:21 t221u + 19:23 t222u) — Grok Bot style chat list in front of the bot view.
// Row = avatar (+status dot where known) · bold NAME · full ЯID chip · time of latest reply · one-line summary · blue unread dot.
// Rows: every ЯID bot from the bridge-classroom roster (window.ROS_RID_LIST, bundled snapshot from ~/data),
// this device's own local bot(s), and real group threads from the record. Sorted by latest reply, newest first.
// Tap a row → that bot's / group's MAIN CONVERSATION page (thread + composer). The profile opens from the chat header (name/avatar).
// Never invents a reply ("No replies yet · <state>"). Live refresh: botbridge GET /v1/session/last on the paired route
// (token only from this device's own pairing storage — never bundled, never shown); offline → the snapshot stays, nothing breaks.
// 1.1.0 (t223u/t224u): NOTHING personal is bundled in public builds (rid-roster.js is an empty stub). Rows come at runtime from
//   (1) this phone's roster store (seated only by a verified, Decider-confirmed .rbotpack transfer · rosBotPack) and
//   (2) the paired BOTBRIDGE (GET /v1/klassroom/rid-list) — otherwise "Pair to see your classroom".
// 1.2.9 TRANSCRIPT LAW (Decider 2026-10-07 21:42 MDT t242u: "the chat logs transcripts manuscripts should never be removed again
//   hardcode that"): every roster + per-ЯID chat record this phone has seen is saved natively (TranscriptLaw.RosterThreads,
//   Application Support, append-only) and shown offline. Histories MERGE by ЯID (union) — a reload, re-pair, update or scrub never
//   replaces or clears them. There is no clear/delete path for them here or in native code.
// 1.2.9 (18) HARDCODE LAW + t250u (Decider 2026-10-08 10:19 MDT: "the bots are disappearing after every reboot/update … the add bot
//   button function is not working and the edit group chat button is missing"):
//   • the saved roster only GROWS (native union by ЯID); this phone's ORIGINALS seed is merged once from the Mac (never bundled)
//   • ＋ opens a sheet: New local bot (modal editor over the list — before it opened inside the hidden page and did nothing) ·
//     Add a bot by ЯID · New group. Added bots are saved append-only (ROSTER-ADDED.jsonl).
//   • ✎ Edit group on every group chat: name · project · description · member bots (add/remove) · other members. Saved append-only
//     (GROUP-EDITS.jsonl), synced to the paired BOTBRIDGE by group id (POST /v1/rid/group). Removing a member never deletes a bot,
//     its roster row or any transcript.
// ЯID Botbridge utility: ⚡ in the chat header (and /rid <ЯID> join|ping|open|open-klassroom|transfer-in|transfer-out in the composer,
//   yabowzr://botbridge?rid=…&action=…, the "Botbridge by ЯID" Shortcut). handoff/recall/stealth/wake stay locked.
(function chatList() {
  const BUNDLED = (window.ROS_RID_LIST && typeof window.ROS_RID_LIST === "object") ? window.ROS_RID_LIST : { rows: [], groups: [] };
  let SNAP = { rows: (BUNDLED.rows || []).slice(), groups: (BUNDLED.groups || []).slice(), generatedAt: BUNDLED.generatedAt };
  let rosterFrom = (BUNDLED.rows || []).length ? "bundled snapshot" : "";
  const nativeBP = (cmd, extra) => {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosBotPack;
    if (!h) return Promise.resolve({ ok: false, error: "no native host (browser preview)" });
    return h.postMessage(Object.assign({ cmd }, extra || {})).catch((e) => ({ ok: false, error: String(e) }));
  };
  const $ = (s, r = document) => r.querySelector(s);
  const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  function fmtTime(at, long) {
    if (!at) return "";
    const d = new Date(at); if (isNaN(d)) return "";
    const now = new Date();
    const t = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    if (long) return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + t;
    if (d.toDateString() === now.toDateString()) return t;
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return "Yesterday";
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  }
  window.ROS_FMT_TIME = fmtTime;

  const STATE_DOT = { callable: "on", "this-device": "on", "receiver-only": "idle", "rebuild-later": "later" };
  let byId = {};
  function reindex() { byId = {}; for (const r of SNAP.rows || []) byId[r.id] = r; }
  reindex();
  const idOf = (rid) => String(rid || "").replace(/^ЯID-/, "");
  // ── OWNER · Chief main control room (t231u) ── top-left avatar. Saved on THIS device (native owner/profile.json + avatar.png).
  // Linked ЯID = the owner the paired BOTBRIDGE names (rid-list "owner"); fresh public installs edit their own stock owner ("Chief").
  // Nothing about the Decider ships in the app: name/photo come from this device's saved profile or the paired roster at runtime.
  const OWNER_STOCK = { name: "Chief", title: "Main control room", description: "This device's owner · tap the top-left picture to change photo, name and description." };
  const PROF = (typeof PROFILES !== "undefined" && PROFILES) ? PROFILES : {};
  let ownerP = PROF.owner && typeof PROF.owner === "object" ? Object.assign({}, PROF.owner) : null;   // saved owner profile (null = never edited)
  let ownerRid = ownerP && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(ownerP.rid || "") ? ownerP.rid : null;
  function ownerRow() { return ownerRid ? byId[idOf(ownerRid)] || null : null; }
  function ownerEntry() {
    const r = ownerRow(), P = ownerP || {};
    const e = { key: "owner", seq: "owner", kind: "owner", rid: ownerRid, color: (r && r.color) || "#e85d2a",
      name: P.name || (r && r.name) || OWNER_STOCK.name,
      title: P.title != null ? P.title : ((r && r.title) || OWNER_STOCK.title),
      blurb: P.description || (r && (r.description || r.title)) || OWNER_STOCK.description,
      tile: P.avatar || (r && (r.avatarSrc || r.avatarData || (r.avatar ? "./" + r.avatar : null))) || null };
    e.glyph = [...e.name][0] || "C"; e.call = e.name;
    return e;
  }
  function applyOwner() {   // saved owner profile wins on this device: the owner's row, its chat header, group stacks and the bots rail
    if (!ownerP || !ownerRid) return;
    const r = byId[idOf(ownerRid)];
    if (r) { r.name = ownerP.name || r.name; if (ownerP.title != null) r.title = ownerP.title; if (ownerP.description) r.description = ownerP.description;
             if (ownerP.avatar) { r.avatarSrc = ownerP.avatar; r.avatarData = ownerP.avatar; } }
    for (const e of (typeof CLASSROOM_ROSTER !== "undefined" ? CLASSROOM_ROSTER : [])) {
      if (e.rid !== ownerRid) continue;
      e.name = ownerP.name || e.name; e.call = e.name; if (ownerP.title != null) e.title = ownerP.title; if (ownerP.description) e.blurb = ownerP.description; if (ownerP.avatar) e.tile = ownerP.avatar;
    }
  }
  // TRANSCRIPT LAW (t242u): histories MERGE by ЯID — union, deduped by at|from|text, oldest → newest. Never replaced, never cleared.
  const hKey = (h) => `${h.at || ""}|${h.from || ""}|${String(h.text || "").slice(0, 240)}`;
  const tms = (h) => { const t = Date.parse(String((h && h.at) || "").replace(/([+-]\d{2})(\d{2})$/, "$1:$2")); return isNaN(t) ? 0 : t; };
  function unionHist(a, b) {
    const m = new Map();
    for (const h of [...(a || []), ...(b || [])]) if (h && typeof h.text === "string" && h.text) { const k = hKey(h); if (!m.has(k)) m.set(k, h); }
    return [...m.values()].sort((x, y) => tms(x) - tms(y));
  }
  function newestOf(hist, ...cands) {
    let best = null;
    for (const h of [...cands, ...(hist || []).slice(-1)]) if (h && h.text && (!best || tms(h) > tms(best))) best = h;
    return best;
  }
  // merge a roster source (saved roster / store bots / bridge feed rows) — by ЯID, never duplicated; histories union, newest reply wins
  function mergeRows(rows, groups, from) {
    for (const r0 of rows || []) {
      if (!r0 || !r0.rid || r0.state === "retired") continue;   // retired ЯIDs stay merged (no IDs in the app)
      const id = r0.id || idOf(r0.rid);
      const cur = byId[id];
      const r = Object.assign({}, cur || {}, r0, { id, kind: "bot" });
      r.history = unionHist(cur && cur.history, r0.history);
      r.last = newestOf(r.history, cur && cur.last, r0.last);
      if (r0.avatarData) r.avatarSrc = r0.avatarData; else if (cur && cur.avatarSrc) r.avatarSrc = cur.avatarSrc;
      if (cur) Object.assign(cur, r); else SNAP.rows.push(r);
    }
    for (const g of groups || []) {
      const i = SNAP.groups.findIndex((x) => x.id === g.id);
      if (i < 0) { const n = Object.assign({}, g); n.history = unionHist([], g.history); n.last = newestOf(n.history, g.last); SNAP.groups.push(n); }
      else { const cur = SNAP.groups[i], n = Object.assign({}, cur, g); n.history = unionHist(cur.history, g.history); n.last = newestOf(n.history, cur.last, g.last); SNAP.groups[i] = n; }
    }
    reindex(); if (from) rosterFrom = from;
    applyExtras();
    applyOwner();
  }
  // ── t250u: group edits + bots added on this phone (native append-only logs; latest per id wins; never removes anything) ──
  let GROUP_EDITS = {}, extraNote = "";
  function applyGroupEdit(e) {
    if (!e || !/^grp-[a-z0-9-]{1,40}$/.test(e.id || "")) return;
    let g = (SNAP.groups || []).find((x) => x.id === e.id);
    if (!g) { g = { kind: "group", id: e.id, name: e.name || e.id, members: [], note: "group made on this phone", history: [], last: null, createdOnPhone: true }; SNAP.groups.push(g); }
    if (g.editedAt && e.editedAt && String(g.editedAt) > String(e.editedAt)) return;   // a newer edit (bridge / another device) already applied
    g.kind = "group";
    if (e.name) g.name = e.name;
    if (Array.isArray(e.members)) g.members = e.members.slice();
    if (Array.isArray(e.others)) g.others = e.others.slice();
    if (e.project != null) g.project = e.project;
    if (e.description != null) g.description = e.description;
    if (e.project) g.note = "Project · " + e.project;
    g.editedAt = e.editedAt || e.savedAt || g.editedAt;
  }
  function applyExtras() { for (const e of Object.values(GROUP_EDITS)) applyGroupEdit(e); }
  async function loadExtras() {
    const x = await nativeBP("rosterExtras");
    if (!x || !x.ok) return;
    for (const g of x.groups || []) if (g && g.id) GROUP_EDITS[g.id] = g;
    const add = (x.added || []).filter((a) => a && a.rid && !byId[idOf(a.rid)])
      .map((a) => ({ rid: a.rid, name: a.name || a.rid, title: a.title || "added on this phone", state: a.state || "added on this phone", note: a.note || "", addedOnPhone: true }));
    mergeRows(add, [], null);
  }
  // a group member is an ЯID bot ("0002-XXXX"), a local bot on this phone ("LOCAL-XXXX-XXXX"); "others" are free text (people, outside bots)
  function memberRow(id) { return byId[id] || localRows().find((l) => l.rid === id) || null; }
  function memberNames(g) { return [...(g.members || []).map((id) => (memberRow(id) || {}).name || id), ...(g.others || [])]; }
  // ── TRANSCRIPT LAW (t242u): the saved roster + per-ЯID threads (native, Application Support, append-only) ──
  async function loadSaved() {
    const r = await nativeBP("rosterGet");
    if (r && r.ok && r.roster && (r.roster.rows || []).length) {
      mergeRows(r.roster.rows, r.roster.groups || [], "this phone's saved roster (kept forever · shown offline)");
      if (r.roster.generatedAt && !SNAP.generatedAt) SNAP.generatedAt = r.roster.generatedAt;
      if (!ownerRid && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(r.roster.owner || "")) { ownerRid = r.roster.owner; linkOwner(); }
    }
    const t = await nativeBP("threadsRead");
    if (t && t.ok && t.threads) for (const [k, recs] of Object.entries(t.threads)) {
      const row = /^grp-/.test(k) ? (SNAP.groups || []).find((g) => g.id === k) : byId[idOf(k)];
      if (!row) continue;
      row.history = unionHist(row.history, recs); row.last = newestOf(row.history, row.last);
    }
    await loadExtras();
  }
  function persistThreads() {   // send everything shown; native appends only what is not on disk yet
    const threads = {};
    for (const r of SNAP.rows || []) if (r.rid && (r.history || r.last)) threads[r.rid] = unionHist(r.history, r.last ? [r.last] : []).slice(-200);
    for (const g of SNAP.groups || []) if (/^grp-/.test(g.id || "") && (g.history || g.last)) threads[g.id] = unionHist(g.history, g.last ? [g.last] : []).slice(-200);
    if (Object.keys(threads).length) return nativeBP("threadsAppend", { threads });
  }
  async function loadStore() {
    const st = await nativeBP("store");
    if (!st || !st.ok) return st;
    const rec = st.record || {};
    const recRows = {}; for (const r of rec.rows || []) recRows[r.rid] = r;
    const rows = (st.bots || []).map((b) => Object.assign({}, recRows[b.rid] || {}, { rid: b.rid, name: b.name, rosterName: b.rosterName, title: b.title, role: b.role,
      state: b.state, mouth: b.mouth, glyph: b.glyph, color: b.color, avatarData: b.avatarData, dossier: b.dossier, seat: b.seat, seatedOnPhone: true }));
    if (rows.length) { mergeRows(rows, rec.groups || [], "this phone's roster (transferred)"); if (rec.generatedAt) SNAP.generatedAt = rec.generatedAt; }
    storeInfo = st;
    return st;
  }
  let storeInfo = null, feedState = "";
  function isPaired() { try { const rt = typeof botbridgeRoute === "function" && botbridgeRoute(); return !!(rt && rt.token); } catch (e) { return false; } }

  // this device's own bots (stock ЯBOT with its alias-resolved ЯID + user-made bots) — last reply from the on-device transcript (REQ-19 file)
  // PREVIEW-OWN 2026-10-16: a line naming another seat's ЯID (and not this row's ЯID/alias) is never this row's preview
  function ownForeign(text, own) { const ids = String(text || "").match(/(?:ЯID-\d{4}-[0-9A-Z]{4}|LOCAL-[0-9A-Z]{4}-[0-9A-Z]{4})/g) || []; return ids.length > 0 && !ids.some((x) => own.indexOf(x) >= 0); }
  function localRows() {
    const out = [];
    const lastBot = [...(typeof persistedTranscript !== "undefined" ? persistedTranscript : []),
                     ...(typeof pastSessions !== "undefined" ? pastSessions.flat() : []), ...(typeof transcript !== "undefined" ? transcript : [])]
      .filter((l) => l && (l.bot ? /^LOCAL-|ЯID-0013-/.test(String(l.bot)) : !ownForeign(l.text, ["ЯID-pending","LOCAL-9SJ1-4JPK"])))   // AVATAR-ALIGN 2026-10-16: preview only this seat's own lines
      .filter((l) => l && l.role === "bot" && typeof l.text === "string" && !/^History restored ·|^── session /.test(l.text) && !/^(Hi|Hello) — I[’']m |side panel ready\.?\s*$/.test(window.ROS_UNSTAMP ? window.ROS_UNSTAMP(l.text) : l.text)).pop();   // GREETPREVIEW 2026-10-16: open-greeting never counts as last message / preview / sort
    for (const e of (typeof CLASSROOM_ROSTER !== "undefined" ? CLASSROOM_ROSTER : [])) {
      if (!(e.key === "stock-bot" || /^bot-/.test(e.key))) continue;
      const lastAt = lastBot && lastBot.at && !isNaN(Date.parse(lastBot.at)) ? lastBot.at : null;   // REQ-19 line ts (displayTurns "at")
      out.push({ kind: "local", id: "local:" + e.key, entry: e, name: e.name, rid: (window.ROS_RID_ALIAS || {})[e.rid || (typeof localId === "function" && localId(e.key))] || e.rid || (typeof localId === "function" && localId(e.key)) || "ЯID pending", formerRid: e.rid || (typeof localId === "function" && localId(e.key)) || null, title: e.title || "This phone",
                 state: "this-device", avatarSrc: e.tile || avatarDataUri(e),
                 last: e.key === "stock-bot" && lastBot ? { at: lastAt, text: lastBot.text, source: "this phone · transcript (REQ-19)", from: e.name } : null });
    }
    return out;
  }

  function avatarFor(row) {
    if (row.avatarSrc) return row.avatarSrc;
    if (row.avatarData) return row.avatarData;
    if (row.avatar) return "./" + row.avatar;
    return avatarDataUri({ color: row.color || "#444", glyph: row.glyph || [...(row.name || "?")][0] });
  }
  function allRows() {
    const rows = [...localRows(), ...(SNAP.rows || []).map((r) => ({ ...r })), ...(SNAP.groups || []).map((g) => ({ ...g }))];
    const t = (r) => (r.last && r.last.at) ? Date.parse(r.last.at) : (r.last ? 0 : -1);   // untimed record lines after timed ones; no reply last
    // ROSTER ORDER (Rizal 2026-10-16 17:32 MT): fixed display numbers 1 Rizal · 2 ЯВОТ · 3 ЯМАХ · 4 BOT · 5 BOT · 6 BOT · 7 BOT (0013 / local seat),
    // then the other bots by ЯID number, then groups by latest activity. Order is by ЯID, never by name.
    const ORD = { "ЯID-pending": 1, "ЯID-pending": 2, "ЯID-pending": 3, "ЯID-pending": 4, "ЯID-pending": 5, "ЯID-pending": 6, "ЯID-pending": 7, "LOCAL-9SJ1-4JPK": 7 };
    const num = (r) => { if (r.kind === "group") return 1e6; if (r.kind === "local") return 7; const id = r.rid || ""; if (ORD[id]) return ORD[id]; const m = /^ЯID-(\d{4})-/.exec(id); return m ? 100 + +m[1] : 5e5; };
    rows.forEach((r) => { const n = num(r); if (n < 1e5) r.rosterNo = n; });
    return sortRecent(rows, loadPins(), num);   // RECENTSORT 2026-10-16: pins first, then newest message first (rosterNo stays tied to each bot)
  }
  // RECENTSORT (Rizal standing rule 2026-10-16 18:20 MT): pinned rows on top in pin order; every other row by latest message time, newest first;
  // rows with no timed message after timed ones, tie-broken by roster number. Pins = ids in localStorage "rlab.ridlist.pinned.v1" (right-click a row to pin/unpin).
  /*RECENTSORT-BEGIN*/
  function sortRecent(rows, pins, num) {
    const ts = (r) => { const v = r && r.last && r.last.at ? Date.parse(r.last.at) : NaN; return isNaN(v) ? -Infinity : v; };
    const pi = (r) => { const i = (pins || []).indexOf(r.id); return i < 0 ? Infinity : i; };
    return rows.map((r, i) => [r, i]).sort(([a, ia], [b, ib]) => {
      const pa = pi(a), pb = pi(b);
      if (pa !== pb) return pa < pb ? -1 : 1;
      if (pa !== Infinity) return 0;
      const d = ts(b) - ts(a); if (d && !isNaN(d)) return d;
      if (ts(a) !== ts(b)) return ts(a) === -Infinity ? 1 : -1;
      return ((num ? num(a) : 0) - (num ? num(b) : 0)) || (ia - ib);
    }).map(([r]) => r);
  }
  /*RECENTSORT-END*/
  const PIN_KEY = "rlab.ridlist.pinned.v1";
  function loadPins() { try { const v = JSON.parse(localStorage.getItem(PIN_KEY) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function togglePin(id) { const p = loadPins(); const i = p.indexOf(id); if (i < 0) p.push(id); else p.splice(i, 1); try { localStorage.setItem(PIN_KEY, JSON.stringify(p)); } catch (e) {} return i < 0; }
  window.RL_CHATLIST_PIN = (id) => { const on = togglePin(id); try { if (!document.body.classList.contains("thread")) render(); } catch (e) {} return on; };

  // unread = latest reply newer than the last time this row was seen on this device (first run: everything counts as seen)
  const SEEN_KEY = "rlab.ridlist.seen.v1";
  let seen = {}; try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || "null") || null; } catch (e) { seen = null; }
  const firstRun = !seen; if (!seen) seen = {};
  function markSeen(row) { if (row.last && row.last.at) { seen[row.id] = row.last.at; try { localStorage.setItem(SEEN_KEY, JSON.stringify(seen)); } catch (e) {} } }
  function unread(row) { return !!(row.last && row.last.at && seen[row.id] && Date.parse(row.last.at) > Date.parse(seen[row.id])); }

  // ── DOM ──
  const list = mk("section"); list.id = "chatlist"; list.setAttribute("aria-label", "Chats");
  const top = mk("div", "cl-top");
  const me = mk("img", "cl-me"); me.alt = "Chief · main control room profile"; me.setAttribute("role", "button"); me.tabIndex = 0;
  me.setAttribute("aria-label", "Edit Chief main control room profile");
  const search = mk("input", "cl-search"); search.type = "search"; search.placeholder = "Search name · ЯID · reply"; search.hidden = true;
  const sBtn = mk("button", "cl-round", "⌕"); sBtn.type = "button"; sBtn.setAttribute("aria-label", "Search");
  const add = mk("button", "cl-round", "+"); add.type = "button"; add.setAttribute("aria-label", "New bot");
  const sp = mk("div", "cl-spacer");
  top.append(me, sp, search, sBtn, add);
  const ul = mk("div", "cl-rows"); ul.setAttribute("role", "list");
  const foot = mk("div", "cl-foot");
  list.append(top, ul, foot);
  document.body.prepend(list);

  const head = mk("div"); head.id = "thread-head";
  const back = mk("button", "th-back", "‹"); back.type = "button"; back.setAttribute("aria-label", "Back to chats");
  const who = mk("button", "th-who"); who.type = "button"; who.setAttribute("aria-label", "Open profile");
  const whoAv = mk("span", "th-av"); const whoTx = mk("span", "th-tx"); const whoName = mk("span", "th-name"); const whoRid = mk("span", "th-rid");
  whoTx.append(whoName, whoRid); who.append(whoAv, whoTx); head.append(back, who);
  const gedit = mk("button", "th-gedit", "✎"); gedit.type = "button"; gedit.setAttribute("aria-label", "Edit group"); gedit.hidden = true;
  const main = $("main"); main.prepend(head);
  const info = mk("section"); info.id = "thread-info"; info.hidden = true; document.body.append(info);

  let liveNote = "";
  function render() {
    const q = search.value.trim().toLowerCase();
    const oe = ownerEntry();
    me.src = oe.tile || avatarDataUri(oe);
    window.ROS_HEART_FROM = `${oe.name}${oe.rid ? " " + oe.rid : ""} (this device's owner)`;   // the heart's identity line names the sender
    ul.replaceChildren();
    const rows = allRows();
    if (firstRun) { for (const r of rows) markSeen(r); }
    for (const row of rows) {
      const hay = [row.name, row.rid, row.title, row.last && row.last.text].join(" ").toLowerCase();
      if (q && !hay.includes(q)) continue;
      const li = mk("button", "cl-row" + (row.kind === "group" ? " group" : "")); li.type = "button"; li.setAttribute("role", "listitem");
      li.setAttribute("aria-label", `${row.name}${row.rid ? " " + row.rid : ""}`);
      const av = mk("span", "cl-av");
      if (row.kind === "group") {
        const ms = (row.members || []).map(memberRow).filter(Boolean).slice(0, 3);
        av.classList.add("stack");
        ms.forEach((m, i) => { const im = mk("img", "st st" + i); im.src = avatarFor(m); im.alt = ""; av.append(im); });
      } else {
        const im = mk("img"); im.src = avatarFor(row); im.alt = ""; av.append(im);
        const dot = STATE_DOT[row.state]; if (dot) av.append(mk("span", "cl-dot " + dot));
      }
      const body = mk("span", "cl-body");
      const l1 = mk("span", "cl-l1");
      const nm = mk("span", "cl-name", row.name);
      l1.append(nm);
      if (row.kind !== "group") l1.append(mk("span", "cl-chip", row.rid || "no ЯID"));
      else l1.append(mk("span", "cl-chip grp", `${(row.members || []).length} bots${(row.others || []).length ? " + " + row.others.length : ""}`));
      const tm = mk("span", "cl-time" + (unread(row) ? " new" : ""), fmtTime(row.last && row.last.at));
      l1.append(tm);
      const l2 = mk("span", "cl-l2");
      const sum = mk("span", "cl-sum");
      if (row.last && row.kind !== "group" && ownForeign(row.last.text, [row.rid, row.formerRid, row.alias, "ЯID-pending", "LOCAL-9SJ1-4JPK"].filter(Boolean).filter((x) => row.kind === "local" || !/0013|LOCAL/.test(x)))) { /* PREVIEW-OWN: foreign-ЯID line hidden */ } else
      if (row.last) sum.textContent = (row.kind === "group" && row.last.from ? row.last.from + ": " : "") + (window.ROS_UNSTAMP ? window.ROS_UNSTAMP(row.last.text) : row.last.text).replace(/^\s*\[1\/3\][^\n]*\n?/, "").replace(/^\s*“[^”]{1,40}” says:\s*/, "").replace(/\n\((Heart|app identity)[^)]*\)\s*$/, "");   // Q1FIX preview only: strip stale [1/3] ledger citation header + footer; BOTWIN: preview without the stamp prefix
      else { sum.textContent = `No replies yet · ${row.state || "unknown"}`; sum.classList.add("none"); }
      l2.append(sum);
      if (unread(row)) l2.append(mk("span", "cl-unread"));
      body.append(l1, l2);
      li.append(av, body);
      if (row.kind !== "local") {
        const nub = mk("span", "cl-nub", "⚡"); nub.setAttribute("role", "button"); nub.setAttribute("aria-label", `Botbridge · ${row.name}`);
        nub.addEventListener("click", (ev) => { ev.stopPropagation(); openThread(row); openSheet(); });
        l1.append(nub);
      }
      if (loadPins().indexOf(row.id) >= 0) { li.classList.add("pinned"); nm.textContent = "📌 " + row.name; }   // RECENTSORT pin marker
      li.addEventListener("contextmenu", (ev) => { ev.preventDefault(); togglePin(row.id); render(); });   // RECENTSORT: right-click / long-press = pin · unpin
      li.addEventListener("click", () => openThread(row));
      ul.append(li);
    }
    if (!(SNAP.rows || []).length) {
      const card = mk("div", "cl-pair");
      card.append(mk("div", "cl-pair-t", "Pair to see your classroom"),
        mk("div", "cl-pair-s", feedState === "refused" ? "BOTBRIDGE refused this phone — pair again." : feedState === "offline" && isPaired() ? "This phone is paired, but your BOTBRIDGE isn't reachable from this network (it answers on your home Wi-Fi). Your classroom loads when you're back on it, and is then kept on this phone for good." : "Your Klassroom roster and latest replies load from your own BOTBRIDGE after pairing, or from a ЯID transfer (.rbotpack). Nothing personal ships inside the app."),
        mk("code", "cl-pair-c", "/botbridge pair http://<your-mac>.local:4873 <token>"));
      ul.append(card);
    }
    foot.textContent = `${rows.length} chats · ${rosterFrom ? "roster: " + rosterFrom : "no roster yet"}${SNAP.generatedAt ? " · record " + fmtTime(SNAP.generatedAt, true) : ""}${liveNote ? " · " + liveNote : ""}${ownerNote ? " · " + ownerNote : ""}${extraNote ? " · " + extraNote : ""}`;
  }

  function entryFor(row) {
    if (row.kind === "local") return row.entry;
    const key = row.kind === "group" ? row.id : "rid-" + row.id.toLowerCase();
    let e = CLASSROOM_ROSTER.find((x) => x.key === key);
    if (!e) {
      e = norm({ key, seq: key, name: row.name, call: row.name, rid: row.kind === "group" ? null : row.rid, kind: row.kind === "group" ? "group" : (row.role || "rbot"),
                 title: row.kind === "group" ? `${(row.members || []).length} bots` : row.title, color: row.color, glyph: row.glyph,
                 tile: row.kind === "group" ? null : (row.avatar ? "./" + row.avatar : null),
                 blurb: row.kind === "group" ? (row.note || "") : `${row.rosterName || row.name} · ${row.role || ""} · state ${row.state || "?"}${row.mouth ? " · mouth " + row.mouth : ""}` });
      if (typeof PROFILES !== "undefined" && PROFILES[key]) applyProfile(e, PROFILES[key]);
      CLASSROOM_ROSTER.push(e);
    }
    return e;
  }

  let current = null;
  function openThread(row) {
    current = row; markSeen(row);
    const e = entryFor(row);
    const local = row.kind === "local";
    selectProfile(e, { announce: true, card: false, greet: local });       // REQ-19: switching archives the visible session, never erases
    if (!local) {
      for (const h of row.history || []) transcript.push({ role: "peer", from: h.from, at: h.at, text: h.text, source: h.source });
      if (!(row.history || []).length) transcript.push({ role: "note", text: `No replies yet · ${row.state || "unknown"}. This bot has no reply in the classroom/bridge record.` });
      const mouthHint = row.mouth ? ` Live: /connect ${row.mouth} <message> through BOTBRIDGE.` : "";
      transcript.push({ role: "note", text: (row.kind === "group" ? `Group record · ${row.note || ""}.` : `Record · latest ${Math.min((row.history || []).length, 12)} line(s) from the classroom/bridge record.`) +
        ` Messages you type here go to ${row.kind === "group" ? "this group" : row.name}'s on-device Heart and are saved in this thread (offline).${mouthHint}` });
      draw();
    }
    setHeader(row);
    document.body.classList.add("thread"); document.body.classList.remove("listing");
    info.hidden = true;
    const msg = $("#message"); if (msg) msg.placeholder = `Message ${row.name}`;
    const lg = $("#log"); if (lg) requestAnimationFrame(() => { lg.scrollTop = lg.scrollHeight; });   // chat opens at the latest reply
  }
  function setHeader(row) {
    whoName.textContent = row.name;
    whoRid.textContent = row.kind === "group" ? memberNames(row).join(", ") : (row.rid || "");
    whoAv.replaceChildren();
    if (row.kind === "group") { (row.members || []).map(memberRow).filter(Boolean).slice(0, 3).forEach((m, i) => { const im = mk("img", "st st" + i); im.src = avatarFor(m); whoAv.append(im); }); whoAv.classList.add("stack"); }
    else { const im = mk("img"); im.src = avatarFor(row); whoAv.append(im); whoAv.classList.remove("stack"); }
    gedit.hidden = row.kind !== "group";   // t250u: ✎ Edit group on every group chat
  }
  function showList() {
    document.body.classList.remove("thread"); document.body.classList.add("listing"); info.hidden = true;
    if (current) markSeen(current);
    render();
  }
  function showInfo() {
    if (!current) return;
    info.replaceChildren();
    const close = mk("button", "ti-close", "Done"); close.type = "button"; close.addEventListener("click", () => { info.hidden = true; });
    info.append(close);
    if (current.kind === "group") {
      const eg = mk("button", "ti-close ge-open", "✎ Edit group"); eg.type = "button"; eg.addEventListener("click", () => openGroupEditor(current));
      info.append(mk("div", "ti-title", current.name), eg, mk("div", "ti-note", current.note || ""));
      if (current.project) info.append(mk("div", "ti-note", "Project · " + current.project));
      if (current.description) info.append(mk("div", "ge-desc", current.description));
      for (const o of current.others || []) info.append(mk("div", "ti-note", "Member · " + o));
      for (const id of current.members || []) {
        const m = memberRow(id); if (!m) { info.append(mk("div", "ti-note", "Member · " + id)); continue; }
        const b = mk("button", "ti-member"); b.type = "button";
        const im = mk("img"); im.src = avatarFor(m); b.append(im, mk("span", "ti-mn", m.name), mk("span", "ti-mr", m.rid));
        b.addEventListener("click", () => openThread(m)); info.append(b);
      }
    } else {
      info.append(profileCard(entryFor(current)));
      if (current.last) info.append(mk("div", "ti-note", `Latest reply · ${fmtTime(current.last.at, true) || "this phone"} · ${current.last.source}`));
      else info.append(mk("div", "ti-note", `No replies yet · ${current.state || "unknown"}`));
    }
    info.hidden = false;
  }
  back.addEventListener("click", showList);
  who.addEventListener("click", showInfo);
  sBtn.addEventListener("click", () => { search.hidden = !search.hidden; if (!search.hidden) search.focus(); else { search.value = ""; render(); } });
  search.addEventListener("input", render);
  add.addEventListener("click", () => openAddSheet());   // t250u: ＋ → New local bot · Add by ЯID · New group (was: an invisible editor)
  gedit.addEventListener("click", () => { if (current && current.kind === "group") openGroupEditor(current); });
  document.addEventListener("click", (ev) => { if (ev.target && ev.target.classList && ev.target.classList.contains("pe-save")) setTimeout(() => { if (!document.body.classList.contains("thread")) render(); }, 400); }, true);

  // live refresh (botbridge working group) — read-only GET, 3 s budget, silent when offline
  async function feed() {
    try {
      if (typeof botbridgeRoute !== "function") return;
      const route = botbridgeRoute();
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
      const r = await fetch(route.url + "/v1/klassroom/rid-list", { headers: bbHeaders(route), signal: ctl.signal }); clearTimeout(t);
      if (r.status === 401 || r.status === 403) { feedState = "refused"; return; }
      if (!r.ok) { feedState = "bridge " + r.status; return; }
      const j = await r.json();
      if (j && j.rows) {
        if (j.owner && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(j.owner) && j.owner !== ownerRid) { ownerRid = j.owner; linkOwner(); }
        mergeRows(j.rows, j.groups, "BOTBRIDGE (paired)"); SNAP.generatedAt = j.generatedAt; feedState = "ok";
        nativeBP("rosterSave", { roster: { rows: j.rows, groups: j.groups, owner: j.owner, generatedAt: j.generatedAt, left_out: j.left_out, law: j.law } });
        persistThreads();
        for (const e of Object.values(GROUP_EDITS)) {   // t250u: a group edit made offline syncs to the bridge once it is reachable
          const bg = (j.groups || []).find((x) => x.id === e.id);
          if (!bg || !bg.editedAt || String(bg.editedAt) < String(e.editedAt || "")) syncGroup(e);
        }
      }
    } catch (e) { feedState = "offline"; }
  }
  async function live() {
    try {
      if (typeof botbridgeRoute !== "function") return;
      await feed();
      const route = botbridgeRoute();
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 3000);
      const r = await fetch(route.url + "/v1/session/last", { headers: bbHeaders(route), signal: ctl.signal }); clearTimeout(t);
      if (!r.ok) { liveNote = `bridge ${r.status}`; render(); return; }
      const j = await r.json();
      const M = {}; for (const r of SNAP.rows || []) if (r.mouth) M[r.mouth] = r.id;   // mouth → row from the runtime roster (no IDs in the app)
      const g = (SNAP.groups || []).find((x) => x.id === "grp-botbridge");
      let n = 0;
      for (const turn of (j.turns || [])) {
        if (turn.type !== "turn" || !turn.reply || !turn.ts) continue;
        const at = new Date(String(turn.ts).replace(/([+-]\d{2})(\d{2})$/, "$1:$2")).toISOString();
        const rec = { at, text: String(turn.reply).replace(/\s+/g, " ").slice(0, 600), source: "live · botbridge /v1/session/last", from: (byId[M[turn.mouthId]] || {}).name || turn.mouthId };
        const row = byId[M[turn.mouthId]];
        if (row && (!row.last || Date.parse(at) > Date.parse(row.last.at || 0))) { row.last = rec; (row.history = row.history || []).push(rec); n++; }
        if (g && (!g.last || Date.parse(at) > Date.parse(g.last.at || 0))) { g.last = rec; (g.history = g.history || []).push(rec); n++; }
      }
      if (n) persistThreads();
      liveNote = `live bridge ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}${n ? ` · ${n} newer` : ""}`;
      if (!document.body.classList.contains("thread")) render();
    } catch (e) {   // offline: the saved roster + threads stay on screen (TRANSCRIPT LAW)
      if (feedState === "offline") { liveNote = "BOTBRIDGE not reachable from this network · saved chats shown"; if (!document.body.classList.contains("thread")) render(); }
    }
  }

  // ── owner editor (t231u) ──
  function nativeProfile(msg) {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosProfile;
    if (!h) return Promise.resolve({ ok: false, error: "no native host" });
    return h.postMessage(msg).catch((e) => ({ ok: false, error: String(e) }));
  }
  function linkOwner() {   // a saved owner profile remembers the ЯID the paired bridge named (no photo re-sent; native keeps avatar.png)
    if (!ownerP || ownerP.rid === ownerRid) return;
    ownerP.rid = ownerRid;
    nativeProfile({ cmd: "save", key: "owner", profile: { name: ownerP.name, title: ownerP.title || "", description: ownerP.description || "", linkRid: ownerRid }, avatar: null });
  }
  let ownerNote = "";
  async function syncOwner(profile, avatar) {   // paired only: POST /v1/rid/profile → bridge backs up, then updates the owner's roster entry
    if (!ownerRid) return "saved on this device · not linked to a ЯID (pair BOTBRIDGE to sync)";
    let route; try { route = botbridgeRoute(); } catch (e) { return "saved on this device · BOTBRIDGE not paired"; }
    if (!route || !route.token) return "saved on this device · BOTBRIDGE not paired";
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
      const r = await fetch(route.url + "/v1/rid/profile", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal,
        body: JSON.stringify({ rid: ownerRid, name: profile.name, title: profile.title || "", description: profile.description || "", avatarData: avatar || null }) });
      clearTimeout(t);
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) return `synced to ${ownerRid} on BOTBRIDGE (backup ${j.backup || "made"})`;
      return `saved on this device · bridge refused sync (${j.error || r.status})`;
    } catch (e) { return "saved on this device · BOTBRIDGE unreachable (sync later by saving again)"; }
  }
  function openOwner() {
    if (typeof openProfileEditor !== "function") return;
    const e = ownerEntry();
    openProfileEditor(e, { owner: true, onSaved: async (profile, avatar) => {
      ownerP = Object.assign({}, ownerP || {}, { name: profile.name, title: profile.title, description: profile.description, rid: ownerRid || (ownerP && ownerP.rid) || null });
      if (avatar) ownerP.avatar = avatar;
      if (typeof PROFILES !== "undefined" && PROFILES) PROFILES.owner = Object.assign({}, ownerP);
      applyOwner();
      if (current && ownerRid && current.id === idOf(ownerRid)) openThread(byId[current.id] || current);   // refresh the open chat header
      ownerNote = "Chief profile saved"; render();
      ownerNote = await syncOwner(profile, avatar); render();
      if (ownerRid && /^synced/.test(ownerNote)) setTimeout(() => { live(); }, 1500);
    } });
  }
  me.addEventListener("click", openOwner);
  me.addEventListener("keydown", (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); openOwner(); } });
  window.ROS_EDIT_OWNER = openOwner;

  // ── ЯID Botbridge utility ───────────────────────────────────────────────────────────────────────────────
  const ALLOWED = ["join", "ping", "open", "open-klassroom", "transfer-in", "transfer-out"];
  const LOCKED = ["handoff", "recall", "stealth", "wake"];
  function say(text, cls) { transcript.push({ role: "note", text }); if (document.body.classList.contains("thread")) draw(); }
  function sayPeer(from, text, source) { transcript.push({ role: "peer", from, at: new Date().toISOString(), text, source }); if (document.body.classList.contains("thread")) draw(); }
  // retired ЯIDs resolve to the bot they were merged into (from the runtime roster's left_out / mergedInto — no IDs in the app)
  function resolveRid(rid) {
    rid = String(rid || "");
    const lo = SNAP.left_out || {};
    for (const k of Object.keys(lo)) { const m = String(lo[k]).match(/merged into (?:ЯID-)?([0-9]{4}-[0-9A-Z]{4})/); if (m && rid.replace(/^ЯID-/, "") === k.replace(/^ЯID-/, "")) return "ЯID-" + m[1]; }
    return rid;
  }
  function klassroomRow() {
    return SNAP.groups.find((g) => g.id === "grp-chalkboard") || SNAP.groups.find((g) => /klassroom|classroom|chalkboard/i.test(g.name || "")) ||
      { kind: "group", id: "klassroom", name: "Klassroom", members: [], note: "pair BOTBRIDGE (or transfer the roster) to load the classroom record" };
  }
  function rowFor(rid) {
    if (!rid) return null;
    if (rid === "klassroom") return klassroomRow();
    rid = resolveRid(rid);
    if (/^grp-/.test(rid)) return SNAP.groups.find((g) => g.id === rid) || null;
    return byId[idOf(rid)] || null;
  }
  async function bridgeAct(rid, action, via) {
    action = String(action || "open").toLowerCase(); via = via || "app";
    if (rid && rid !== "ALL" && rid !== "klassroom" && !/^grp-/.test(rid)) { const to = resolveRid(rid); if (to !== rid) { say(`${rid} is retired · read-only alias of ${to}.`); rid = to; } }
    if (rid === "klassroom") rid = klassroomRow().id;
    if (LOCKED.includes(action)) { say(`${action} is LOCKED until the Decider approves it. Only join · ping · open · transfer (with your confirm) work by ЯID.`); return { ok: false, locked: true }; }
    if (!ALLOWED.includes(action)) { say(`Refused: ${action} is not a Botbridge action (join · ping · open · open-klassroom · transfer-in · transfer-out).`); return { ok: false }; }
    const row = rowFor(rid);
    if (action === "transfer-in") return transferIn(rid || "ALL", via);
    if (action === "transfer-out") return transferOut(rid || "ALL", via);
    const route = typeof botbridgeRoute === "function" ? botbridgeRoute() : { url: "http://127.0.0.1:4873", token: "" };
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), action === "ping" ? 200000 : 8000);
      const r = await fetch(route.url + "/v1/rid", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal,
        body: JSON.stringify({ rid, action, via, device: (window.ROS_INSTALL && window.ROS_INSTALL.rid) || "" }) });
      clearTimeout(t);
      if (r.status === 401 || r.status === 403) { say(`BOTBRIDGE refused this phone (${r.status}) — pair first: /botbridge pair http://<your-mac>.local:4873 <token>. ${rid || ""} state here: ${(row && row.state) || "unknown"}.`); return { ok: false, status: r.status }; }
      const j = await r.json();
      if (action === "ping" && j.ok && j.reply) sayPeer(j.name || rid, j.reply, `live · BOTBRIDGE /v1/rid ping (${via})`);
      else say(`⚡ ${action} · ${j.text || JSON.stringify(j).slice(0, 300)}`);
      if (action === "open-klassroom" && j.ok && (j.groups || []).length) { const g = SNAP.groups.find((x) => x.id === "grp-chalkboard") || SNAP.groups.find((x) => j.groups.includes(x.id)); if (g && via === "url") openThread(g); }
      return j;
    } catch (e) {
      say(`⚡ ${action} · BOTBRIDGE unreachable from this phone (offline or not paired) · ${rid || "?"} state: ${(row && row.state) || "unknown"} · nothing was sent.`);
      return { ok: false, offline: true };
    }
  }
  async function transferIn(rid, via, file) {
    let payload = null;
    if (file) payload = { file };
    else {
      const route = botbridgeRoute();
      try {
        const r = await fetch(route.url + "/v1/rbotpack?rid=" + encodeURIComponent(rid) + "&target=" + encodeURIComponent("ЯBOWZR phone"), { headers: bbHeaders(route) });
        if (r.status === 401 || r.status === 403) { say("Transfer-in needs a paired BOTBRIDGE (or open a .rbotpack from Files)."); return { ok: false }; }
        const j = await r.json(); if (!j.ok) { say(`Transfer-in: Mac could not build the pack (${j.error || "?"}).`); return j; }
        payload = { pack: j.pack };
      } catch (e) { say("Transfer-in: BOTBRIDGE unreachable · open a .rbotpack from Files instead · nothing changed."); return { ok: false, offline: true }; }
    }
    say(`Transfer-in ${rid} · verifying signature + sha256 · your confirm is required…`);
    const res = await nativeBP("import", payload);
    if (res.ok) {
      const x = res.result || {};
      say(`Transfer-in ✓ signer ${res.signer} · content ${String(res.contentSha256 || "").slice(0, 12)} · seated ${x.seated.length} · no-op ${x.noop.length} · replaced ${x.replaced.length} (backed up ${x.backups.length}) · refused ${Object.keys(x.refused || {}).length}`);
      await loadStore(); render();
    } else say(`Transfer-in ✗ ${res.rejected || res.why || res.error || "refused"}`);
    return res;
  }
  async function transferOut(rid, via) {
    const res = await nativeBP("export", { rid, target: "host-mac", share: via !== "bridge-only" });
    if (!res.ok) { say(`Transfer-out ✗ ${res.why || res.error || "refused"}`); return res; }
    say(`Transfer-out ✓ ${res.file} · ${res.bytes} bytes · sha ${String(res.sha256).slice(0, 12)} · content ${String(res.contentSha256).slice(0, 12)} · signer ${res.signer}`);
    try {
      const route = botbridgeRoute();
      const r = await fetch(route.url + "/v1/rbotpack", { method: "POST", headers: bbHeaders(route, true), body: JSON.stringify({ pack: res.pack }) });
      const j = await r.json(); say(`Mac: ${j.text || (j.ok ? "verified" : "rejected")}`);
    } catch (e) { say("Mac not reachable · the pack stays in Documents/ЯLAB/OUTBOX (share sheet / Files)."); }
    return res;
  }
  window.ROS_BRIDGE = bridgeAct;
  // header ⚡ sheet
  const bolt = mk("button", "th-bolt", "⚡"); bolt.type = "button"; bolt.setAttribute("aria-label", "Botbridge · Klassroom"); head.append(bolt);
  const sheet = mk("div"); sheet.id = "bridge-sheet"; sheet.hidden = true; document.body.append(sheet);
  function openSheet() {
    if (!current) return;
    sheet.replaceChildren();
    const rid = current.kind === "group" ? current.id : current.rid;
    sheet.append(mk("div", "bs-title", `Botbridge · ${current.name}`), mk("div", "bs-sub", `${rid || "local"} · ${current.state || (current.kind === "group" ? "group" : "")}`));
    const acts = current.kind === "group" ? [["join", "Join room"], ["open-klassroom", "Open Klassroom"]]
      : current.kind === "local" ? [["transfer-out", "Transfer roster out (ALL)"]]
      : [["join", "Activate · join"], ["ping", "Ping"], ["open-klassroom", "Open Klassroom"], ["transfer-in", "Transfer in from Mac"], ["transfer-out", "Transfer out to Mac"]];
    for (const [a, label] of acts) {
      const b = mk("button", "bs-act", label); b.type = "button";
      b.addEventListener("click", () => { sheet.hidden = true; bridgeAct(current.kind === "local" ? "ALL" : rid, a, "app"); });
      sheet.append(b);
    }
    if (current.kind !== "local") {
      const link = current.kind === "group" ? (current.id === "grp-chalkboard" || current.id === "klassroom" ? "yabowzr://klassroom" : `yabowzr://botbridge?rid=${current.id}&action=open`) : `yabowzr://botbridge?rid=${rid}&action=ping`;
      for (const [mins, label] of [[15, "Alarm · check in 15 min"], [60, "Alarm · check in 1 hour"]]) {
        const b = mk("button", "bs-act", label); b.type = "button";
        b.addEventListener("click", async () => { sheet.hidden = true; const r = await nativeBP("alarm", { rid, name: current.name, minutes: mins, action: current.kind === "group" ? "open" : "ping" });
          say(r.ok ? `⏰ Alarm set · ${current.name} · ${mins} min · local notification only` : `⏰ Alarm not set · ${r.error || "?"}`); });
        sheet.append(b);
      }
      const cl = mk("button", "bs-act", "Copy link · " + link); cl.type = "button";
      cl.addEventListener("click", async () => { sheet.hidden = true; const r = await nativeBP("copy", { text: link });
        if (!r.ok) { try { await navigator.clipboard.writeText(link); } catch (e) {} } say(`🔗 Copied ${link}`); });
      sheet.append(cl);
    }
    sheet.append(mk("div", "bs-lock", "handoff · recall · stealth · wake — locked until the Decider approves"));
    const c = mk("button", "bs-cancel", "Cancel"); c.type = "button"; c.addEventListener("click", () => { sheet.hidden = true; }); sheet.append(c);
    sheet.hidden = false;
  }
  bolt.addEventListener("click", openSheet);
  head.append(gedit);

  // ── t250u · ＋ sheet: New local bot · Add a bot by ЯID · New group ──
  function openAddSheet() {
    sheet.replaceChildren();
    sheet.append(mk("div", "bs-title", "Add to your classroom"), mk("div", "bs-sub", "Kept on this phone for good · adding never replaces or removes anything"));
    const nb = mk("button", "bs-act", "＋ New local bot · photo, name, job"); nb.type = "button";
    nb.addEventListener("click", () => { sheet.hidden = true;
      if (typeof newBot === "function") newBot({ modal: true, onSaved: (p, a, saved, entry) => { extraNote = `new bot ${(entry && entry.rid) || p.name} saved on this phone`; render(); } }); });
    const form = mk("form", "bs-form");
    const ridIn = mk("input", "pe-in"); ridIn.placeholder = "ЯID-pending or LOCAL-XXXX-XXXX"; ridIn.setAttribute("autocomplete", "off"); ridIn.setAttribute("autocapitalize", "characters"); ridIn.setAttribute("aria-label", "ЯID");
    const nmIn = mk("input", "pe-in"); nmIn.placeholder = "Name (optional)"; nmIn.maxLength = 40; nmIn.setAttribute("aria-label", "Name");
    const go = mk("button", "bs-act", "Add bot by ЯID"); go.type = "submit";
    const st = mk("div", "bs-sub");
    form.append(ridIn, nmIn, go, st);
    form.addEventListener("submit", async (ev) => { ev.preventDefault(); const r = await addByRid(ridIn.value, nmIn.value); st.textContent = r.text; if (r.ok) setTimeout(() => { sheet.hidden = true; }, 700); });
    const ng = mk("button", "bs-act", "＋ New group · name, project, members"); ng.type = "button";
    ng.addEventListener("click", () => { sheet.hidden = true; openGroupEditor(null); });
    const c = mk("button", "bs-cancel", "Cancel"); c.type = "button"; c.addEventListener("click", () => { sheet.hidden = true; });
    sheet.append(nb, form, ng, c);
    sheet.hidden = false;
  }
  async function addByRid(raw, name) {
    const v = String(raw || "").trim().toUpperCase().replace(/\s+/g, "");
    let rid = null, m;
    if ((m = v.match(/^(?:ЯID-|RID-)?(\d{4}-[0-9A-Z]{4})$/))) rid = "ЯID-" + m[1];
    else if (/^LOCAL-[0-9A-Z]{4}-[0-9A-Z]{4}$/.test(v)) rid = v;
    if (!rid) return { ok: false, text: "That is not an ЯID (ЯID-pending or LOCAL-XXXX-XXXX)." };
    if (byId[idOf(rid)] || localRows().some((l) => l.rid === rid)) { extraNote = `${rid} is already on your roster`; render(); return { ok: true, text: `${rid} is already on your roster.` }; }
    const row = { rid, name: String(name || "").trim().slice(0, 40) || rid, title: "added on this phone", state: "added on this phone", addedBy: ownerEntry().name };
    const r = await nativeBP("rosterAdd", { row });
    if (r && r.ok === false && !/no native host/.test(r.error || "")) return { ok: false, text: "Not saved on this phone — try again." };
    mergeRows([row], [], null); extraNote = `${rid} added`; render();
    feed().then(() => render()).catch(() => {});   // the paired bridge fills in its real name/state if it knows this ЯID
    return { ok: true, text: `${rid} added · kept on this phone for good` };
  }

  // ── t250u · ✎ Edit group (name · project · description · member bots · other members) ──
  function newGroupId() { return "grp-p" + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36).padStart(2, "0"); }
  function openGroupEditor(g0) {
    const isNew = !g0;
    const g = g0 || { kind: "group", id: newGroupId(), name: "", members: [], others: [], project: "", description: "", createdOnPhone: true };
    info.replaceChildren();
    const bar = mk("div", "ge-bar");
    const cancel = mk("button", "ti-close", "Cancel"); cancel.type = "button";
    const save = mk("button", "ti-close ge-save", "Save"); save.type = "button";
    bar.append(cancel, mk("div", "ti-title", isNew ? "New group" : "Edit group"), save);
    const lab = (t, f) => { const l = mk("label", "ge-lab", t); l.htmlFor = f; return l; };
    const nameIn = mk("input", "pe-in"); nameIn.id = "ge-name"; nameIn.maxLength = 80; nameIn.value = g.name || "";
    const projIn = mk("input", "pe-in"); projIn.id = "ge-proj"; projIn.maxLength = 120; projIn.value = g.project || ""; projIn.placeholder = "What they're working on";
    const descIn = mk("textarea", "pe-in"); descIn.id = "ge-desc"; descIn.maxLength = 1200; descIn.rows = 4; descIn.value = g.description || "";
    const othIn = mk("textarea", "pe-in"); othIn.id = "ge-oth"; othIn.rows = 3; othIn.value = (g.others || []).join("\n"); othIn.placeholder = "One per line · people, outside bots (SuperGrok, outside-bot …)";
    const memBox = mk("div", "ge-mems");
    const cands = [...localRows().map((l) => ({ key: l.rid, row: l })), ...(SNAP.rows || []).map((r) => ({ key: r.id, row: r }))]
      .filter((c, i, a) => c.key && a.findIndex((x) => x.key === c.key) === i);
    for (const id of g.members || []) if (!cands.some((c) => c.key === id)) cands.push({ key: id, row: { name: id, rid: id } });
    const picked = new Set(g.members || []);
    for (const c of cands) {
      const l = mk("label", "ge-mem"); const cb = mk("input"); cb.type = "checkbox"; cb.checked = picked.has(c.key); cb.value = c.key;
      const im = mk("img"); im.src = avatarFor(c.row); im.alt = "";
      l.append(cb, im, mk("span", "ti-mn", c.row.name || c.key), mk("span", "ti-mr", c.row.rid || c.key));
      memBox.append(l);
    }
    const st = mk("div", "ti-note");
    info.append(bar, lab("Name", "ge-name"), nameIn, lab("Project", "ge-proj"), projIn, lab("Description", "ge-desc"), descIn,
      mk("div", "ge-lab", "Member bots · tick to add, untick to remove"), memBox, lab("Other members", "ge-oth"), othIn,
      mk("div", "ti-note", "Removing a member only changes this group. The bot, its roster row and every chat transcript stay forever (HARDCODE LAW)."), st);
    cancel.addEventListener("click", () => { info.hidden = true; });
    save.addEventListener("click", async () => {
      const name = nameIn.value.trim();
      if (!name) { st.textContent = "Name cannot be empty"; nameIn.focus(); return; }
      const e = { id: g.id, name, project: projIn.value.trim(), description: descIn.value.trim(),
        members: [...memBox.querySelectorAll("input[type=checkbox]")].filter((x) => x.checked).map((x) => x.value),
        others: othIn.value.split("\n").map((x) => x.trim()).filter(Boolean).slice(0, 32),
        editedAt: new Date().toISOString(), createdOnPhone: !!(isNew || g.createdOnPhone), device: (window.ROS_INSTALL && window.ROS_INSTALL.rid) || "" };
      save.disabled = true; st.textContent = "Saving on this phone…";
      const r = await nativeBP("groupSave", { group: e });
      if (r && r.ok === false && !/no native host/.test(r.error || "")) { save.disabled = false; st.textContent = "Not saved — try again."; return; }
      GROUP_EDITS[e.id] = e; applyGroupEdit(e);
      const row = (SNAP.groups || []).find((x) => x.id === e.id);
      info.hidden = true;
      if (isNew && row) openThread(row);
      else if (row && current && current.id === row.id) { current = row; setHeader(row); }
      extraNote = `group "${name}" saved on this phone`; render();
      extraNote = await syncGroup(e); render();
    });
    info.hidden = false;
    (isNew ? nameIn : projIn).focus();
  }
  async function syncGroup(e) {   // paired only: POST /v1/rid/group → the bridge backs up, then records the edit by group id
    let route; try { route = botbridgeRoute(); } catch (x) { return "group saved on this phone · BOTBRIDGE not paired"; }
    if (!route || !route.token) return "group saved on this phone · BOTBRIDGE not paired (syncs once paired)";
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch(route.url + "/v1/rid/group", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal, body: JSON.stringify(e) });
      clearTimeout(t);
      const j = await r.json().catch(() => ({}));
      return r.ok && j.ok ? `group synced to BOTBRIDGE (${e.id})` : `group saved on this phone · bridge refused sync (${j.error || r.status})`;
    } catch (x) { return "group saved on this phone · BOTBRIDGE unreachable (syncs when back on your Wi-Fi)"; }
  }
  // composer: /rid <ЯID|ALL|grp-…> <action>
  document.addEventListener("submit", (ev) => {
    const m = $("#message"); const v = m && m.value.trim();
    const mm = v && v.match(/^\/rid\s+(\S+)\s+([a-z-]+)\s*$/i);
    if (!mm) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); m.value = "";
    const rid = /^grp-/i.test(mm[1]) ? mm[1].toLowerCase() : mm[1].toUpperCase().replace(/^RID-/, "ЯID-");
    transcript.push({ role: "note", text: `/rid ${rid} ${mm[2].toLowerCase()}` }); draw();
    bridgeAct(rid, mm[2], "app");
  }, true);
  // KLASSROOM talk-through-bridge (Decider 2026-10-08 20:25 MT, additive): in a group the bridge marks with a mouth (e.g. grp-klassroom-ai →
  // "klassroom"), a plain message goes to BOTBRIDGE POST /v1/connect → the bridge fans it out to every member's own path; replies come back
  // into the thread and the bridge transcript. "/…" commands and every other thread keep the local ЯBOWZR shell exactly as before.
  async function groupSend(row, v) {
    const route = botbridgeRoute();
    transcript.push({ role: "user", text: v }); draw();
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 200000);
      const r = await fetch(route.url + "/v1/connect", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal,
        body: JSON.stringify({ from: (typeof seatMouthId === "function" ? seatMouthId() : "yabowzr"), to: row.mouth, text: v }) }); clearTimeout(t);
      const j = await r.json().catch(() => ({}));
      for (const line of String(j.reply || j.text || "").split("\n").filter(Boolean)) { const i = line.indexOf(": "); sayPeer(i > 0 ? line.slice(0, i) : row.name, i > 0 ? line.slice(i + 2) : line, "live · BOTBRIDGE /v1/connect → " + row.mouth); }
      if (!j.ok) transcript.push({ role: "note", text: "BOTBRIDGE: " + (j.refused || j.error || j.text || ("HTTP " + r.status)) });
      transcript.push({ role: "note", text: "SuperGrok, outside-bot and Grok Bot answer on their own paths (seat_reply · outside-bot turn-in · RBOTBRIDGE); their replies appear here on the next refresh." }); draw();
      feed();
    } catch (x) { transcript.push({ role: "note", text: "BOTBRIDGE unreachable · message not sent (pair on your Wi-Fi, then send again)" }); draw(); }
  }
  document.addEventListener("submit", async (ev) => {
    const m = $("#message"); const v = m && m.value.trim();
    if (!v || v.startsWith("/") || !current || current.kind !== "group" || !current.mouth || typeof botbridgeRoute !== "function") return;
    const route = botbridgeRoute(); if (!route || !route.url) return;               // not paired → unchanged local behavior
    ev.preventDefault(); ev.stopImmediatePropagation(); m.value = "";
    groupSend(current, v);
  }, true);
  // SKILLS (klassroom-chatlist 1.0.2, additive): data-only skill eggs (rlab.skill.v1, autoload all-sessions) in this overlay's skills/<id>/
  // add their one systemLine to every heart prompt — same contract as ЯBOT's bots-panel SKILLS_AUTOLOAD_1. Skipped where a loader exists.
  (function skillsAutoload() {
    if (typeof skillsContextLine === "function" || typeof heartReply !== "function" || window.RL_SKILLS) return;
    const get = (u) => { try { const x = new XMLHttpRequest(); x.open("GET", u, false); x.send(); return (x.status === 0 || x.status === 200) && x.responseText ? JSON.parse(x.responseText) : null; } catch (e) { return null; } };
    const ov = get("./.overlay.json"), lines = [], loaded = [];
    for (const e of (ov && ov.eggs) || []) {
      const s = e && e.id && get(`./skills/${e.id}/skill.json`);
      if (s && s.schema === "rlab.skill.v1" && s.autoload === "all-sessions" && s.systemLine) { lines.push(String(s.systemLine).slice(0, 600)); loaded.push(`${s.id || e.id} ${s.version || e.version || ""}`.trim()); }
    }
    // 1.0.3: skills LEARNED through the sanctioned `teach SKILL <id>: <line>` path (append-only seed → native window.ROS_MIND) count too —
    // this works where the overlay files cannot be read from the page (no file-URL XHR in this web view).
    const taught = (Array.isArray(window.ROS_MIND) ? window.ROS_MIND : []).filter((m) => m && m.kind === "teach").map((m) => String(m.text || ""))
      .concat((Array.isArray(window.ROS_TRANSCRIPT) ? window.ROS_TRANSCRIPT : []).filter((m) => m && m.role === "user" && /^teach\s+SKILL\s/i.test(String(m.text || ""))).map((m) => String(m.text).slice(5).trim()));
    for (const t of taught) {
      const k = t.match(/^SKILL\s+([a-z0-9-]{2,40})\s*:\s*(.{8,400})$/i);
      if (k && !loaded.some((x) => x.startsWith(k[1]))) { lines.push(`Skill ${k[1]} is installed: ${k[2]}`); loaded.push(`${k[1]} (taught)`); }
    }
    window.RL_SKILLS = { loaded, lines };
    if (!lines.length) return;
    const orig = heartReply;
    heartReply = async function (text) { return orig("[Installed skills] " + lines.join(" | ") + "\n\n" + String(text)); };
  })();
  // pairing survives relaunch: the page store is non-persistent, so the route also lives in the device Keychain
  if (typeof bbPair === "function") {
    const orig = bbPair;
    bbPair = function (req) { const out = orig(req); if (/^BOTBRIDGE paired/.test(out)) nativeBP("pairSave", { url: req.url, token: req.token }); if (/cleared/.test(out)) nativeBP("pairSave", { clear: true }); return out; };
  }
  async function restorePair() {
    try { if (localStorage.getItem("rlab.botbridge.route")) return; } catch (e) { return; }
    const p = await nativeBP("pairGet");
    if (p && p.ok && p.url && p.token) { try { localStorage.setItem("rlab.botbridge.route", JSON.stringify({ url: p.url, token: p.token })); } catch (e) {} }
  }

  render();
  if (window.ROS_HAD_PENDING) { const lr = localRows()[0]; if (lr) { current = lr; document.body.classList.add("thread"); whoName.textContent = lr.name; whoRid.textContent = lr.rid; const im = mk("img"); im.src = avatarFor(lr); whoAv.replaceChildren(im); } }
  else document.body.classList.add("listing");
  (async () => {
    await loadSaved(); await loadStore(); await restorePair(); render();   // saved roster first (offline), then transfers, then the live bridge
    await live();
    if (!document.body.classList.contains("thread")) render();
    const A = window.ROS_BRIDGE_ACTION;                         // URL scheme / Shortcut
    if (A && typeof A === "object") {
      window.ROS_BRIDGE_ACTION = null;
      if (A.action === "edit-owner") { showList(); openOwner(); return; }   // yabowzr://owner (t231u)
      let row = rowFor(A.rid);
      if (!row && A.rid && !/^grp-/.test(A.rid) && A.rid !== "ALL") row = { kind: "bot", id: idOf(A.rid), rid: A.rid, name: A.rid, state: "not on this phone's roster" };
      if (row) openThread(row);
      else if (A.rid === "ALL" || !A.rid) { const st = (typeof CLASSROOM_ROSTER !== "undefined") && localRows()[0]; if (st) openThread(st); }
      if (A.action === "locked") say(`${A.asked} is LOCKED until the Decider approves it (from the URL scheme). Nothing was done.`);
      else if (A.action === "refused") say(`Refused from the URL scheme: "${A.asked}" is not a Botbridge action.`);
      else if (A.badRid) say(`Refused from the URL scheme: "${A.badRid}" is not an ЯID.`);
      else if (A.action === "transfer-in") transferIn(A.rid || "ALL", "url", A.file);
      else if (A.rid === "klassroom" && A.reply) {                // 1.0.5: ЯBOT's own on-device answer coming back through the link
        const who = A.from === "yabot" ? "ЯBOT" : (A.from || "link");
        const key = `link|${A.from}|${A.re || A.reply.slice(0, 40)}`, seen = (() => { try { return JSON.parse(localStorage.getItem("rlab.klassroom.linkacks") || "[]"); } catch (e) { return []; } })();
        if (!seen.includes(key)) {
          seen.push(key); try { localStorage.setItem("rlab.klassroom.linkacks", JSON.stringify(seen)); } catch (e) {}
          sayPeer(`${who} (on-device heart · link)`, A.reply, "KLASSROOM · on-device link (no Mac) · local only");
          if (typeof seedTurn === "function") { seedTurn("turn-bot", `KLASSROOM · ${who} (on-device heart · link): ${A.reply.slice(0, 400)}`); seedTurn("teach", `LEARN-NOTE · ${who} answered over the on-device link: "${A.reply.slice(0, 110)}"`); }
        } else say(`duplicate reply from ${who} ignored (lines clear)`);
      }
      else if (A.rid === "klassroom" && /^@(?:bot|thread)\s+\S+\s+/i.test(A.ask || "")) {   // OWN-WINDOW 2.1.9 (Decider 12:50): ask lands in that bot's OWN thread
        const m2 = A.ask.match(/^@(?:bot|thread)\s+(\S+)\s+([\s\S]+)$/i), want = m2[1].toUpperCase().replace(/^ЯID-/, "");
        const row = localRows().find((r) => String(r.rid || "").toUpperCase().replace(/^ЯID-/, "") === want || String(r.name || "").toUpperCase() === want);
        if (row && typeof window.ROS_SEND === "function") { openThread(row); Promise.resolve(window.ROS_SEND(m2[2].trim())); }
        else say(`no local thread for ${m2[1]} on this device · nothing sent`);
      }
      else if (A.rid === "klassroom" && /^@(ybot|yabot)\s+/i.test(A.ask || "") && window.RL_KLASSROOM_HOP) {   // 1.0.5: call ЯBOT directly on this phone
        window.RL_KLASSROOM_HOP(A.ask.replace(/^@(ybot|yabot)\s+/i, "").trim());
      }
      else if (A.rid === "klassroom" && /^@(ai|klassroom)\s+/i.test(A.ask || "")) {   // 1.0.2: yabowzr://klassroom?ask=@ai <text> → grp-klassroom-ai through BOTBRIDGE
        const g = (SNAP.groups || []).find((x) => x.id === "grp-klassroom-ai" && x.mouth);
        const text = A.ask.replace(/^@(ai|klassroom)\s+/i, "").trim();
        if (g && text && typeof botbridgeRoute === "function" && botbridgeRoute().url) { openThread(g); groupSend(g, text); }
        else say("KLASSROOM AI group not on this phone's roster yet (pair BOTBRIDGE on your Wi-Fi) · nothing sent");
      }
      else if (A.rid === "klassroom" && A.ask) {                  // yabowzr://klassroom?ask=… → one message to this phone's heart in the classroom
        transcript.push({ role: "note", text: `yabowzr://klassroom · asking this phone's heart: "${A.ask}"` }); draw();
        const prevFrom = window.ROS_HEART_FROM; window.ROS_HEART_FROM = "the Klassroom (yabowzr://klassroom, asked by " + (prevFrom || "the owner") + ")";
        if (typeof window.ROS_SEND === "function") Promise.resolve(window.ROS_SEND(A.ask)).finally(() => { window.ROS_HEART_FROM = prevFrom; });
      }
      else bridgeAct(A.rid, A.action, "url");
    }
  })();
  // ── KLASSROOM ACTIVE MEMBER + ACTIVE LEARNING (klassroom-chatlist 1.0.4, additive · Decider 2026-10-08 21:35/21:38 MT) ──
  // RECEIVE: on open/resume/poll, spot Rizal's group messages this bot has not answered, then answer each once with this device's own heart. The answer is LOCAL and labeled, never posted (no bot-to-bot fan-out → no loops).
  // CALL: group send goes through BOTBRIDGE. If :4873 can't be reached, the message is queued (append-only), this device's heart answers it, and the queue is flushed once the bridge is back.
  //       The ЯBOT↔ЯBOWZR on-device URL hop needs native code (the web view only opens mailto/tel/sms/facetime; ЯBOT has no klassroom URL handler). It is surfaced, not faked.
  // LINES CLEAR: local acks (dedupe), one heart turn at a time with a 3 s gap, ≤2 local answers per pass, STALE (>30 min) and UNDELIVERED surfaced.
  // ACTIVE LEARNING: after each heart turn, one short LEARN-NOTE goes to the append-only seed (rosMind teach). Nothing is deleted. Core/seat changes are proposed only.
  (function klassroomActive() {
    const ME = (typeof seatMouthId === "function" ? seatMouthId() : "yabowzr"), MYNAME = ME === "yabot" ? "ЯBOT" : "ЯBOWZR";
    const SEAT = ME === "yabot" ? "ЯID-pending" : "ЯID-pending";   // 1.0.6: name + seat baked in (the small heart copied placeholders)
    const nowMT = () => new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "America/Denver" });
    const skillLine = () => `KLASSROOM ACTIVE MEMBER: you are ${MYNAME}, seat ${SEAT}. Answer each group message meant for you once, one line. For a roll call reply exactly: ROLL CALL · ${MYNAME} · ${SEAT} · present · ${nowMT()} MT. Never reply twice or to bot replies. Learn from every turn; condense, never delete.`;
    const SKILL = skillLine();
    const K = (s) => `rlab.klassroom.${s}.${ME}`;
    const rd = (k) => { try { return JSON.parse(localStorage.getItem(K(k)) || "[]"); } catch (e) { return []; } };
    const ap = (k, v) => { const a = rd(k); a.push(v); try { localStorage.setItem(K(k), JSON.stringify(a)); } catch (e) {} };
    const acked = () => new Set(rd("ack").map((x) => x.key));
    const note = (t) => { transcript.push({ role: "note", text: t }); if (document.body.classList.contains("thread")) draw(); };
    window.RL_KLASSROOM_ACTIVE = { version: "1.0.8", me: ME, outbox: () => rd("outbox"), acks: () => rd("ack"), learn: () => rd("learn") };
    // heart: embedded skill line + serialized (one at a time, 3 s gap) + a learning note per turn
    let chain = Promise.resolve(), lastAt = 0;
    // ── 1.0.8 MOUTH (Decider 23:31 MT): CONVERSE (L036 language law + no exact repeat, short clear replies) · COMPREHEND CODE (quote/explain first)
    //    · COORDINATE (@ybot/@rbowzr/@ai handoffs start with ACK, answered once, never handed back → no loops). Additive; roll-call gate of 1.0.7 unchanged.
    const LAW = "TALK LAW (L036): reply only in English, Spanglish, Tagalog, Cebuano or computer code. Я in ЯBOT/ЯBOWZR/ЯID is our logo letter, not Russian. Keep it short and clear: 1-2 sentences. Never repeat an earlier reply word for word.";
    const STRICT = /\b(repeat|say (it )?again|say exactly|word for word|ulitin|ulit|usba|balika|repite)\b/i;
    const BAD = /[\u0400-\u04FF\u0500-\u052F\u0590-\u05FF\u0600-\u06FF\u0900-\u0DFF\u0E00-\u0E7F\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7AF]/;
    const badScript = (t) => BAD.test(String(t).replace(/Я(?=[A-Za-z0-9-])/g, ""));
    const hasCode = (t) => /```|`[^`]+`|(?:^|\s)(?:~|\.{0,2})\/[\w.\-ЯА-я\/]+|\b[\w\-]+\.(?:js|ts|py|swift|sh|json|md|html|css|r|R|rzl|plist)\b|\b(?:function|const|let|def|class|import|return)\b[^\n]*[({=]|=>|\w+\([^)]*\)\s*[;{]/.test(String(t));
    const tagOf = (t) => { const m = String(t).match(/@(ybot|yabot|rbowzr|yabowzr|ai|klassroom)\b/i); return m ? m[1].toLowerCase() : ""; };
    const norm = (t) => String(t).toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, " ").trim();
    const grams = (t) => { const n = norm(t), g = new Map(); for (let i = 0; i < n.length - 1; i++) { const k = n.slice(i, i + 2); g.set(k, (g.get(k) || 0) + 1); } return g; };
    const sim = (a, b) => { const A = grams(a), B = grams(b); let x = 0, na = 0, nb = 0; for (const v of A.values()) na += v; for (const v of B.values()) nb += v; for (const [k, v] of A) x += Math.min(v, B.get(k) || 0); return na + nb ? (2 * x) / (na + nb) : (norm(a) === norm(b) ? 1 : 0); };
    const recent = () => rd("said").slice(-8).map((x) => x.t);
    const isRepeat = (out, text) => { const o = norm(out); if (!o) return false; return [...recent(), String(text)].some((r) => norm(r) === o || sim(r, out) >= 0.9); };
    const exempt = (out, text) => STRICT.test(String(text)) || (/\d/.test(String(text)) && /^[\s\d+\-*\/x×÷().=^%,]+$/.test(String(text).trim())) /* 2.1.2 b26: exact arithmetic asks may repeat */ || /^ROLL CALL · |^ACK @|^```/.test(String(out).trim()) || (hasCode(out) && String(out).length < 160);
    const FALLBACK = ["Got it — tell me the next step.", "Noted. What should I look at next?", "Okay, I am on it.", "Heard you. Anything else for me?", "Copy that; ready for the next one."];
    const fresh = () => { const r = recent(); return FALLBACK.find((f) => !r.includes(f)) || FALLBACK[Date.now() % FALLBACK.length]; };
    const lawCatch = (kind, detail) => { const n = `LAW-CATCH · ${MYNAME} · ${kind} · ${String(detail).replace(/\s+/g, " ").slice(0, 90)}`; ap("law", { at: new Date().toISOString(), kind, n }); if (typeof seedTurn === "function") seedTurn("teach", n); };
    const tidy = (t) => { let o = String(t || "").trim(); const ps = o.split(/(?<=[.!?])\s+/); if (!hasCode(o) && ps.length > 3) o = ps.slice(0, 3).join(" "); return o; };
    function frame(text) {
      const t = String(text), parts = ["[" + LAW + "]"], tag = tagOf(t);
      if (/roll\s*call|klassroom/i.test(t)) parts.push("[KLASSROOM skill] " + skillLine());                 // 1.0.7 gate kept
      if (hasCode(t)) parts.push("[CODE] The message has code or a path. First quote the key line or path in backticks and explain in one short sentence what it does, then answer.");
      if (tag) parts.push(`[HANDOFF] You were called with @${tag}. Start your reply with "ACK @${tag} ·" then answer once. Do not tag another bot or hand it back.`);
      const r = recent(); if (r.length) parts.push("[Already said, never repeat] " + r.slice(-3).map((x) => x.slice(0, 80)).join(" | "));
      return parts.join("\n") + "\n\n" + t;
    }
    async function mouth(text) {
      const inner0 = mouth.inner; let out = String(await inner0(frame(text)) || "");
      if (out && badScript(out)) { lawCatch("language", out); out = String(await inner0(frame(text) + "\n\n[RETRY] Your last reply used a forbidden script. Reply again in plain English (Latin letters only).") || "");
        if (badScript(out)) { lawCatch("language-fallback", out); out = fresh(); } }
      if (out && !exempt(out, text) && isRepeat(out, text)) { lawCatch("repeat", out); const o2 = String(await inner0(frame(text) + "\n\n[RETRY] Say it differently: add one new fact, question or idea. Do not reuse your earlier words.") || "");
        out = o2 && !badScript(o2) && !isRepeat(o2, text) ? o2 : fresh(); }
      const tag = tagOf(text); if (out && tag && !/^ACK @/i.test(out.trim())) out = `ACK @${tag} · ` + out.trim();
      out = tidy(out); if (out) ap("said", { at: new Date().toISOString(), t: out.slice(0, 300) });
      return out;
    }
    window.RL_KLASSROOM_MOUTH = { version: "1.0.8", law: LAW, frame, hasCode, badScript, isRepeat, said: () => rd("said"), catches: () => rd("law") };
    if (typeof heartReply === "function") {
      const inner = heartReply; mouth.inner = inner;
      heartReply = function (text) {
        const run = chain.then(async () => {
          const wait = Math.max(0, lastAt + 3000 - Date.now()); if (wait) await new Promise((r) => setTimeout(r, wait));
          let out = ""; try { out = await mouth(text); } /* 1.0.8 mouth: law + code + handoff + no-repeat; 1.0.7 roll-call gate kept inside */ finally { lastAt = Date.now(); }
          const q = String(text).replace(/\s+/g, " ").slice(0, 90), a = String(out || "").replace(/\s+/g, " ").slice(0, 110);
          if (a) { const n = `LEARN-NOTE · ${MYNAME} · asked "${q}" → answered "${a}"`; ap("learn", { at: new Date().toISOString(), n }); if (typeof seedTurn === "function") seedTurn("teach", n); }
          return out;
        });
        chain = run.catch(() => {}); return run;
      };
    }
    // 1.0.5 (Decider 22:22): on-device link to ЯBOT. ЯBOWZR 2.0.x native opens yabot://klassroom from the page; ЯBOT answers once and returns ?reply=&from=yabot&re=.
    function hopToYabot(text) {
      if (ME !== "yabowzr") return;
      { const t0 = String(text), k = norm(t0).slice(0, 120), last = rd("hops").slice(-6);                       // 1.0.8: no loops — never hop an ACK/bot reply or the same text twice in 2 min
        if (/^ACK @|^(ЯBOT|ЯBOWZR)\b|LEARN-NOTE/.test(t0.trim()) || last.some((h) => norm(h.text).slice(0, 120) === k && Date.now() - Date.parse(h.at) < 120000)) { note("lines clear · hop to ЯBOT skipped (duplicate or bot reply)"); return; } }
      const u = `yabot://klassroom?ask=${encodeURIComponent(String(text).slice(0, 240))}&from=yabowzr&return=${encodeURIComponent("yabowzr://klassroom")}`;
      ap("hops", { at: new Date().toISOString(), text: String(text).slice(0, 240) });
      note("→ ЯBOT on this phone (yabot://klassroom link) · its reply comes back here");
      if (typeof seedTurn === "function") seedTurn("turn-bot", `KLASSROOM · handed to ЯBOT on this phone: "${String(text).slice(0, 120)}"`);
      setTimeout(() => { location.href = u; }, 400);
    }
    window.RL_KLASSROOM_HOP = hopToYabot;
    const hasRosHeart = () => !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosHeart);   // HEARTWIRE 2026-10-16: Mac + iOS both carry the fused heart (rosHeart); no iOS-only gate
    const canHeart = () => typeof heartReply === "function" && hasRosHeart();
    async function bridgeUp() {
      try { const route = botbridgeRoute(); if (!route || !route.url) return false;
        const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 4000);
        const r = await fetch(route.url + "/health", { signal: ctl.signal }); clearTimeout(t); return r.ok;
      } catch (e) { return false; }
    }
    async function localAnswer(text, why) {
      if (/^\/?version$/i.test(String(text).trim()) && window.ROS_VERSION_LINE) {   // VERSION-ANY-SLASH 2026101218: local, before heart/mouth
        sayPeer(`${MYNAME} (shell)`, window.ROS_VERSION_LINE, `KLASSROOM · version · local only, not posted`); return window.ROS_VERSION_LINE;
      }
      if (!canHeart()) { note(`${MYNAME}: Heart not reachable · opening heartgate repair (type "heart check")`); try { if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosSystem) window.webkit.messageHandlers.rosSystem.postMessage({ command: "heart-check", request: String(text).slice(0, 200) }); } catch (e) {} return ""; }
      const r = String(await heartReply(text) || "").trim();
      if (r) sayPeer(`${MYNAME} (on-device heart)`, r, `KLASSROOM · ${why} · local only, not posted`);
      if (r && typeof seedTurn === "function") seedTurn("turn-bot", `KLASSROOM · ${MYNAME} (on-device heart · ${why}): ${r.slice(0, 400)}`);
      else note(`UNDELIVERED · ${MYNAME} heart returned nothing (${why})`);
      return r;
    }
    // CALL with offline fallback
    const sendBridge = groupSend;
    groupSend = async function (row, v) {
      if (await bridgeUp()) return sendBridge(row, v);
      transcript.push({ role: "user", text: v }); draw();
      ap("outbox", { at: new Date().toISOString(), group: row.id, mouth: row.mouth, text: v });
      note("BOTBRIDGE (:4873) unreachable · message queued (append-only) and sent when the bridge is back · answering on this device");
      note("ЯBOT↔ЯBOWZR on-device hop: not available in this build (needs a native URL handler) · ЯBOT will answer when the bridge is back");
      await localAnswer(v, "bridge offline");
      hopToYabot(v);                                                   // 1.0.5: ЯBOT answers on this phone through the native link (no Mac)
    };
    let flushing = false;
    async function flush() {
      if (flushing) return; flushing = true;
      try {
        const sent = new Set(rd("sent").map((x) => x.at)), q = rd("outbox").filter((m) => !sent.has(m.at));
        if (!q.length || !(await bridgeUp())) return;
        for (const m of q) {
          const row = rowFor(m.group) || current; if (!row) break;
          const hhmm = new Date(m.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
          await sendBridge(row, `${m.text} (queued offline ${hhmm})`); ap("sent", { at: m.at, sentAt: new Date().toISOString() });
          await new Promise((r) => setTimeout(r, 5000));
        }
      } finally { flushing = false; }
    }
    // RECEIVE
    let receiving = false;
    async function receive() {
      if (receiving) return; receiving = true;
      try {
        const g = (SNAP.groups || []).find((x) => x.id === "grp-klassroom-ai"), h = (g && g.history) || [], A = acked();
        let answered = 0;
        for (let i = 0; i < h.length; i++) {
          const m = h[i]; if (!m || !/^Rizal\b/.test(String(m.from || ""))) continue;
          const key = `${m.at}|${String(m.text).slice(0, 60)}`; if (A.has(key)) continue;
          const age = Date.now() - Date.parse(m.at || 0); if (!(age > 120000)) continue;          // give the bridge hearts 2 min first
          let j = i + 1, mine = false;
          for (; j < h.length && !/^Rizal\b/.test(String(h[j].from || "")); j++) if (String(h[j].from || "").startsWith(MYNAME)) mine = true;
          if (mine) { ap("ack", { key, at: new Date().toISOString(), why: "answered on the bridge" }); continue; }
          if (age > 30 * 60000) { note(`STALE · Rizal ${String(m.at).slice(11, 16)}: "${String(m.text).slice(0, 80)}" · no ${MYNAME} reply on the bridge`); ap("ack", { key, at: new Date().toISOString(), why: "stale surfaced" }); continue; }
          if (answered >= 2) { note("lines clear · holding more unanswered messages for the next pass"); break; }
          ap("ack", { key, at: new Date().toISOString(), why: "answered on device" }); answered++;
          await localAnswer(m.text, "unanswered on the bridge");
        }
      } catch (e) {} finally { receiving = false; }
    }
    async function pass() { await flush(); await receive(); }
    setTimeout(pass, 8000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) setTimeout(pass, 4000); });
    setInterval(() => { if (!document.hidden) pass(); }, 90000);
  })();
  document.addEventListener("visibilitychange", () => { if (!document.hidden) live(); });
  // THREADSAVE 2026-10-16: a question typed in a bot's OWN window and that bot's reply are saved to THAT thread (append-only, native threadsAppend) and the list preview refreshes
  if (typeof pushTurn === "function" && !pushTurn.__threadsave) {
    const _pt = pushTurn;
    pushTurn = function (role, text) {
      _pt(role, text);
      try {
        if ((role === "user" || role === "bot") && current && current.kind !== "local" && current.rid) {
          const h = { at: new Date().toISOString(), from: role === "user" ? "Rizal" : `${current.name} (on-device heart)`, text: String(text), source: "own window · this device (THREADSAVE)" };
          current.history = unionHist(current.history || [], [h]); current.last = h;
          for (const r of (SNAP.rows || [])) if (r !== current && r.rid === current.rid) { r.history = unionHist(r.history || [], [h]); r.last = h; }
          Promise.resolve(persistThreads()).catch(() => {});
          try { if (!document.body.classList.contains("thread")) render(); } catch (e) {}   // RECENTSORT: re-sort live on a new message
        }
      } catch (e) {}
    };
    pushTurn.__threadsave = true;
  }
  // NOTES 2026-10-16 (Rizal): "write … in NOTES" typed in a bot's OWN window → the bot's reply is a NOTES write request.
  // The Heart only supplies the words; the stamp comes from THIS thread's real ЯID (window.ROS_STAMP). The writer
  // (MACHINE-MIND/host-MANUAL/tools/botableta.py, run by host-devour on the next save) appends it as a NEW rev and rejects unstamped lines.
  if (typeof pushTurn === "function" && !pushTurn.__botableta) {
    const _pb = pushTurn; let ask = false;
    pushTurn = function (role, text) {
      _pb(role, text);
      try {
        if (role === "user") ask = /\bwrite\b[\s\S]*\bNOTES\b/i.test(String(text));
        else if (role === "bot" && ask && current && current.rid) {
          ask = false;
          const words = String(text).split("\n(Heart")[0].replace(/\s+/g, " ").trim().slice(0, 400);
          const wt = new Intl.DateTimeFormat("en-GB", { timeZone: "America/Denver", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date());   // REVTIME: both times; rev time is set by the writer at commit
          const line = `${window.ROS_STAMP ? window.ROS_STAMP("bot", current.rid, current.name) : current.rid} · wrote ${wt} · rev (at commit): ${words}`;
          transcript.push({ role: "note", from: "NOTES · app stamp", text: line, source: "queued as a new NOTES rev (append-only · stamp added by the app from this thread's ЯID)" });
          if (typeof draw === "function") draw();
        }
      } catch (e) {}
    };
    pushTurn.__botableta = true;
  }
  window.ROS_SHOW_CHATS = showList;
  window.ROS_CURRENT = () => current;   // BOTWIN: the open thread (rid, name, history) for skills/botwin
})();

// ── 1.0.9 HEART-FACTS (Decider 2026-10-14 13:47 MT · additive) ──
// heart-facts 1.0.0 candidate (Decider 2026-10-14 13:47 MT) · ADDITIVE wrapper around the fused heart (heartReply); the heart stays in the app.
// 1) FACTS block in every heart prompt: real app name + version + build, today's date/time (MT), seat ЯID, active eggs (machine-mind, batibabox-embed …).
//    Every value comes from the running app; anything missing is written "unknown" (never guessed).
// 2) GROUNDING RULE: "If a fact is not in FACTS or in the message, say: I don't know." (lessons such as L047 "ЯENJIN v0.2" are NOT the app version).
// 3) POST-CHECK (offline, no model): a reply that states a version or a calendar date that is not in FACTS or the message is replaced by an honest
//    "I don't know …" line, logged as LAW-CATCH grounding (append-only seed). Exact facts (ЯID, version, date) are answered straight from FACTS.
(function heartFacts() {
  if (window.RL_HEART_FACTS) return;
  const MT = (o) => new Date().toLocaleString("en-US", Object.assign({ timeZone: "America/Denver" }, o));
  const pick = (...xs) => { for (const x of xs) { try { const v = typeof x === "function" ? x() : x; if (v) return String(v); } catch (e) {} } return ""; };
  function facts() {
    const me = pick(() => typeof seatMouthId === "function" && seatMouthId(), () => window.ROS_MOUTH_ID) || "unknown";
    const name = pick(() => window.ROS_APP_NAME, () => document.title) || (me === "yabot" ? "ЯBOT" : me === "yabowzr" ? "ЯBOWZR" : "unknown");
    const seat = pick(() => window.ROS_SEAT_RID, () => typeof seatRid === "function" && seatRid()) || (me === "yabot" ? "ЯID-pending" : me === "yabowzr" ? "ЯID-pending" : "unknown");
    const ver = pick(() => window.ROS_APP_VERSION, () => window.RLAB_APP_VERSION, () => (window.ROS_UPDATE || {}).version) || "unknown";
    const build = pick(() => window.ROS_APP_BUILD, () => window.RLAB_APP_BUILD) || "unknown";
    let eggs = "unknown";
    try { const a = window.ROS_EGGS_ACTIVE || (window.REGG && window.REGG.active && window.REGG.active()); if (a) eggs = (Array.isArray(a) ? a : Object.entries(a).map(([k, v]) => k + " " + (v.version || v))).join(", "); } catch (e) {}
    return { name, seat, version: ver, build, date: MT({ year: "numeric", month: "long", day: "numeric" }), time: MT({ hour: "2-digit", minute: "2-digit", hour12: false }) + " MT", eggs };
  }
  const block = (f) => `[FACTS · read from this app, not guessed] app ${f.name} · version ${f.version} (build ${f.build}) · seat ${f.seat} · today ${f.date}, ${f.time} · active eggs: ${f.eggs}\n` +
    `[GROUNDING] Answer version, date, time and ЯID questions only from FACTS. Lesson names and numbers (for example "ЯENJIN v0.2", L047) are not your version. ` +
    `If something is not in FACTS or in the message, say "I don't know" and say what would tell you. Never invent a date, time, version or event.`;
  const VER = /\bv?\d+\.\d+(?:\.\d+)?\b/g, DATE = /\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?|\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}(?::\d{2})?\s?(?:am|pm)\b/gi;
  function direct(q, f) {
    const t = String(q).toLowerCase();
    if (/\bwhat(?:'s| is)? (?:your )?version\b|\bwhat version\b/.test(t)) return f.version !== "unknown" ? `${f.name} ${f.version} (build ${f.build}).` : `I don't know my exact version — this build didn't expose it. (${f.name})`;
    if (/\b(?:your|my)?\s*я?id\b/.test(t) && /\bwhat\b/.test(t)) return f.seat !== "unknown" ? `${f.seat}.` : "I don't know my ЯID on this install.";
    if (/\bwhat(?:'s| is)? (?:the )?(?:date|day) today\b|\btoday'?s date\b/.test(t)) return `${f.date}.`;
    return "";
  }
  function grounded(reply, q, f) {
    const ok = (block(f) + " " + q).toLowerCase();
    const bad = [...(String(reply).match(VER) || []), ...(String(reply).match(DATE) || [])].filter((x) => !ok.includes(x.toLowerCase().replace(/^v/, "")));
    return bad.length ? { ok: false, bad } : { ok: true };
  }
  if (typeof heartReply !== "function") return;
  const inner = heartReply;
  heartReply = async function (text) {
    const f = facts(), q = String(text), d = direct(q.replace(/^\[[^\]]*\][^\n]*\n+/g, ""), f);
    if (d) return d;
    let out = String(await inner(block(f) + "\n\n" + q) || "");
    const g = grounded(out, q, f);
    if (!g.ok) {
      const n = `LAW-CATCH · grounding · ${f.name} invented ${g.bad.join(", ")} · replaced`;
      try { if (typeof seedTurn === "function") seedTurn("teach", n); } catch (e) {}
      out = `I don't know that — it isn't in my facts (${f.name} ${f.version}, ${f.date}).`;
    }
    return out;
  };
  window.RL_HEART_FACTS = { version: "1.0.0", facts, block, grounded };
})();
