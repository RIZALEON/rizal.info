/* rscribe.js · ЯSCRIBE 0.2 · ЯBOWZR overlay (iOS/iPadOS/macOS parity with the Mac native ЯSCRIBE 0.2).
 * Opens BELOW the bot header (as on Linux). Notes are rzl.doc.v1 pages (rscribe-doc.js), autosaved 1.2 s after typing.
 * Never deletes (archive only). Writes each saved rev into BATIBABOX: persists locally, mirrors a tagged line to the
 * install transcript (ns "notes" -> the shared memory index -> BATIBABOX index), and refreshes RL_BBX retrieval.
 * Data-only, no identifiers, no network. */
(function () {
  "use strict";
  if (typeof document === "undefined") return;
  if (window.RL_RSCRIBE) return;
  var DOC = window.RL_RSCRIBE_DOC;
  var LS = "rlab.rscribe.notes.v1";       // { name: {created, revs:[{rev,page,at}], chain:[], pinned, archived, title} }
  var state = { notes: {}, sel: null, mode: 0, timer: null, lastText: "" };

  function load() { try { state.notes = JSON.parse(localStorage.getItem(LS) || "{}"); } catch (e) { state.notes = {}; } }
  function persist() { try { localStorage.setItem(LS, JSON.stringify(state.notes)); } catch (e) {} }
  function stamp(d) { d = d || new Date(); function p(n){return(n<10?"0":"")+n;} return d.getFullYear()+""+p(d.getMonth()+1)+p(d.getDate())+"-"+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  // ---- host hooks (best-effort; all optional, all read-safe) ----
  function toTranscript(name, rev, text) {
    try { var h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosTranscript;
      if (h) h.postMessage({ cmd: "append", role: "system", ns: "notes",
        text: "ЯSCRIBE note " + name + " rev " + rev + " · " + text.replace(/\s+/g, " ").slice(0, 160) }); } catch (e) {}
  }
  function toBatibabox(name, rev, text) {
    // 1) local store is the source of truth in-app (no native note-file writer on iOS)
    // 2) mirror a tagged line into the transcript -> the shared memory index -> BATIBABOX index (next consolidation pass)
    toTranscript(name, rev, text);
    // 3) optional direct writer hook if a future native/egg writer provides it
    try { if (typeof window.RL_NOTES_SAVE === "function") window.RL_NOTES_SAVE(name, rev, text); } catch (e) {}
    // 4) nudge the shared retrieval runtime to pick up new indexed notes
    try { if (window.RL_BBX && typeof window.RL_BBX.refresh === "function") window.RL_BBX.refresh().catch(function(){}); } catch (e) {}
  }

  // ---- panel (below the bot header) ----
  var panel, listEl, editor, viewer, statusEl, titleEl;
  function ensurePanel() {
    if (panel) return;
    var main = document.querySelector("main") || document.body;
    var hero = document.getElementById("bot-hero");
    panel = el("section", "rscribe"); panel.id = "rscribe"; panel.hidden = true;
    panel.setAttribute("aria-label", "ЯSCRIBE notes");
    var bar = el("div", "rsc-bar");
    var bNew = el("button", "rsc-btn", "✎ New"); bNew.type = "button"; bNew.addEventListener("click", newNote);
    var bWrite = el("button", "rsc-tab sel", "Write"); bWrite.type = "button"; bWrite.addEventListener("click", function(){ setMode(0); });
    var bRead = el("button", "rsc-tab", "Reader"); bRead.type = "button"; bRead.addEventListener("click", function(){ setMode(1); });
    var bBot = el("button", "rsc-tab", "Bot"); bBot.type = "button"; bBot.addEventListener("click", function(){ setMode(2); });
    var bPin = el("button", "rsc-btn", "📌 Pin"); bPin.type = "button"; bPin.addEventListener("click", togglePin);
    var bArch = el("button", "rsc-btn", "Archive"); bArch.type = "button"; bArch.addEventListener("click", archive);
    var bClose = el("button", "rsc-btn rsc-close", "✕"); bClose.type = "button"; bClose.addEventListener("click", close);
    titleEl = el("input", "rsc-title"); titleEl.placeholder = "Note title"; titleEl.addEventListener("input", schedule);
    bar._tabs = { 0: bWrite, 1: bRead, 2: bBot };
    bar.append(bNew, bWrite, bRead, bBot, bPin, bArch, bClose);
    var body = el("div", "rsc-body");
    listEl = el("nav", "rsc-list");
    var pane = el("div", "rsc-pane");
    editor = el("textarea", "rsc-editor"); editor.placeholder = "# Title\n\nStart writing. Autosaves 1.2 s after you stop.";
    editor.addEventListener("input", schedule);
    viewer = el("pre", "rsc-viewer"); viewer.hidden = true;
    pane.append(titleEl, editor, viewer);
    body.append(listEl, pane);
    statusEl = el("div", "rsc-status", "ready · offline");
    panel.append(bar, body, statusEl);
    if (hero && hero.parentNode) hero.parentNode.insertBefore(panel, hero.nextSibling);  // BELOW the bot header
    else main.insertBefore(panel, main.firstChild);
    state._tabs = bar._tabs;
  }

  function open() { ensurePanel(); panel.hidden = false; renderList(); if (!state.sel) newNote(); window.RL_RSCRIBE.opened = true; }
  function close() { if (!panel) return; flush(); panel.hidden = true; window.RL_RSCRIBE.opened = false; }
  function toggle() { ensurePanel(); if (panel.hidden) open(); else close(); }

  function setMode(m) { state.mode = m; if (state._tabs) for (var k in state._tabs) state._tabs[k].classList.toggle("sel", +k === m); draw(); }

  function newNote() {
    flush();
    var name = "SCRIBE-" + stamp();
    state.notes[name] = state.notes[name] || { created: new Date().toISOString(), revs: [], chain: [], pinned: false, archived: false, title: "" };
    state.sel = name; state.lastText = ""; titleEl.value = ""; editor.value = ""; setMode(0); renderList();
    status("new note · writes on first edit · offline");
    editor.focus();
  }

  function select(name) { flush(); state.sel = name; var n = state.notes[name]; var head = n.revs[n.revs.length - 1];
    editor.value = head ? DOC.human(head.page.blocks) : ""; titleEl.value = n.title || ""; state.lastText = editor.value; setMode(0); renderList(); draw();
    status(head ? name + "@" + head.rev + " · " + head.page.blocks.length + " blocks · rzl.doc.v1 · offline" : "new note · offline"); }

  function schedule() { if (state.timer) clearTimeout(state.timer); state.timer = setTimeout(flush, 1200); }

  async function flush() {
    if (state.timer) { clearTimeout(state.timer); state.timer = null; }
    if (!state.sel) return;
    var text = editor.value, title = titleEl.value.trim();
    var n = state.notes[state.sel];
    if (!n) return;
    var changed = text !== state.lastText || (title && title !== n.title);
    if (!changed || (!text.trim() && !n.revs.length)) return;   // nothing to write for an empty new note
    var rev = (n.revs.length ? n.revs[n.revs.length - 1].rev : 0) + 1;
    var extra = {}; if (title) { extra.display_title = title; n.title = title; }
    var blocks = DOC.parse(text);
    var page = await DOC.page(state.sel, rev, blocks, n.created, extra);
    n.revs.push({ rev: rev, page: page, at: new Date().toISOString() });
    var rec = await DOC.chainAppend(n.chain, { kind: "doc.edit", op: "set", name: state.sel, rev: rev, at: new Date().toISOString(), app: DOC.VERSION });
    n.chain.push(rec);
    state.lastText = text; persist();
    toBatibabox(state.sel, rev, text);
    renderList(); draw();
    status("1/3 page @" + rev + " ✓ · 2/3 chain ✓ · 3/3 BATIBABOX mirror ✓ · " + state.sel + "@" + rev);
  }

  function togglePin() { if (!state.sel) return; var n = state.notes[state.sel]; n.pinned = !n.pinned;
    n.chain.push({ kind: "doc.log", op: n.pinned ? "pin" : "unpin", name: state.sel, at: new Date().toISOString() }); persist(); renderList();
    status(n.pinned ? "pinned" : "unpinned"); }

  function archive() {
    if (!state.sel) return;
    var n = state.notes[state.sel];
    if (!window.confirm("Archive this note? It is hidden, never erased, and can be restored.")) return;
    n.archived = !n.archived; n.chain.push({ kind: "doc.log", op: n.archived ? "archive" : "restore", name: state.sel, at: new Date().toISOString() });
    persist(); renderList(); status(n.archived ? "archived (not erased)" : "restored");
  }

  function status(t) { if (statusEl) statusEl.textContent = t; }

  function renderList() {
    if (!listEl) return;
    listEl.textContent = "";
    var names = Object.keys(state.notes).filter(function (k) { return !state.notes[k].archived || state._showArch; });
    names.sort(function (a, b) {
      var A = state.notes[a], B = state.notes[b];
      if (!!B.pinned - !!A.pinned) return !!B.pinned - !!A.pinned;
      var at = (A.revs[A.revs.length - 1] || {}).at || A.created, bt = (B.revs[B.revs.length - 1] || {}).at || B.created;
      return bt < at ? -1 : 1;
    });
    names.forEach(function (name) {
      var n = state.notes[name];
      var row = el("button", "rsc-row" + (name === state.sel ? " sel" : "") + (n.pinned ? " pin" : ""));
      row.type = "button";
      row.append(el("span", "rsc-row-t", (n.pinned ? "📌 " : "") + (n.title || name)), el("small", "", name + (n.revs.length ? "@" + n.revs[n.revs.length - 1].rev : "")));
      row.addEventListener("click", function () { select(name); });
      listEl.append(row);
    });
  }

  function draw() {
    if (!state.sel || !editor) return;
    var n = state.notes[state.sel], head = n.revs[n.revs.length - 1];
    if (state.mode === 0) { editor.hidden = false; viewer.hidden = true; }
    else if (state.mode === 1) { editor.hidden = true; viewer.hidden = false; viewer.textContent = head ? DOC.human(head.page.blocks) : DOC.human(DOC.parse(editor.value)); }
    else { editor.hidden = true; viewer.hidden = false; viewer.textContent = head ? JSON.stringify(head.page, null, 1) : "(no saved rev yet)"; }
  }

  function search(q) {
    q = (q || "").toLowerCase();
    return Object.keys(state.notes).filter(function (name) {
      var n = state.notes[name]; if ((n.title || name).toLowerCase().indexOf(q) >= 0) return true;
      var head = n.revs[n.revs.length - 1]; return head ? DOC.human(head.page.blocks).toLowerCase().indexOf(q) >= 0 : false;
    });
  }

  // ---- top-bar button + hook into the clay ЯSCRIBE tile if the shell exposes one ----
  function wireButton() {
    // the native shell injects window.ROS_RSCRIBE_TOGGLE or a #rscribe-btn; otherwise add our own tile right of the composer
    window.RL_RSCRIBE_TOGGLE = toggle;
    var existing = document.getElementById("rscribe-btn");
    if (existing) { existing.addEventListener("click", toggle); return; }
    var hero = document.getElementById("bot-hero");
    if (hero) { var b = el("button", "rsc-open-btn", "ЯSCRIBE"); b.id = "rscribe-open"; b.type = "button"; b.title = "Open ЯSCRIBE (notes)"; b.addEventListener("click", toggle); hero.appendChild(b); }
  }

  window.RL_RSCRIBE = { version: "0.2", open: open, close: close, toggle: toggle, newNote: newNote, search: search,
    get notes() { return state.notes; }, flush: flush, opened: false };

  function injectCss() { if (document.getElementById("rscribe-css")) return; var l = document.createElement("link"); l.id = "rscribe-css"; l.rel = "stylesheet"; l.href = "./skills/rscribe/rscribe.css"; document.head.appendChild(l); }
  function boot() { injectCss(); load(); wireButton(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
