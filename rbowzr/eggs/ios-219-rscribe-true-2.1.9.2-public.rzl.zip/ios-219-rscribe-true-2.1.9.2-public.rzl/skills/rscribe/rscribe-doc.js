/* rscribe-doc.js · ЯSCRIBE 0.2 · rzl.doc.v1 model + canonical JSON + block sealing + chain records.
 * Faithful to the Mac native ЯSCRIBE 0.2 (Shared/RScribe.swift, branch rscribe-0.2): sorted keys, no spaces,
 * shortest numbers, SHA-256 sealed blocks (n/size/sha256), hash-linked chain.jsonl (prev_hash/entry_hash).
 * Pure data + logic; no DOM, no identifiers. Works in a browser (SubtleCrypto) and headless (node webcrypto). */
(function (root) {
  "use strict";
  var VERSION = "0.2";
  // ---- canonical JSON (byte-identical to the native canon()) ----
  function quote(s) {
    var r = '"';
    for (var i = 0; i < s.length; i++) {
      var c = s[i], v = s.charCodeAt(i);
      if (c === '"') r += '\\"';
      else if (c === '\\') r += '\\\\';
      else if (c === '\n') r += '\\n';
      else if (c === '\r') r += '\\r';
      else if (c === '\t') r += '\\t';
      else if (v === 8) r += '\\b';
      else if (v === 12) r += '\\f';
      else if (v < 0x20) r += '\\u' + ('0000' + v.toString(16)).slice(-4);
      else r += c;
    }
    return r + '"';
  }
  function num(n) {
    if (!isFinite(n)) return 'null';
    if (Number.isInteger(n)) return String(n);
    return String(n);
  }
  function canonStr(o) {
    if (o === null || o === undefined) return 'null';
    var t = typeof o;
    if (t === 'string') return quote(o);
    if (t === 'boolean') return o ? 'true' : 'false';
    if (t === 'number') return num(o);
    if (Array.isArray(o)) {
      if (!o.length) return '[]';
      return '[' + o.map(canonStr).join(',') + ']';
    }
    if (t === 'object') {
      var ks = Object.keys(o).sort();
      if (!ks.length) return '{}';
      return '{' + ks.map(function (k) { return quote(k) + ':' + canonStr(o[k]); }).join(',') + '}';
    }
    return 'null';
  }
  function utf8(s) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(s);
    return Buffer.from(s, 'utf8');
  }
  function toHex(buf) {
    var u = new Uint8Array(buf), h = '';
    for (var i = 0; i < u.length; i++) h += ('0' + u[i].toString(16)).slice(-2);
    return h;
  }
  function subtle() {
    if (typeof crypto !== 'undefined' && crypto.subtle) return crypto.subtle;
    if (typeof require !== 'undefined') { try { return require('crypto').webcrypto.subtle; } catch (e) {} }
    return null;
  }
  async function sha256Hex(s) {
    var sc = subtle(), bytes = utf8(s);
    if (sc) { var d = await sc.digest('SHA-256', bytes); return toHex(d); }
    var c = require('crypto'); return c.createHash('sha256').update(Buffer.from(bytes)).digest('hex');
  }
  function byteLen(s) { return utf8(s).length; }

  // ---- blocks ----
  var SEAL_KEYS = ['n', 'sha256', 'size', 'rid'];
  function content(b) { var c = {}; for (var k in b) if (SEAL_KEYS.indexOf(k) < 0) c[k] = b[k]; return c; }
  function defaultTag(type) { return type === 'head' ? null : (type === 'live' ? 'observed' : 'declared'); }
  async function seal(blocks) {
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      var c = content(blocks[i]);
      if (c.type !== 'head' && (c.tag === undefined || c.tag === null)) { var dt = defaultTag(c.type || 'text'); if (dt) c.tag = dt; }
      var cs = canonStr(c);
      c.n = i; c.sha256 = await sha256Hex(cs); c.size = byteLen(cs);
      out.push(c);
    }
    return out;
  }
  function titleOf(blocks) {
    for (var i = 0; i < blocks.length; i++) { var b = blocks[i]; if (b.type === 'head' && (b.level === 1 || b.level === undefined)) return b.text || ''; }
    for (var j = 0; j < blocks.length; j++) if (blocks[j].text) return String(blocks[j].text).slice(0, 80);
    return '';
  }
  async function page(name, rev, blocks, created, extra) {
    var sealed = await seal(blocks);
    var p = { schema: 'rzl.doc.v1', spec: 'RZL-DOC 0.1', name: name, title: titleOf(sealed), rev: rev,
      layer: 'PUBLIC', lang: 'en', source: { authored: VERSION + ' (ЯBOWZR composer)', at: created }, blocks: sealed };
    if (extra) for (var k in extra) p[k] = extra[k];
    return p;
  }

  // ---- composer text  ->  blocks (Markdown-ish, matches the native parser) ----
  function parse(text) {
    var lines = String(text).replace(/\r\n/g, '\n').split('\n');
    var blocks = [], i = 0;
    while (i < lines.length) {
      var ln = lines[i];
      var fence = /^```(.*)$/.exec(ln);
      if (fence) {
        var lang = fence[1].trim(), body = [];
        i++;
        while (i < lines.length && !/^```\s*$/.test(lines[i])) { body.push(lines[i]); i++; }
        i++; // closing fence
        blocks.push({ type: 'code', lang: lang || '', text: body.join('\n') });
        continue;
      }
      var h = /^(#{1,3})\s+(.*)$/.exec(ln);
      if (h) { blocks.push({ type: 'head', level: h[1].length, text: h[2].trim() }); i++; continue; }
      // table
      if (/^\s*\|.*\|\s*$/.test(ln)) {
        var rows = [], cap = null;
        if (blocks.length) { var prev = blocks[blocks.length - 1]; var cm = prev.type === 'text' && /^Table\s*·\s*(.+)$/.exec(prev.text || ''); if (cm) { cap = cm[1]; blocks.pop(); } }
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
          var cells = lines[i].trim().replace(/^\||\|$/g, '').split('|').map(function (c) { return c.trim(); });
          if (!/^[\s:|-]+$/.test(lines[i])) rows.push(cells);
          i++;
        }
        var tb = { type: 'table', columns: rows.shift() || [], rows: rows };
        if (cap) tb.caption = cap;
        blocks.push(tb); continue;
      }
      // list / checklist / numbered
      var chk = /^\s*-\s*\[([ xX])\]\s+(.*)$/.exec(ln);
      var bull = /^\s*(?:[-•])\s+(.*)$/.exec(ln);
      var numbered = /^\s*\d+\.\s+(.*)$/.exec(ln);
      if (chk || bull || numbered) {
        var items = [], checked = [], style = numbered ? 'ordered' : (chk ? 'check' : 'bullet'), idx = 0;
        while (i < lines.length) {
          var c2 = /^\s*-\s*\[([ xX])\]\s+(.*)$/.exec(lines[i]);
          var b2 = /^\s*(?:[-•])\s+(.*)$/.exec(lines[i]);
          var n2 = /^\s*\d+\.\s+(.*)$/.exec(lines[i]);
          if (style === 'check' && c2) { items.push(c2[2]); if (c2[1].toLowerCase() === 'x') checked.push(idx); idx++; i++; }
          else if (style === 'ordered' && n2) { items.push(n2[1]); idx++; i++; }
          else if (style === 'bullet' && b2 && !c2) { items.push(b2[1]); idx++; i++; }
          else break;
        }
        var lb = { type: 'list', style: style, items: items };
        if (style === 'check') lb.checked = checked;
        blocks.push(lb); continue;
      }
      var live = /^::live\s+(\S+)\s*(.*)$/.exec(ln);
      if (live) { blocks.push({ type: 'live', expr: live[1], text: live[2] || '' }); i++; continue; }
      var link = /^::link\s+(\S+?)#(\d+)\s*(.*)$/.exec(ln);
      if (link) { blocks.push({ type: 'link', to: { doc: link[1], block: parseInt(link[2], 10) }, text: link[3] || '' }); i++; continue; }
      if (ln.trim() === '') { i++; continue; }
      // paragraph (accumulate until blank / block starter)
      var para = [ln]; i++;
      while (i < lines.length && lines[i].trim() !== '' && !/^(#{1,3}\s|```|\s*\||\s*[-•]\s|\s*\d+\.\s|::live|::link)/.test(lines[i])) { para.push(lines[i]); i++; }
      var ptext = para.join('\n'), tag;
      if (/\s\[inferred\]\s*$/.test(ptext)) { ptext = ptext.replace(/\s\[inferred\]\s*$/, ''); tag = 'inferred'; }
      var pb = { type: 'text', text: ptext };
      if (tag) pb.tag = tag;
      blocks.push(pb);
    }
    return blocks;
  }

  // composer text  <-  blocks (Reader "human view", same as rzl-doc cat)
  function human(blocks) {
    var out = [];
    (blocks || []).forEach(function (b) {
      if (b.type === 'head') out.push((b.level === 2 ? '## ' : b.level === 3 ? '### ' : '# ') + (b.text || ''));
      else if (b.type === 'code') out.push('```' + (b.lang || '') + '\n' + (b.text || '') + '\n```');
      else if (b.type === 'list') {
        (b.items || []).forEach(function (it, k) {
          if (b.style === 'ordered') out.push((k + 1) + '. ' + it);
          else if (b.style === 'check') out.push('- [' + ((b.checked || []).indexOf(k) >= 0 ? 'x' : ' ') + '] ' + it);
          else out.push('• ' + it);
        });
      } else if (b.type === 'table') {
        if (b.caption) out.push('Table · ' + b.caption);
        if (b.columns) out.push('| ' + b.columns.join(' | ') + ' |');
        (b.rows || []).forEach(function (r) { out.push('| ' + r.join(' | ') + ' |'); });
      } else if (b.type === 'live') out.push('⚡ ' + (b.text || b.expr) + '  (' + b.expr + ')');
      else if (b.type === 'link') out.push('↔ ' + (b.text || '') + ' → ' + b.to.doc + '#' + b.to.block);
      else out.push(b.text || '');
    });
    return out.join('\n\n');
  }

  // ---- chain record (prev_hash links to previous record; entry_hash = sha256(canon(record))) ----
  async function chainAppend(prevRecords, rec) {
    var r = {};
    for (var k in rec) r[k] = rec[k];
    var prior = prevRecords && prevRecords.length ? prevRecords[prevRecords.length - 1] : null;
    r.prev_hash = (prior && prior.entry_hash) || ('doc:' + (rec.name || rec.doc || ''));
    r.entry_hash = await sha256Hex(canonStr(r));
    return r;
  }
  async function verifyChain(records, name) {
    var prev = 'doc:' + name;
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (r.prev_hash !== prev) return { ok: false, at: i, why: 'prev_hash break' };
      var c = {}; for (var k in r) if (k !== 'entry_hash') c[k] = r[k];
      var h = await sha256Hex(canonStr(c));
      if (h !== r.entry_hash) return { ok: false, at: i, why: 'entry_hash mismatch' };
      prev = r.entry_hash;
    }
    return { ok: true, n: records.length };
  }

  var API = { VERSION: VERSION, canon: canonStr, sha256Hex: sha256Hex, byteLen: byteLen, seal: seal,
    content: content, titleOf: titleOf, page: page, parse: parse, human: human,
    chainAppend: chainAppend, verifyChain: verifyChain };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (root) root.RL_RSCRIBE_DOC = API;
})(typeof window !== 'undefined' ? window : null);
