/* test-true-rename.js · ЯBOWZR overlay patch 2.1.9.2
 * Display-only: relabels the in-shell bot-sidebar header badge from "TEST" to "TRUE".
 * Data-only, no logic change, no identifiers. Runs after the sidebar paints and on every repaint. */
(function () {
  "use strict";
  if (window.RL_TEST_TRUE_RENAME) return;
  window.RL_TEST_TRUE_RENAME = { version: "2.1.9.2", from: "TEST", to: "TRUE" };
  var FROM = "TEST", TO = "TRUE";
  function fix() {
    var tags = document.querySelectorAll(".hd small");
    for (var i = 0; i < tags.length; i++) {
      if (tags[i].textContent.trim() === FROM) tags[i].textContent = TO;
    }
  }
  function boot() {
    fix();
    try {
      var mo = new MutationObserver(function () { fix(); });
      mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
