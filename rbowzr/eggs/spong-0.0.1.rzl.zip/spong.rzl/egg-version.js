window.SPONG_EGG={id:"spong",version:"0.0.1",staged:"2026-10-14",signed:false};
